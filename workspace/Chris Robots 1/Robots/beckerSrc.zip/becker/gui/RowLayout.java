/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.gui;


 
 


/** <p>A RowLayout manages the layout of a container's components.  The
 components are laid out in a row according to their preferred sizes.
 If the components will not fit into the container they are all
 scaled by the same amount in both the horizontal and vertical dimensions
 so they will fit.</p>

 <p>By default, all components will be laid out so their bottoms are aligned.
 A RowLayout may also be set to align the tops or centers of the components.
 Similarly, the row itself is centered horizontally by default but may be set
 to align at either the left or the right of the container.</p>

 @author Byron Weber Becker */
public class RowLayout implements LayoutManager
{ /*0*/

   /** Vertically align the bottoms of the components. */
   public static final int ALIGN_BOTTOMS = 1;

   /** Vertically align the centers of the components. */
   public static final int ALIGN_CENTERS = 2;

   /** Vertically align the tops of the components. */
   public static final int ALIGN_TOPS = 3;

   /** Position the components as far left as possible within the container. */
   public static final int JUSTIFY_LEFT = 4;

   /** Position the components in the center of the container. */
   public static final int JUSTIFY_CENTER = 5;

   /** Position the components as far right as possible within the container. */
   public static final int JUSTIFY_RIGHT = 6;

       
       
       

   /** Construct a new RowLayout layout manager which aligns component
    bottoms and center justifies the row. */
   public RowLayout()
   { /*1*/   
   } /*1*/

   /** Construst a new RowLayout layout manager.
    @param alignment How the components are aligned vertically.  One of
    {ALIGN_BOTTOMS, ALIGN_CENTERS, ALIGN_TOPS}.
    @param justification How the row of components is justified horizontally.
    One of {JUSTIFY_LEFT, JUSTIFY_CENTER, JUSTIFY_RIGHT}. */
   public RowLayout(int alignment, int justification)
   { /*1*/  
        
        
   } /*1*/

   /**
    * Adds the specified component with the specified name to
    * the layout.
    * @param name the component name
    * @param comp the component to be added
    */
   public void addLayoutComponent(String name, Component comp)
   { /*1*/} /*1*/

   /**
    * Removes the specified component from the layout.
    * @param comp the component to be removed
    */
   public void removeLayoutComponent(Component comp)
   { /*1*/} /*1*/

   /**
    * Calculates the preferred size dimensions for the specified
    * panel given the components in the specified parent container.
    * @param parent the component to be laid out
    *
    * @see #minimumLayoutSize
    */
   public Dimension preferredLayoutSize(Container parent)
   { /*1*/     
         

            
              
         
              
           
          
               
               
                    
            
         
      
         
          
      
       
   } /*1*/

   /**
    * Calculates the minimum size dimensions for the specified 
    * panel given the components in the specified parent container.
    * @param parent the component to be laid out
    * @see #preferredLayoutSize
    */
   public Dimension minimumLayoutSize(Container parent)
   { /*1*/     
         

            
              
         
              
           
          
               
               
                    
            
         
      
         
          
      
       
   } /*1*/

   /**
    * Lays out the container in the specified panel.
    * @param parent the component which needs to be laid out
    */
   public void layoutContainer(Container parent)
   { /*1*/     
         

         
            
                

           

         

              
           
          
              
                  
                  

               
             
              
                        

             
                  
               

             
                        
               

             
                     
                     
               
            

                   
         
      
   } /*1*/

   /** Set the horizontal gap between components.
    @param gap The gap between components, in pixels. */
   public void setHgap(int gap)
   { /*1*/    
   } /*1*/

   /** Get the horizontal gap between components.
    @return The gap between components, in pixels. */
   public int getHgap()
   { /*1*/   
   } /*1*/

   /** Calculate the x position of the leftmost component. */
   
     
         

         
       
        
                  

       
           
         

       
             
                         
         

       
             
                       
         
      
       
   

   /*
    public static void main(String[] args)
    {  

    RowLayout rl = new RowLayout(ALIGN_BOTTOMS, JUSTIFY_CENTER);
    rl.setHgap(10);
    JPanel contents = new JPanel(rl);
    contents.add(new Button("A Button"));
    contents.add(new JList(new String[]{"One", "Two", "Three"}));
    contents.add(new TextArea(5, 10));


    JFrame f = new JFrame();
    f.setContentPane(contents);
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    f.setBounds(10, 10, 400, 400);
    f.setVisible(true);
    }
    */

} /*0*/
