
package becker.gui;


 
 
 
 
 

/** JIntField is just like a JTextField except that it will accept only
 * integers in the range Integer.MIN_VALUE..Integer.MAX_VALUE.  It also
 * provides two convienience functions, <code>setInt</code> and 
 * <code>getInt</code>.
 *
 * @author Byron Weber Becker */
public class JIntField extends JTextField
{ /*0*/
   /** Constructs a new empty JIntField with the specified number of columns. 
    * The initial value is set to 0.
    * @param columns the number of columns to use to calculate the preferred 
    * width.  If columns is zero, the preferred width calculations will
    * depend on the current underlying implementation. */
   public JIntField(int columns)
   { /*1*/   
   } /*1*/

   /** Constructs a new JIntField.  Sets the number of columns to 0 and
    * the initial value to 0.*/
   public JIntField()
   { /*1*/   
   } /*1*/

   /** Constructs a new JIntField with the specified number of columns and 
    * sets the initial value to the given value. 
    * @param columns the number of columns to use to calculate the preferred 
    * width.  If columns is zero, the preferred width calculations will
    * depend on the current underlying implementation.
    * @param initialValue the initial value displayed */
   public JIntField(int columns, int initialValue)
   { /*1*/  
      
   } /*1*/

   /** Get the integer entered into this text field.
    * @return the integer entered in this text field. */
   public int getInt()
   { /*1*/     
   
       
   } /*1*/

   /** Set the contents of this text field to the given integer.
    * @param i the integer to display. */
   public void setInt(int i)
   { /*1*/    
   } /*1*/
 
   protected Document createDefaultModel()
   { /*1*/    
   } /*1*/
 
       
   { /*1*/  
               
           
           
         
         
            
            
                 
              
             
                
                             
                
            
         
            
                
                  
            
            
            
              
                   
                  
               
              
               
            
         
            
              
          
      
   } /*1*/
} /*0*/
