/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.gui;


 
 
 
 
 
 


/** A layout manager that arranges components in a double column.  In most
 * cases the left column will hold a label and the right column will hold a
 * component the user can manipulate.  Preferred component sizes are respected
 * as much as possible.  Components in the left column are right justified;  
 * components in the right column are left justified.
 * <img src="doc-files/FormLayout.gif"> 
 *
 * @author Byron Weber Becker */
public class FormLayout implements LayoutManager
{ /*0*/
       
       
   
   /** Construct a new FormLayout object. */
   public FormLayout()
   { /*1*/  
   } /*1*/
   
   /** Construct a new FormLayout object. 
    * @param hGap the number of hortizontal pixels between components
    * @param vGap the number of vertical pixels between components */
   public FormLayout(int hGap, int vGap)
   { /*1*/  
        
        
   } /*1*/
   
   /**
    * Adds the specified component with the specified name to
    * the layout.
    * @param name the component name
    * @param comp the component to be added
    */
   public void addLayoutComponent(String name, Component comp)
   { /*1*/} /*1*/

   /**
    * Removes the specified component from the layout.
    * @param comp the component to be removed
    */
   public void removeLayoutComponent(Component comp)
   { /*1*/} /*1*/

   /**
    * Calculates the preferred size dimensions for the specified 
    * panel given the components in the specified parent container.
    * @param parent the component to be laid out
    *  
    * @see #minimumLayoutSize
    */
   public Dimension preferredLayoutSize(Container parent)
   { /*1*/   
            
          
               
                 
                
                   
          
      
   } /*1*/

   /* Precondition:  the caller has gotten the treelock.
    * preferred = true for preferred sizes;  false for minimum sizes */   
   
      
         
      
                
             
            
            
          
          
          
             
              
          
             
              
         
             
             
             
               
      
           
        
              
            
          
          
             
          
             
         
             
                      
      
          
          
       
   

   /**
    * Calculates the minimum size dimensions for the specified 
    * panel given the components in the specified parent container.
    * @param parent the component to be laid out
    * @see #preferredLayoutSize
    */
   public Dimension minimumLayoutSize(Container parent)
   { /*1*/   
            
          
               
                 
                
                   
          
      
   } /*1*/

   /**
    * Lays out the container in the specified panel.
    * @param parent the component which needs to be laid out 
    */
   public void layoutContainer(Container parent)
   { /*1*/     
   
       
            
         
                  
            
                  
            
                  
               
             
         
         
         
         
                 
                             
                            
                
              
         
            
                   
                
               
               
               
            
                  
            
            
                   
            	
            	     
            	     
            
                    
                  
            
            
            
                   
            	
            	     
            	     
            
                   
                  
         
              
           
                 
               
           	     
           	     
                    
                  
         
      
   } /*1*/  
   
      
   { /*1*/
         
         
         
   } /*1*/ 
} /*0*/
