/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


 
 


/** An instance of <code>Observers</code> is usually used by a class implementing
 * <code>IObservable</code> to store its list of observers.  Each time the
 * class changes, it should call <code>notifyObservers</code>.  This, in turn,
 * calls the <code>update</code> method for each of the observers stored in
 * the list.
 *
 * @see IObservable
 * @see IObserver
 *
 * @author Byron Weber Becker */
public class Observers extends Object implements IObservable
{ /*0*/
     

   /** Construct a new list of observers. */
   public Observers()
   { /*1*/  
         
   } /*1*/

   /** Add another observer to the list.
    * @param observer The observer to add. */
   public void addObserver(IObserver observer)
   { /*1*/  
   } /*1*/

   /** Remove a specific observer from the list.
    * @param observer The observer to remove. */
   public void removeObserver(IObserver observer)
   { /*1*/  
   } /*1*/

   /** Remove all the observers from the list. */
   public void removeObservers()
   { /*1*/  
   } /*1*/

   /** Notify each of the observers on the list that something has happened
    * to the object they are observing.  
    * @param theObserved The object that changed.
    * @param changeInfo Additional information about what changed.  May be
    * <code>null</code>. */
   public void notifyObservers(Object theObserved, Object changeInfo)
   { /*1*/     
       
            
          
      
   } /*1*/
} /*0*/
