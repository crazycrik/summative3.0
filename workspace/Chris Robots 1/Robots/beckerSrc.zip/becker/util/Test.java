/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


/** Methods to assist in testing code.  Example usage:
 * <pre>public static void main(String[] args)
 * {  Patron p = new Patron(1001);
 *    Test.ckEquals("patron ID#", 1001, p.getID());
 * }
 * </pre>
 * Each method prints a message on the console indicating whether the test
 * passed or failed and what the expected and actual values were compared.
 *
 * @author Byron Weber Becker */
public class Test extends Object
{ /*0*/

   /** The default value for testing doubles for equality.  If the absolute
    value of the difference is less than EPSILON, they are deemed to be the
    'same'. */
   public static final double EPSILON = 0.000001;
        

	/** An instance may be created, but is not required as all the methods are
	 * declared static.  This is here to enable using the class before class
	 * methods are covered. */
   public Test()
   { /*1*/	
   } /*1*/

   /** Check two integers for equality.  Print a message indicating whether
    the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test
    @param actual the value actually obtained for this test */
   public static void ckEquals(String idString, int expected, int actual)
   { /*1*/           
   } /*1*/

   /** Check two doubles for equality within a specified tolerance.
    Print a message indicating whether the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test
    @param actual the value actually obtained for this test
    @param epsilon the value by which the two doubles are allowed to deviate */
   public static void ckEquals(String idString, double expected, double actual, double epsilon)
   { /*1*/       
                 
   } /*1*/

   /** Check two doubles for equality, using EPSILON as a tolerance.
    Print a message indicating whether the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test
    @param actual the value actually obtained for this test */
   public static void ckEquals(String idString, double expected, double actual)
   { /*1*/     
   } /*1*/

   /** Check two booleans for equality.  Print a message indicating whether
    the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test
    @param actual the value actually obtained for this test */
   public static void ckEquals(String idString, boolean expected, boolean actual)
   { /*1*/           
   } /*1*/

   /** Check two characters for equality.  Print a message indicating whether
    the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test
    @param actual the value actually obtained for this test */
   public static void ckEquals(String idString, char expected, char actual)
   { /*1*/           
   } /*1*/

   /** Check two strings for equality.  Print a message indicating whether
    the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test
    @param actual the value actually obtained for this test */
   public static void ckEquals(String idString, String expected, String actual)
   { /*1*/          
             
            
   } /*1*/

   /** Check two strings for equality, ignoring any differences in case.
    Print a message indicating whether the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test
    @param actual the value actually obtained for this test */
   public static void ckEqualsIgnoreCase(String idString, String expected, String actual)
   { /*1*/        
             
            
            
            
   } /*1*/

   /** Check two Objects for equality using the .equals method.
    Print a message indicating whether the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test (not null)
    @param actual the value actually obtained for this test (not null) */
   public static void ckEquals(String idString, Object expected, Object actual)
   { /*1*/         
           
               
          
                     
        
                  
                       
      
   } /*1*/

   /** Check that two Objects are identical using ==.
    Print a message indicating whether the test passed or failed.
    @param idString a string identifying this test
    @param expected the value expected for this test (not null)
    @param actual the value actually obtained for this test (not null) */
   public static void ckIdentical(String idString, Object expected, Object actual)
   { /*1*/            
                  
   } /*1*/

   /** Check an integer is between a given minimum and maximum.
    * Print a message indicating whether the test passed or failed.
    * @param idString a string identifying this test
    * @param minExpected the smallest expected value
    * @param actual the actual value obtained for the test
    * @param maxExpected the largest expected value */
   public static void ckIsBetween(String idString, int minExpected, int actual, int maxExpected)
   { /*1*/         
             
       
        
           
      
                 
                   
   } /*1*/
	
   /** Check that a double is between a given minimum and maximum.
    * Print a message indicating whether the test passed or failed.
    * @param idString a string identifying this test
    * @param minExpected the smallest expected value
    * @param actual the actual value obtained for the test
    * @param maxExpected the largest expected value */
   public static void ckIsBetween(String idString, double minExpected, double actual, double maxExpected)
   { /*1*/         
             
       
        
           
      
                 
                   
   } /*1*/
	
   /** Check that a char is between a given minimum and maximum.
    * Print a message indicating whether the test passed or failed.
    * @param idString a string identifying this test
    * @param minExpected the smallest expected value
    * @param actual the actual value obtained for the test
    * @param maxExpected the largest expected value */
   public static void ckIsBetween(String idString, char minExpected, char actual, char maxExpected)
   { /*1*/         
             
       
        
           
      
                 
                   
   } /*1*/
	
   /** Check that a String is between a given minimum and maximum.
    * Print a message indicating whether the test passed or failed.
    * @param idString a string identifying this test
    * @param minExpected the smallest expected value
    * @param actual the actual value obtained for the test
    * @param maxExpected the largest expected value */
   public static void ckIsBetween(String idString, String minExpected, String actual, String maxExpected)
   { /*1*/     
               
             
       
        
           
      
                 
                   
   } /*1*/
	
   /** Check that a value is null.  Print a message indicating whether
    the test passed or failed.
    @param idString a string identifying this test
    @param actual the value actually obtained for this test */
   public static void ckIsNull(String idString, Object actual)
   { /*1*/         
   } /*1*/

   /** Check that a value is not null.  Print a message indicating whether
    the test passed or failed.
    @param idString a string identifying this test
    @param actual the value actually obtained for this test */
   public static void ckIsNotNull(String idString, Object actual)
   { /*1*/     
            
       
           
             	
                 
      
   } /*1*/
   
   /** Indicate that a test failed.
    * @param idString a string identifying this test */
   public static void fail(String idString)
   { /*1*/  
          
   } /*1*/
   
   /** Indicate that a test passed.
    * @param idString a string identifying this test */
   public static void pass(String idString)
   { /*1*/         
   } /*1*/

   /** Get the number of errors found in this program.
    @return the number of errors */
   public static int getNumErrors()
   { /*1*/   
   } /*1*/

   
   
                   
                        
       
        
                 
                        
      
   

   /** Replace common control characters with printable representations */
   
      
          
          
          
       
   

   
     
         
           
               
         
         
      
       
   
} /*0*/
