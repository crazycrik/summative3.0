/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


/** A class implementing <code>IObserver</code> is usually registered with
 * a class implementing {@link IObservable}.  Each time the <code>IObservable</code>
 * object changes its state, the <code>update</code> method of each registered 
 * observer is called so that the observer can react to the change.
 *
 * <p>The intent of <code>IObserver</code> is similar to that of 
 * <code>java.util.Observer</code>.  However, <code>Observer</code> requires
 * that the <code>update</code> method be passed an object extending 
 * <code>java.util.Observable</code> -- something that can't be done if the
 * observed object must extend another superclass.</p>
 *
 * @see IObservable
 * @see Observers
 *
 * @author Byron Weber Becker */
  
{ /*0*/

   /** Update the this observer after an <code>IObservable</code> it is
    * registered with has changed.
    * @param theObserved The object that changed.
    * @param changeInfo Optional information about what it was that changed.
    *  May be <code>null</code>. */
        
} /*0*/
