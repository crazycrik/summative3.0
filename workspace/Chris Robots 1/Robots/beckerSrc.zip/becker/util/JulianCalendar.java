package becker.util;


 
 


/**
 * This Calendar provides Julian Day and "Calendar Day" methods,
 * The Calendar Day starts at _local_ midnight.
 * 
 * Code from http://java.sun.com/people/linden/faq_b2.html#Date
 * 
 * @author Paul A. Hill
 * @version 1.1
 * @since JDK 1.1.7 3/99
 * @see java.util.Calendar
 */

    

   /**
    ** this constant and the ones that follow are actually private
    ** in the GregorianCalendar, so we'll redefine them here.
    **/
   public static final long
         ONE_SECOND = 1000,
         ONE_MINUTE = ONE_SECOND * 60,
         ONE_HOUR = ONE_MINUTE * 60;

   /**
    * this next constant and the others with it have their uses,
    * but watch out for DST days and the weeks that contain them.
    * Note also that 1/1/1970 doesn't start on the first day of the week.
    */
   


        
   /** The number of days from Jan 1, 4713 BC (Proleptic Julian)
    ** to 1/1/1970 AD (Gregorian).  1/1/1970 is time 0 for a java.util.Date.
    **/
   public static final long JULIAN_DAY_OFFSET = 2440588L;
        
   /**
    * Same as GregorianCalendar(). Creates a calendar with the time set to 
    * the moment it was created.
    * 
    * @see java.util.GregorianCalendar#GregorianCalendar
    */
   
  
   
   
   
       
   
        
   /**
    * A calendar day as defined here, is like the Julian Day but it starts
    * and ends at _local_ 12 midnight, as defined by the timezone which is
    * attached to this calendar.  This value is useful for comparing
    * any date in the calendar to any other date to determine how many days
    * between them, i.e. tomorrow - today = 1
    * 
    * @return the calendar day (see above).
    * @see #getCalendarDay
    */
   
     
      
           
             
                    
               
            
   
    
   /**
    * Sets the date in the calendar to 00:00 (midnight) on the local calendar day.
    * See getCalendarDay for the definition of calendar day as used in this class.
    * 
    * @param calendarDay the day to set the calendar to.
    * @see #setCalendarDay
    * @see java.util.TimeZone#getRawOffset
    */
   
  
      
      
        
      
      
      
      
       
   
    
   /**
    * Finds the number of days after 12/31/4312 BC 24:00 GMT on a proleptic
    * Julian Calendar (i.e. extending the Julian Calendar into pre-history)
    * to the current time.
    * The Astronomer's Julian Day begins at noon.  The Julian Day used here
    * sometimes called the Chronologist's or Historian's Julian Day 
    * starts at midnight.  For more information see 
    * http://www.magnet.ch/serendipity/hermetic/cal_stud/jdn.htm#astronomical
    * Note: This routine does NOT take into consideration 
    * leap seconds.
    * 
    * @return the day number of the current time from 1/
    * @see #getCalendarDay
    */     
   
      
   
    
   /**
    * Sets the current date contained in this calendar to exactly
    * 00:00 GMT on the date defined by the Julian Day provided.
    * 
    * @param julianDay the Julian Day to set the calendar to
    * @see #setCalendarDay
    */
     
   
              
   
        
   /**
    * This is a utility routine for rounding (toward negative) to the nearest
    * multiple of the conversion factor.
    * BUG? Why is this different than the formula given in 
    * java.util.GregorianCalendar private millisToJulianDay?
    * 
    * @param conversion typically one of the constants defined 
    * above ONE_MINUTE, ONE_DAY etc.
    * @param fractions the value to convert expressed in the same units 
    * as the conversion factor (i.e milliseconds).
    *
    * @return the value divided by the conversion factor, rounded to the negative.
    * @see java.util.Calendar
    */
      
   
        
      
      
      
      
        
         
            
       
                
              
       
       
 
