/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


 
 


/** Classes implementing <code>IModel</code> have a standard protocol for 
 *  adding views (such as a graphical user interfaces). 
 *  
 *  <p>A program with a graphical user interface is typically composed of a 
 *  <i>model</i> and one or more <i>views</i>.  The model provides an abstraction of
 *  the problem to be solved while a views shows a particular representation
 *  (often graphical) of the model.  Often there are several different views
 *  of the model.  When the model changes, all of the views should be notified
 *  so they can update the information they display.</p>
 *  
 *  <p>At least one of the classes modeling the problem should implement the
 *  <code>IModel</code> interface to provide a standard protocol for adding or
 *  removing a view.</p>
 *  
 *  <p>The minimal class implementing <code>IModel</code> is:</p>
 *  <pre>
 *   class MyModel extends Object implements IModel
 *   {
 *      private ArrayList<IView> views = new ArrayList<IView>();
 *      
 *      public MyModel()
 *      {   super();
 *      }
 *     
 *     public void addView(IView aView)
 *     {   this.views.add(aView);
 *     }
 *     
 *     public void removeView(IView aView)
 *     {   this.views.remove(aView);
 *     }
 *     
 *     public void updateAllViews()
 *     {  for(IView v : this.views)
 *        {  v.updateView();
 *        }
 *     }
 *  }   
 *  </pre> 
 *  
 *  <p>The combination of <code>IModel</code> and {@link IView} is a simplification
 *  of the classic Observer pattern.  {@link IObservable}, {@link IObserver}
 *  and {@link Observers} may be used to implement that pattern without 
 *  simplification.</p>
 *
 *  <p>Classes may also extend {@link AbstractModel}, which provides an 
 *  implementation of this interface.</p>
 *  
 *  @see IView
 *  @see AbstractModel
 *  
 *  @author Byron Weber Becker   */
  
{ /*0*/

   /** Add a view to a list of views.  Each view is notified each 
    time an event occurs that changes the state of the model.
    @param aView The view to add.   */
      

   /** Remove a specific view from the list of views. 
    @param aView The view to remove.   */
      
   
   /** Update all the views that have been added to this model. */
     
} /*0*/

