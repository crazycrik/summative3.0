/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


 
 


/** An instance of <code>ViewList</code> is usually used by a class implementing
 * the model part of a model-view-controller to store its list of views.  Each time the
 * object's state changes, it should call <code>updateAllViews</code>.  This, in turn,
 * calls the <code>updateView</code> method for each of the views stored in
 * the list.
 *
 * @see IView
 *
 * @author Byron Weber Becker */
public class ViewList extends Object implements IModel
{ /*0*/
        

   /** Construct a new list of Views. */
   public ViewList()
   { /*1*/  
   } /*1*/

   /** Add another View to the list.
    * @param aView The View to add. */
   public void addView(IView aView)
   { /*1*/  
   } /*1*/

   /** Remove a specific view from the list.
    * @param aView The view to remove. */
   public void removeView(IView aView)
   { /*1*/  
   } /*1*/

   /** Remove all the views from the list. */
   public void removeViews()
   { /*1*/  
   } /*1*/

   /** Notify each of the views on the list that something has happened
    * to the object they are viewing.  */
   public void updateAllViews()
   { /*1*/     
   		
   	
   } /*1*/
} /*0*/
