/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


 
 
 
 
 
 
 
 
 


/** A class to represent an instant in time that is simpler to use than either
 * Date or GregorianCalendar.
 *
 * @author Byron Weber Becker */
public class DateTime extends Object implements Cloneable, Comparable
{ /*0*/
     
   








































       
       

   /** Cause format(...) to use a short format. */
   public static final int SHORT = DateFormat.SHORT;

   /** Cause format(...) to use a medium-length format. */
   public static final int MEDIUM = DateFormat.MEDIUM;

   /** Cause format(...) to use a long format. */
   public static final int LONG = DateFormat.LONG;

   /** Cause format(...) to return the date only. */
   public static final int DATE_ONLY = 123;	

   /** Cause format(...) to return the time only. */
   public static final int TIME_ONLY = 124;	

   /** Cause format(...) to return the date and time. */
   public static final int DATE_AND_TIME = 125;	

         
         
	
   /** Construct a new date object representing the current instant in time. */
   public DateTime()
   { /*1*/  
         
      
   } /*1*/
	
   /** Construct a new date object representing the given year, month, and day.
    * @param year The year {e.g. 2003}
    * @param month The month in the range 1..12
    * @param day The day in the range 1..31 */
   public DateTime(int year, int month, int day)
   { /*1*/       
   } /*1*/
	
   /** Construct a new date object representing the given year, month, and day.
    * @param year The year {e.g. 2003}
    * @param month The month in the range 1..12
    * @param day The day in the range 1..31 
    * @param hours The hour in the range 0..23 
    * @param minutes The minutes in the range 0..59
    * @param seconds The seconds in the range 0..59 */
   public DateTime(int year, int month, int day, int hours, int minutes, int seconds)
   { /*1*/  
   	        
      
      	
   } /*1*/
	




























   /** Read a date from <code>in</code>, leaving the file cursor immediately 
    * after the date.  The date (and optional time) must be in one of the
    * two formats produced by <code>toString</code>.
    * @param in The open file from which to read the date. */
   public DateTime(Scanner in)
   { /*1*/  
   
      
      
      
		
         
         
         
         
         
         
		
       
        
            
           
           
           		
           
           
           
         
      	
            
           
           
           		
      
   		
              
      
      	
   } /*1*/

   /** Construct a new DateTime object that represents the same date as <code>dt</code>.
    * @param dt The DateTime object to duplicate. */
   public DateTime(DateTime dt)
   { /*1*/     
             
   } /*1*/
   
   /** Get an instance representing today (time fields set to midnight).
    * @return an instance representing today */
   public static DateTime getTodayInstance()
   { /*1*/      
      
      
      
		
       
   } /*1*/
  
   /** Get an instance representing the current date and time.
    * @return an instance representing this moment */
   public static DateTime getNowInstance()
   { /*1*/    
   } /*1*/
 
   /** Compare two DateTime objects.
    * @param dt A DateTime object to compare to this object.  It must be a DateTime
    *           object in spite of the fact that the parameter has type Object.
    * @return -1 if this object represents a date & time before dt,
    *          +1 if this object represents a date & time after dt,
    *          and 0 if they represent the same time. */
   public int compareTo(Object dt)
   { /*1*/     
               
      
          
       
         
         
         
       
         
      
   } /*1*/
   
   
	
   /** Format the date and/or time as a string.
    * @param length One of DateTime.{SHORT, MEDIUM, LONG}
    * @param dateTime One of DateTime.{DATE_ONLY, TIME_ONLY, DATE_AND_TIME}
    * @return an appropriately formatted string. */
/*   public String format(int length, int dateTime)
   {  DateFormat f;
      if (dateTime == DateTime.DATE_AND_TIME)
      {  f = DateFormat.getDateTimeInstance(length, length);
      } else if (dateTime == DateTime.TIME_ONLY)
      {  f = DateFormat.getTimeInstance(length);
      } else if (dateTime == DateTime.DATE_ONLY)
      {  f = DateFormat.getDateInstance(length);
      } else
      {  throw new IllegalArgumentException("dateTime = " + dateTime);
      }
      return f.format(this.c.getTime());	
   }
*/

	/** Set the length of the string returned by format().
	 * @param formatLength One of DateTime.{SHORT, MEDIUM, LONG} */
	public void setFormatLength(int formatLength)
   { /*1*/             
          
       
          
      
   } /*1*/
	
	/** Set the data to include in the string returned by format().
	 * @param formatInclude One of DateTime.{DATE_ONLY, TIME_ONLY, DATE_AND_TIME} */
	public void setFormatInclude(int formatInclude)
	{ /*1*/	           
	       
	    
	       
	   
	} /*1*/
	
	/** Format the date and/or time as a string according to the current
	 * settings established by {@link #setFormatInclude setFormatInclude} 
	 * and {@link #setFormatLength setFormatLength}.
	 *
	 * <blockquote>Examples:
    *  <table border="1" CELLPADDING="2">
    *    <tr><th>Length</th><th>Include</th><th>Format</th></tr>
    *    <tr><td>SHORT</td><td>DATE_AND_TIME</td><td>3/27/08 1:15 PM</td></tr>
    *    <tr><td>SHORT</td><td>DATE_ONLY</td><td>3/27/08</td></tr>
    *    <tr><td>SHORT</td><td>TIME_ONLY</td><td>1:15 PM</td></tr>
    *
    *    <tr><td>MEDIUM</td><td>DATE_AND_TIME</td><td>Mar 27, 2008 1:15:15 PM</td></tr>
    *    <tr><td>MEDIUM</td><td>DATE_ONLY</td><td>Mar 27, 2008</td></tr>
    *    <tr><td>MEDIUM</td><td>TIME_ONLY</td><td>1:15:15 PM</td></tr>
    *
    *    <tr><td>LONG</td><td>DATE_AND_TIME</td><td>March 27, 2008 1:15:15 PM EST</td></tr>
    *    <tr><td>LONG</td><td>DATE_ONLY</td><td>March 27, 2008</td></tr>
    *    <tr><td>LONG</td><td>TIME_ONLY</td><td>1:15:15 PM EST</td></tr>
    *  </table>
	 * </blockquote>
	 */
	public String format()
	{ /*1*/	   
         
           
           
          
           
          
       
         
      
       	
	} /*1*/
	
   /** Represent this date (and time, if the time is not midnight) as a string.
    * Example formats:  2003/3/27 and 2003/3/27@10:05:30
    * @return A string representing this date and time. */
   public String toString()
   { /*1*/     
                 
               
		
         
         
         
		
                 
                     
                      
                     
      
				
       
   } /*1*/
		
   /** Get the year. 
    * @return The year */
   public int getYear()
   { /*1*/   
   } /*1*/
		
   /** Get the month. 
    * @return The month, one of {1..12} */
   public int getMonth()
   { /*1*/     
   } /*1*/
		
   /** Get the day. 
    * @return The day, one of {1..31} */
   public int getDay()
   { /*1*/   
   } /*1*/
		
   /** Get the hour. 
    * @return The hour, one of {0..23} */
   public int getHour()
   { /*1*/   
   } /*1*/
		
   /** Get the minute. 
    * @return The minute, one of {0..59} */
   public int getMinute()
   { /*1*/   
   } /*1*/
		
   /** Get the second. 
    * @return The second, one of {0..59} */
   public int getSecond()
   { /*1*/   
   } /*1*/
	
   /** Add (or subtract, if negative) years from this DateTime.
    * @param howMany The number of years to add or subtract. */
   public void addYears(int howMany)
   { /*1*/   
   } /*1*/
	
   /** Add (or subtract, if negative) months from this DateTime.
    * @param howMany The number of months to add or subtract. */
   public void addMonths(int howMany)
   { /*1*/   
   } /*1*/
	
   /** Add (or subtract, if negative) days from this DateTime.
    * @param howMany The number of days to add or subtract. */
   public void addDays(int howMany)
   { /*1*/   
   } /*1*/
	
   /** Add (or subtract, if negative) hours from this DateTime.
    * @param howMany The number of hours to add or subtract. */
   public void addHours(int howMany)
   { /*1*/   
   } /*1*/
	
   /** Add (or subtract, if negative) minutes from this DateTime.
    * @param howMany The number of minutes to add or subtract. */
   public void addMinutes(int howMany)
   { /*1*/   
   } /*1*/
	
   /** Add (or subtract, if negative) seconds from this DateTime.
    * @param howMany The number of seconds to add or subtract. */
   public void addSeconds(int howMany)
   { /*1*/   
   } /*1*/

   /** Set the year for this to the given year
    * @param year the new year for this */
   public void setYear(int year)
   { /*1*/   
       
   } /*1*/
    
   /** Set the month for this to the given month
    * @param month the new month for this */
   public void setMonth(int month)
   { /*1*/   
       
   } /*1*/

   /** Set the day for this to the given day
    * @param day the new day for this */
   public void setDay(int day)
   { /*1*/   
       
   } /*1*/

   /** Set the hour for this to the given hour
    * @param hour the new hour for this */
   public void setHour(int hour)
   { /*1*/   
       
   } /*1*/

   /** Set the minute for this to the given minute
    * @param minute the new minute for this */
   public void setMinute(int minute)
   { /*1*/   
       
   } /*1*/

   /** Set the second for this to the given second
    * @param second the new second for this */
   public void setSecond(int second)
   { /*1*/   
       
   } /*1*/

   /** Set the time for this to the given hour, minute and second.
    * @param hour The new hour
    * @param min The new minute
    * @param sec The new second */
   public void setTime(int hour, int min, int sec)
   { /*1*/  
      
      
   } /*1*/
  
   /** Determine whether this Date/Time is before another.
    * @param other The other DateTime to compare against
    * @return true if this DateTime represents a date & time earlier than <code>other</code>. */
   public boolean isBefore(DateTime other)
   { /*1*/   
   } /*1*/
		
   /** Determine whether this Date/Time is after another.
    * @param other The other DateTime to compare against
    * @return true if this DateTime represents a date & time later than <code>other</code>. */
   public boolean isAfter(DateTime other)
   { /*1*/   
   } /*1*/
	
   /** Determine whether this Date/Time is equal to another.
    * @param other The other DateTime to compare against
    * @return true if this DateTime represents a date and time equal to <code>other</code> */
   public boolean equals(Object other)
   { /*1*/     
            
          
      
       
   } /*1*/ 
	
   /** Clone this Date/Time object to produce another one, just like it.
    * @return a clone of this Date/Time object */
   public Object clone()
   { /*1*/    
   } /*1*/

   /** Returns a hash code for this object for use in <code>HashSet</code> and
    * related collections. */
   public int hashCode()
   { /*1*/   
   } /*1*/
	
   /** Calculate the number of days until another date.  If this 
    * date is before <code>another</code>, the result will be positive.  If
    * this date is after <code>another</code>, the result will be negative.
    * @param another A DateTime object.
    * @return The number of days between the two days. */
   public int daysUntil(DateTime another)
   { /*1*/     
         
         
   } /*1*/
  	
   /** Return an object that can be passed to an instance of DateFormat.  
    * For example,
    * <pre>DateTime today = new DateTime();
    * DateFormat df = DateFormat.getDateInstance();
    * df.format(today.getTime());
    * </pre>
    * @return an object compatible with DateFormat. 
    * @since June 11, 2004 */
   public Date getTime()
   { /*1*/   
   } /*1*/
} /*0*/
