/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


 
 
 


/** Useful utility methods.  Many of these are here to avoid exceptions
 * until we're ready to understand them.
 *
 * @author Byron Weber Becker */
public class Utilities
{ /*0*/

   /** Sleep (pause the program) for the specified number of milliseconds
    * (a millisecond is 1/1000 of a second -- to sleep for one second, pass
    * 1000 as a parameter).
    * @param milliseconds How many milliseconds to sleep. */
   public static void sleep(long milliseconds)
   { /*1*/  
        
         
      
      
   } /*1*/

   /** Construct a URL relative to the program's working directory.  For 
    * example, if the current working directory for the program (likely
    * the directory containing the program's class files) is "C:/myPrograms/"
    * then <code>getRelativeURL("ringin.wav")</code> returns 
    * "file:///C:/myPrograms/ringin.wav" and <code>getRelativeURL("../clips/ringin.wav")</code>
    * returns "file:///C:/clips/ringin.wav".
    * @param relativePath The relative path to the desired resource
    * @return a URL */
   public static URL getRelativeURL(String relativePath)
   { /*1*/     
      
       
                
             
         
          
          
        
         
          
          
        
         
          
      
   } /*1*/

} /*0*/
