package becker.util;

/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

 
 

/** An implementation of {@link IModel}.  Classes needing to implement 
 * <code>IModel</code> may extend this class to ease their implementation.
 *
 * @author Byron Weber Becker */
public class AbstractModel extends Object implements IModel
{ /*0*/	
	protected List<IView> views = new Vector<IView>();
	
	/** Create a new AbstractModel. */
	public AbstractModel()
	{ /*1*/	
	} /*1*/
	
   /** Add a view to a list of views.  Each view is notified each 
    time an event occurs that changes the state of the model.
    @param aView The view to add.   */
   public void addView(IView aView)
   { /*1*/	
   } /*1*/

   /** Remove a specific view from the list of views. 
    @param aView The view to remove.   */
   public void removeView(IView aView)
   { /*1*/	
   } /*1*/
   
   /** Update all the views that have been added to this model. */
   public void updateAllViews()
   { /*1*/	   
   		
   	
   } /*1*/

} /*0*/
