/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


/** Classes that are observed by others, as in the classic 
 * Model-View pattern, should implement the <code>IObservable</code>
 * interface.  The interface enforces a standard protocol for adding and
 * removing observers.
 *
 * <p>The intent of <code>IObservable</code> is similar to <code>java.util.Observable</code>,
 * however, to use <code>Observable</code> it must be extended.  If different superclass
 * is required, this is impossible.</p>
 *
 * @see IObserver
 * @see Observers
 *
 * @author Byron Weber Becker */
  
{ /*0*/

   /** Add an observer to a list of observers.  Observers are notified each 
    * time an event occurs that 
    * changes the state of the observable.
    * @param observer The observer to add. */
      

   /** Remove a specific observer from the list of observers. 
    * @param observer The observer to remove. */
      
   
   /** Remove all the observers from the list of observers. */
     
} /*0*/
