/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.util;


/** The <code>IView</code> interface provides a standard protocol for a 
 * <i>model</i> to notify a <i>view</i> of changes.  A model provides
 * an abstraction of the problem being solved;  a view provides a representation
 * of the model, often as a graphical user interface.
 *
 * <p>Views add themselves to models that implement the {@link IModel} 
 * interface.  The model, in turn, calls the <code>updateView</code> method 
 * whenever it changes.</p>
 *
 * <p>The combination of <code>IModel</code> and <code>IView</code> represent
 * a simplification of the classic Observer pattern.  It is not appropriate 
 * when a view is observing two or more different models or when model changes 
 * are complex and require extra information to be provided to the view.  In
 * those instances, use {@link IObserver} in place of <code>IView</code> 
 * and {@link IObservable} in place of <code>IModel</code>.
 *
 * @author Byron Weber Becker
 *
 */
  
{ /*0*/

   /** Update the view.  This method is generally called by the model whenever
    * it has changed state. */
     
} /*0*/
