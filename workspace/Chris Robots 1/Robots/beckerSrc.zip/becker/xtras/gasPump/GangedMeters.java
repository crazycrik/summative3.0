package becker.xtras.gasPump;


 
 
 

/** A gas pump typically has more than one meter, each for a different grade of
 * gas.  Put them all into a single object so we can easily manage which one is
 * active at a given time.  Implement the IMeter interface so we can treat the
 * entire group of meters as a single meter.  Notify the interface when 
 * something changes.
 *
 * @author Byron Weber Becker */

/* package */ 

     
     
   
       
   
        
	
	
   
   
	
   /* package */
  
        
   
	
   /* package */ 
   
   
	
   /* package */ 
   
   
	
   /* package */ 
   
   
	
   /* package */ 
    
   	
   
	
   
     
   		
   	
   	
   	
   
   	/*
   	this.views[this.numViews] = aView;
      this.numViews++;
      aView.updateView();
      */
   

   
    
   	   
   		
   	
   

   
  
        
   

   
   
   
	
   
   
   

   
   
   
   
   
   
   

   
   
   
   
   /* package */ 
   
   

