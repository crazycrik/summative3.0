package becker.xtras.gasPump;


 
 
 
 
 


/** A graphical user interface to simulate a gas pump.  It is designed to be 
 * used with three instances of a student-written class that implements
 * {@link IMeter}.
 *
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
public class GasPumpGUI extends Object
{ /*0*/
             
	
     
     
     
	
   /** Create a new graphical user interface for a gas pump.  A gas pump
    * requires three gas meters for three different octane levels:  low, 
    * medium, and high.
    *
    * @param lowOctane the meter for low octane gas (regular or bronze)
    * @param medOctane the meter for medium octane gas (premium or silver)
    * @param highOctane the meter for high octane gas (supreme or gold)
    * @param volumeUnit the unit of volume, such as Liter or Gallon
    */
   public GasPumpGUI(IMeter lowOctane, IMeter medOctane, IMeter highOctane, String volumeUnit)
   { /*1*/        
   } /*1*/
	
   
  
         
          
         
              
             
      
      
		
   
	
   
       
       
		
      
            
      
		
      
            
              
        
      
      
       
      
      
      
      
			
         
      		
      

      
      	
   
} /*0*/

