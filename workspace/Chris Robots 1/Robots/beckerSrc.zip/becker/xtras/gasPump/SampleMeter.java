package becker.xtras.gasPump;

 
 
 

/** A sample class implementing the {@link IMeter} interface.  It measures the 
 * volume of fuel sold and calculates the amount owed by the
 * customer, given the current fuel cost.
 *
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
  

     
       
     
     
   
        

	/** Construct a new fuel meter.
	 * @param unitCost The cost per unit volume of fuel.  For example, $2.85/gallon
	 * or $1.05/litre.
	 * @param octaneRating An integer related to the "performance" of the fuel;  usually 
	 * between 87 and 93.
	 * @param theLabel A label for the fuel such as "Gold" or "Ultra". */
   
  
        
        
        
   

   
    
   	
   
	
   
      
   	
   
	
   
   
   
	
   
   
   	
	
   
   
   
   
   
   
   
	
   
       
       
   
   
   
	
   
	
	/** Used to test the class. */
   
        
          
          
          
      
         
         
           
   	
   


