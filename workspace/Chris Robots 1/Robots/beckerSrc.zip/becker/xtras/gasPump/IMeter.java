package becker.xtras.gasPump;

 

/** Objects implementing IMeter are used to measure the volume of fuel 
 * delivered to a customer at a gas pump.  Such objects also know the current cost per
 * unit (liter or gallon) of fuel and can thus calculate the cost of the
 * fuel delivered.  For informational purposes, they also know the octane level
 * of the fuel and a marketing label such as "Gold" or "Ultra".
 *
 * <p>A typical gas pump will have three objects implementing <code>IMeter</code>,
 * one for each of the three different kinds of fuel available.</p>
 *
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
   
{ /*0*/
	
   /** Get the cost per unit of fuel.
    * @return cost per unit of fuel */
     
	
   /** Get the volume of fuel sold to this customer.
    * @return volume of fuel sold */
     
	
   /** Get the octane rating of the fuel.
    * @return octane rating (typically between 87 and 93) */
     
   
   /** Get the label for this meter's fuel.  For example, "Gold" or "Ultra".
    * @return this meter's fuel label */
     
	
   /** Reset the meter for a new customer. */
     
	
   /** Pump some fuel into a tank.  This method is called
    * repeatedly while the "handle" on the pump is pressed.
    * @param howMuch How much fuel was pumped since the last time this 
    * method was called. */
      
	
   /** Calculate the total cost of fuel sold to this customer.
    * @return price/unit * number of units sold */
     
   
   /** Add a view (graphical user interface) to the meter. The view's <code>updateView</code>
    * method must be called each time the meter's state changes. */
      
} /*0*/
