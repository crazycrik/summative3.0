package becker.xtras.marks;


 
 
 


/**
 * A sample class implementing the {@link IMarks} interface.  It maintains a
 * list of assignment marks for students and performs calculations on them.
 *
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker
 */
  
	
        
        
        
   
         
	
   
  
         
           
      
      
   
	
   
  
   
	
   
     
         
      
       
   

   
     
         
        
   
	
    
   
   

    
   
   

   
  
      
         
          
                    
               
      
      
      
   
	
   
  
         
           
                 	
      
   
	
     
      
              
                
             
         
      
       
   

    
         
   

    
          
   

   
     
       
         
         
         
         
         
       
              
      
   
	
   
     
         
              
          
      
          
   
	
   
     
         
              
           
             
         
      
       
   
	
   
     
         
              
           
             
         
      
       
   

   
     
       
         
           
         
       
              
      
   
	
   
     
         
              
          
      
          
   
	
   
     
         
         
           
         
       
           
            
            
             
              
         
                 
              
               
                
                 
                 
                
            
         
              
      
   
	
    
          
      
      
   
	
   
  
      

      
         
              
                
             
         
         
      
   
	
    
         
   
      
      
		
      
         
         
              
                
              
         
         
      
      
   
   
   /*
    private int randMark(double s)
    {	double r = s - Math.random() * .2 + Math.random() * .2;
    if (r > .80)
    {	return (int)(Math.random()*20 + 80);
    } else if (r > .55)
    {	return (int)(Math.random()*10 + 70);
    } else if (r > .25)
    {	return (int)(Math.random()*10 + 60);
    } else if (r > .10)
    {	return (int)(Math.random()*10 + 50);
    } else if (r > .04)
    {	return (int)(Math.random()*10 + 40);
    } else 
    {	return (int)(Math.random()*20 + 20);
    }	
    }
    */
   
      

      /*m.assignNames[0] = "A01";
       m.studentNames[0] = "Stu Dent";
       m.numAssigns = 1;
       m.numStudents = 1;
       m.marks[0][0] = 95;
       Test.ckEquals("get mark", 95, m.getMark("Stu Dent", "A01"));*/
		
         
      
		
        
        
      
      
         
           
      
      
      
         
           
        
          
        
          
		
   
	
   
      
          
         
         
        
         
          
         
         
        
         
          
         
         
        
         
   


