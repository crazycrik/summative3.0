package becker.xtras.marks;


 
 


/** A graphical user interface to display a "spreadsheet" recording student
 * assignment marks.  See the {@link becker.xtras.marks} package overview
 * for more details on what it looks like and how to use it.
 *
 * @author Byron Weber Becker */
public class MarksGUI extends Object
{ /*0*/
        
     
	
   /** Create a new graphical user interface (GUI) to display and edit
    * student marks using the an object provided by the student to store
    * the marks.  The GUI will display a border that says "Provided Marks Model".
    * @param marksModel the object that stores the marks */
   public MarksGUI(IMarks marksModel)
   { /*1*/   
          
      
   } /*1*/
	
   
  
        
      
		
      
        
         
        	
      

       
      		
   
	
   
      
       
        
        
      
   
} /*0*/
