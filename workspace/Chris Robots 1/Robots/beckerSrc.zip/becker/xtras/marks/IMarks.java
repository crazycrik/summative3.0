package becker.xtras.marks;


 


/** An interface to model a "spreadsheet" recording student assignment marks.
 *
 <H2>Implementation Hints</H2> 
 <UL>
 <LI>Start with a class that extends <CODE>Object</CODE> and implements 
 <CODE>IMarks</CODE>. Get it to compile by including stubs for each 
 method in the <CODE>IMarks</CODE> interface.  (A stub contains just 
 enough code to compile -- no more.  If
 the method has a <code>void</code> return type, the method's body
 will not contain any code.  If the method returns a string, then 
 include <code>return "dummy";</code> as the only line of code in
 the body.  A method returning an array of strings could contain 
 <code>return new String[0];</code>.) </LI>
 <LI>Write a <CODE>main</CODE>
 method as suggested in the {@link becker.xtras.marks} package documentation, 
 and debug the program so it runs without errors (but doesn't do
 much).  </LI>
 <LI>You will need three arrays: one to store student names, one to store
 assignment names, and one to store the marks. Make them big enough 
 to store 3 students and 2 assignments. Put data in them. Fix the methods 
 <CODE>getAssignmentNames</CODE>, <CODE>getStudentNames</CODE>, 
 <CODE>getMark</CODE>, and <CODE>setMark</CODE> so they do the right 
 thing. Test your program.</LI>
 <LI>Complete <CODE>saveFile</CODE>. Run the program to test it and use 
 it to create a file with the data you put in the arrays manually. 
 Complete <CODE>openFile</CODE> so that it reads the data from a 
 file into the arrays.</LI>
 <LI>Write the code for <CODE>addAssignment</CODE> and <CODE>addStudent</CODE>. 
 A complete solution will verify that the arrays have enough room for
 the new information, expanding the arrays as necessary.</LI>
 <LI>Create a new array of strings to store the names of the calculations
 you will perform for each assignment (e.g.: "Average", "Min", and "Max").
 Return this array in <CODE>getAssignmentCalculationNames</CODE>. Write 
 the method <CODE>performAssignmentCalculation</CODE>. It will typically 
 have a structure like this:
 <PRE>public int performAssignmentCalculation(String calcName, String assignmentName)
 *{  if (calcName.equals("Average"))
 *   {  // call a method to calculate the average for the given assignment
 *   } else if (calcName.equals("Min"))
 *   {  // call a method to calculate the minimum mark for the given assignment
 *   } else ...
 *}</PRE>When your calculations for each assignment are working, get the
 calculations for each student working in the same way. </LI>
 </UL>

 * @author Byron Weber Becker */
  
{ /*0*/

   /** Get a mark for a particular student and assignment.
    * @param studentName the name of the student
    * @param assignName the name of the assignment
    * @return the mark assigned to this student for this assignment */
        
	
   /** Set the mark for a particular student and assignment
    * @param studentName the name of the student
    * @param assignName the name of the assignment
    * @param mark the mark to be assigned to this student for this assignment */
          
	
   /** Get the names of all the assignments. 
    * @return the names of all the assignments */
     
	
   /** Get the names of the students.
    * @return the names of all the students. */
     
	
   /** Add a new assignment to the marks "spreadsheet."
    * @param name the name of the new assignment */
      
	
   /** Add a new student to the marks "spreadsheet."
    * @param name the name of the new student */
      
	
   /** Get the names of the calculations provided for assignments.  For example,
    * one might be "Average".  Then calling 
    * <code>performAssignmentCalculation("Average", 0)</code> would return the
    * average of all the marks for assignment 0.
    * @return the names of all the calculations provided for assignments */
     
	
   /** Get the names of the calculations provided for students.  For example,
    * one might be "Average Best Four Assignments".  Then calling 
    * <code>performStudentCalculation("Average Best Four Assignments", 5)</code> 
    * would (presumably) return the average of the best four marks for student 5.
    * @return the names of all the calculations provided for students */	
     
	
   /** Perform one of the calculations defined for assignments.
    * @param calcName one of the names returned by {@link #getAssignmentCalculationNames}
    * @param assignName the name of the assignment
    * @return the result of the calculation */
        
	
   /** Perform one of the calculations defined for students.
    * @param calcName one of the names returned by {@link #getStudentCalculationNames}
    * @param studentName the name of the student
    * @return the result of the calculation */
        
	
   /** Read the marks "spreadsheet" from a file.
    * @param fileName the name of the file to read
    */
   public void readFile(String fileName) t 
	
   /** Write the marks "spreadsheet" to a file.
    * @param fileName the name of the file */
   public void writeFile(String fileName) t 
   
} /*0*/
