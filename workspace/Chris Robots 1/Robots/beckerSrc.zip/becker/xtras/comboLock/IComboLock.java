package becker.xtras.comboLock;

 

/** <p>An interface for a combination lock object.  A combination lock is either
 * locked or unlocked.  If unlocked, it may be locked again with the 
 * <code>lock()</code> command.  If locked, it may be unlocked by specifying a
 * combination of three numbers with the <code>unlock</code> command.  Each 
 * combination lock has its own sequence of three numbers that will unlock it.
 * This sequence is specified when the lock is constructed.</p>
 * 
 * <img src="doc-files/lock.jpg">
 *
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
   
{ /*0*/	
	/** Test whether or not the lock is locked.
	 * @return true if the combination lock is currently locked; false otherwise. */
	  
	
	/** Attempt to unlock the combination lock, assuming it is currently locked.
	 * If the lock is already unlocked, calling this method has no effect.
	 * @param num1 The first number in the combination
	 * @param num2 The second number in the combination
	 * @param num3 The third number in the combination */
	       
	
	/** Lock the combination lock, assuming it is currently unlocked.  If it 
	 * is already locked, calling this method has no effect. */
	  
	
   
   /** Add a view (graphical user interface) to the lock. The view's <code>updateView</code>
    * method must be called each time the lock's state changes. */
      

} /*0*/
