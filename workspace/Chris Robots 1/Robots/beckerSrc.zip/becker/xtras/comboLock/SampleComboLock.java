package becker.xtras.comboLock;

 
 
 

/** A sample class implementing {@link IComboLock} interface.  It simulates
 * a combonation lock.
 *
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
  

   
    
   



     
{ /*0*/
	  
	  
	  
	    
	
	     
	
	/** Create a new combination lock with a specific combination.
	 * @param num1 The first number in the combination
	 * @param num2 The second number in the combination
	 * @param num3 The third number in the combination */
	      
	{ /*1*/	
		  
		  
		  
	} /*1*/
	
	public boolean isLocked()
	{ /*1*/	 
	} /*1*/
	
	public void lock()
	{ /*1*/	  
		
	} /*1*/
	
	public void unlock(int num1, int num2, int num3)
	{ /*1*/	 
			            
			
		
	} /*1*/
	
	public void addView(IView aView)
	{ /*1*/	
	} /*1*/
} /*0*/
