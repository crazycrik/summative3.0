package becker.xtras.comboLock;
 
 
 
 


/** A graphical user interface (GUI) for a combination lock.  It is designed to be
 * used with a student-written class that implements {@link IComboLock}.
 *
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
public class ComboLockGUI extends Object
{ /*0*/	      

	  
	     
	     
	     
	  
         
	
	/** Construct a user interface to display the state of a combination lock
	 * object.
	 * @param aLock the combination lock object to display. */
	public ComboLockGUI(IComboLock aLock)
	{ /*1*/	
		  
		   
		
		    
		 
		    
		    
		
		  
		  
		  
		      
	   	      
	   	
	   	
	   	
	   	
	   	
	   	   
	   	  
         
         
         
			  
	   	  
	   	  
	   	 
	   	
	   	  
	   	 
	 	
	   
	     
	   
	    
	    
	   	
	    
	   	
	   
	    
	   
	     
	     
	     
	     
	     
	    
		
		
		
			
         
      		
      
	    
	   
	} /*1*/
	
	public void updateView()
	{ /*1*/	
			 
					
			 
				
			
	} /*1*/
   
   
     
          
      
   
   
   
     
        
           
            
             
         
      
   
   
         
   { /*1*/
         
        
      
         
        
      
         
           
            
              
            
              
              
            
         
      
         
           
           
         
      
   } /*1*/
 
	    
	{ /*1*/	
		   
			 
				
								
								
			 
				
			      
			     
			      
			   
			
		
	} /*1*/
} /*0*/
