package becker.xtras.demos;

 

/** Run a demo for <code>becker.xtras.comboLock</code>.
 * @author Byron Weber Becker */
public class DemoComboLock extends Object
{ /*0*/
	
	

	
	
	/** Run a demo for <code>becker.xtras.comboLock</code>. */
	public static void main(String[] args) 
	{ /*1*/
		      
		    
	} /*1*/	
} /*0*/
