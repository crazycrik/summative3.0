package becker.xtras.demos;

 

/** Run a demo for <code>becker.xtras.radio</code>.
 * @author Byron Weber Becker */
public class DemoRadio extends Object
{ /*0*/
	
	

	
	
	/** Run a demo for <code>becker.xtras.radio</code>. */
   public static void main(String[] args)
   { /*1*/        
            
		
           
   } /*1*/
} /*0*/
