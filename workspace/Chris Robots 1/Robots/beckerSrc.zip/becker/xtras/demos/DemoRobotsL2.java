package becker.xtras.demos;


 


/** Demonstrate "level 2" robots:  extend a class, methods, control structures
 *
 * @author Byron Weber Becker */
public class DemoRobotsL2
{ /*0*/
   public static void main(String[] args)
   { /*1*/       
   	  
   
   	    
   		       
   		   
   			   
   		
   	
      
             
      

   } /*1*/
} /*0*/


/** A new kind of robot which can pick up a series of piles of things
 and make a histogram bar from each pile in the series.
 @author Arnie Dyck
 */



   /** Construct a new HistogramBot robot.
    *  @param aCity The city where the robot will be created.
    *  @param str The robot's initial street.
    *  @param ave The robot's initial avenue.
    *  @param dir The robot's initial direction, one of {Direction.NORTH, SOUTH, EAST, WEST}. */
   
     
   
   
   /** Constructs a histogram (bar chart) by picking up a pile of things
    *  and distributing them in a column
    */
   

       
        
         
         
      
   

   /** Distributes the things that it has collected one per intersection 
    */
   
     
        
         
       
   

   /* Moves to the start of the next bar */
   
  
      
      
   

   /* Moves back to the beginning of the bar it has just created */
   
   
        
      
   
   
   /* Turns and moves so that it is positionned at the beginning of the next bar */
   
  
      
      
   
   

