package becker.xtras.demos;

 


/*   
 * The idea for this assignment and some of the initial code is from "Teaching 
 * Two-Dimensional Array Concepts in Java With Image Processing Examples" by Kevin R. 
 * Burger in <i>SIGCSE Bulletin</i>, Volume 35, Number 1, March 2003, pages 205-209.
 */


/** Run a demo for <code>becker.xtras.imageTransformation</code>.
 *
 * @author    Michael DiBernardo, Byron Weber Becker
 */

public class DemoImageTransformation extends Object
{ /*0*/
   
   

	
   /** Run a demo for <code>becker.xtras.imageTransformation</code>.*/
   public static void main(String args[])
   { /*1*/      
          
   } /*1*/
} /*0*/
