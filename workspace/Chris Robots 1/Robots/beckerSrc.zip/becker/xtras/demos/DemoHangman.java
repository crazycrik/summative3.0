package becker.xtras.demos;

 


/** Run a demo for becker.xtras.hangman using sample code that 
 *  implements {@link IHangman}.
 *
 * <p>This class is implemented as follows where <code>SampleHangman</code> is 
 * a class implementing the <code>IHangman</code> interface:</p>
 * <blockquote><pre>
 * import becker.xtras.hangman.*;
 *
 * public class DemoHangman extends Object
 * {  public static void main(String[] args)
 *    {  IHangman model = new SampleHangman();
 *       HangmanGUI view = new HangmanGUI(model);
 *    }
 * }
 * </blockquote></pre>
 *
 * @author Byron Weber Becker */
public class DemoHangman extends Object
{ /*0*/

   /** Run a demo for <code>becker.xtras.hangman</code>. */
   public static void main(String[] args)
   { /*1*/      
          
   } /*1*/
} /*0*/
