package becker.xtras.demos;

 

/** Run a demo for <code>becker.xtras.marks</code>.
 * @author Byron Weber Becker */
public class DemoMarks extends Object
{ /*0*/
	
	

	
	
   public static void main(String[] args) 
   { /*1*/      		
          
   } /*1*/
} /*0*/
