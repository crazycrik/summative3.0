package becker.xtras.demos;

 


/** Run a demo for <code>becker.xtras.gasPump</code> using sample code that 
 * implements {@link IMeter}.
 *
 * <p>This class is implemented as follows where <code>SampleMeter</code> is
 * a class implementing the <code>IMeter</code> interface:</p>
<blockquote><pre>
public class DemoGasPump extends Object
{
   public static void main(String[] args) 
   {  SampleMeter silver = new SampleMeter(0.819, 87, "Silver");
      SampleMeter gold = new SampleMeter(0.899, 89, "Gold");
      SampleMeter platinum = new SampleMeter(0.959, 93, "Platinum");
   
      GasPumpGUI gui = new GasPumpGUI(silver, gold, platinum);
   }	
}
</pre></blockquote>
 *
 * @author Byron Weber Becker */
public class DemoGasPump extends Object
{ /*0*/
   
   

	
   /** Run a demo for <code>becker.xtras.gasPump</code>. */
   public static void main(String[] args) 
   { /*1*/        
            
            
   
   	       
   } /*1*/	
} /*0*/
