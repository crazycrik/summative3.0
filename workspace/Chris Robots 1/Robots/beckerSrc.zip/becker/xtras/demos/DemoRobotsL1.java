package becker.xtras.demos;

 

public class DemoRobotsL1
{ /*0*/
	public static void main(String[] args)
   { /*1*/      
   	  
   	       
   	    
   	    
   	    
   	    
   	   
   	   
   	   
   	   
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   	
   } /*1*/
} /*0*/
