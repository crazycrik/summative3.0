package becker.xtras.jotto;


 


/** <p>A Hint object is used to specify one kind of hint to a Jotto player.
 * Hint must be extended to provide a method named {@link #isOK(Word w)} and 
 * another named {@link #getHintWords(int maxDesired, IHintData hintData)}.
 *
 * The <code>getHintWords</code> method is called to generate the words for
 * the hint.  It likely gets the list of known words from hintData and passes
 * itself to the {@link IWordList#getWords(IWordPredicate p)} method.  Passing
 * itself to <code>getWords</code> works because <code>Hint</code> implements
 * <code>IWordPredicate</code> via the <code>isOK</code> method.
 * This method is used to determine 
 * whether or not a given {@link becker.xtras.jotto.Word} is appropriate
 * to include in the answer.  
 *
 *
 * <p>For example, the following subclass of Hint could be used to show the 
 * user words that contain a specified letter.</p>
 *
 * <blockquote><pre>
 * public class HintContainsLetter extends Hint
 * {  private char letter;
 *
 *    public HintContainsLetter()
 *    {  super("containing the letter", Hint.LETTER);
 *    }
 * 
 *    public Word[] getHintWords(int maxDesired, IHintData hintData)
 *    {  this.letter = hintData.getLetter();
 *       return hintData.getKnownWords().getWords(maxDesired, this);
 *    }
 *
 *    public boolean isOK(Word w)
 *    {  return w.getWord().indexOf(this.letter) >= 0;
 *    }
 * }
 * </pre></blockquote>
 * 
 * <p>Note that <code>Hint</code> implements {@link IWordPredicate}, implying
 * that all subclasses will also implement that interface whether or not they
 * include the phrase "implements IWordPredicate".</p>
 *
 * <p><code>Hint</code> objects are added to the program using the 
 * {@link JottoModel#addHint(Hint)} method in <code>JottoModel</code>.  This
 * method adds the hint to a list of hints which will be displayed in 
 * the user interface.
 * When the user requests a hint, the program:
 *   <ol><li>obtains the corresponding <code>Hint</code> object from the list.</li>
 *       <li>constructs an object implementing <code>IHintData</code> from which
 *           the hint can retrieve the data it needs.</li>
 *       <li>calls <code>getHintWords</code>, passing the <code>IHintData</code>
 *           object as a parameter.
 *       <li>displays words returned by <code>getHintWords</code> to the user.</li>
 *    </ol>
 *
 * @author Byron Weber Becker */
public abstract class Hint extends Object implements IWordPredicate
{ /*0*/
         
	
   /** The hint requires a single letter to determine if a word should be included. */
   public static final int LETTER = 0;

   /** The hint requires an array of letters to determine if a word should be included. */
   public static final int LETTERS = 1;

   /** The hint requires an array the user's previous guesses to determine if a word should be included. */
   public static final int GUESSES = 2;

   /** The hint requires no extra information to determine if a word should be included. */
   public static final int NONE = 3;

   /** The hint requires a word difficulty level to determine if a word should be included. */
   public static final int DIFFICULTY = 4;
	
         
	
      
      
	
   /** Construct a hint object. 
    * @param aDescription The description of the hint that will be displayed
    * in the user interface.  This string is returned by {@link #getDescription()}.
    * The user interface will append it to the end of "A word " or "All words ".
    *
    * @param argType The type of argument required by this hint.  Must be
    * one of {LETTER, LETTERS, GUESSES, DIFFICULTY, NONE}.  The value is returned by 
    * {@link #getArgumentType()} and determines which version of <code>setArgument</code>
    * is called. 
    */
   public Hint(String aDescription, int argType)
   { /*1*/  
             
          
                    
                          
      
	
        
        
   } /*1*/
	
   /** Get the description for this hint as given to the constructor.
    * @return the description passed to the constructor */
   public final String getDescription()
   { /*1*/   
   } /*1*/
	
   /** Get the argument type for this hint, as given to the constructor.
    * @return the argument type passed to the constructor */
   public final int getArgumentType()
   { /*1*/   
   } /*1*/
	
   /** Override this method to specify whether or not the Word w is an
    * acceptable answer for this hint. 
    * @param w The word to test.
    * @return true if the word should be included in the hint's answer;  false 
    * otherwise. */
       
	
   /** Get the words to display as the hint.
    * @return the words in the list of known words that satisfies the isOK method. */
         

   public static void main(String[] args)
   { /*1*/       
         
            
         
            
         
            
         
            
         
            
	
           
         
        
				
      
              
               
         
           
      
				
      
            
               
         
           
      
   } /*1*/
	
        
   { /*1*/
         
         
      
		
         
         
      
		
           
         
      
   } /*1*/
	
} /*0*/
