
package becker.xtras.jotto;


/** Evaluate a guess made by the user against the target word.  That is,
 * count the number of partial matches and exact matches.  See the 
 * package <a src="overview.html">overview</a> for more information about 
 * matches.
 * 
 * <p>Hints:  
 * <ul><li>Choose two non-alphabetic characters, say '*' and '-'.  Make a 
 * copy of the two words to compare.  Substitute '*' for each exact match,
 * effectively preventing another match with that character.  Then substitute
 * '-' for each partial.  Finally, count the number of occurrences of each
 * character.</li>
 * <li>This problem is tricky!</li>
 * </ul> 
 * </p>
 *
 * @author Byron Weber Becker */
  
{ /*0*/	

   /** Count the number of exact and partial matches in a pair of words.
    * @param word1 one of the words to compare
    * @param word2 the other word to compare
    * @return an object containing the number of exact and partial matches */
        

} /*0*/
