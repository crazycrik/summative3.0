package becker.xtras.jotto;


/** Provide a hint consisting of words that are consistent with all previous
 * guesses by the user.  That is, suppose a word under consideration,
 * <i>w</i> actually were the target.  Would all the previous guesses give 
 * the same number of partial and exact matches when compared against <i>w</i>
 * as they did when they were compared against the target?
 *
 * <p>The Hint object will need to be constructed with a list of known words
 * and an evaluator object. </p>
 *
 * @author Byron Weber Becker */
public class SampleHintConsistentWithGuesses extends Hint
{ /*0*/
     
     
	
   public SampleHintConsistentWithGuesses(IGuessEvaluator eval)
   { /*1*/      
        
   } /*1*/
	
   public boolean isOK(Word w)
   { /*1*/     
              
           
            
         
             
                
            
         
      
       
   } /*1*/
	
   public void setArgument(Guess[] guesses)
   { /*1*/    
   } /*1*/
   
    
    
        
   
} /*0*/
