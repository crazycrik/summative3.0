
package becker.xtras.jotto;


/** MatchCount objects report how many exact and partial matches are 
 * contained in a pair of words.  It is used by <code>IGuessEvaluator</code>
 * so that a single method can return "multiple" values.
 *
 * @author Byron Weber Becker */
public class MatchCount
{ /*0*/
	
       
       
	
   /** Construct a new MatchCount object to report the number of exact and 
    * partial matches in two words.
    * @param numExact The number of exact matches.  
    *		(0 <= numExact <= JottoModel.NUM_LETTERS) and 
    *		(numExact + numPartial <= JottoModel.NUM_LETTERS)
    * @param numPartial The number of partial matches.  
    *		(0 <= numPartial <= JottoModel.NUM_LETTERS) */
   public MatchCount(int numExact, int numPartial) 
   { /*1*/  
             
          
                          
                  
      
             
          
                          
                  
      
           
          
                           
                         
                
      
   	
        
        
   } /*1*/	
   
   /** Get the number of exact matches between the two words.
    * @return the number of exact matches */
   public int getExact()
   { /*1*/   
   } /*1*/
   
   /** Get the number of partial matches between the two words.
    * @return the number of partial matches */   
   public int getPartial()
   { /*1*/   
   } /*1*/
} /*0*/
