package becker.xtras.jotto;


/** Provide a hint consisting of words that contain all of the letters
 * specified by the user.
 *
 * @author Byron Weber Becker */
public class SampleHintWithAllLetters extends Hint
{ /*0*/
     

   public SampleHintWithAllLetters()
   { /*1*/      
   } /*1*/
	
   public boolean isOK(Word w)
   { /*1*/     
              
           
            
         
      
       
   } /*1*/
   
    
    
        
   
} /*0*/	

