
package becker.xtras.jotto;


/** Get the data needed by the hint classes to generate the hints.
 *
 * @author Byron Weber Becker */
  
{ /*0*/

   /** Get the letter specified by the user for the hint.  For example,
    * a hint that returns all the words containing a given letter would call
    * this method to get the letter the words should contain. 
    * @return a letter, probably entered by the user */
     
	
   /** Get the letters specified by the user for the hint.  For example,
    * a hint that returns all the words containing at least 3 of a set of
    * letters would call this method to get the letters the words should contain. 
    * @return a filled array of letters, probably entered by the user */
     
	
   /** Get the history of guesses made by the user to use in processing hints.
    * @return the user's history of guesses. */
     
	
   /** Get the list of words known to the game.  The hint words will be a
    * subset of this list. 
    * @return the words known to the game */
     
	
} /*0*/
