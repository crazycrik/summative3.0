package becker.xtras.jotto;


/** Provide a hint consisting of words that contain some of the letters
 * specified by the user.
 *
 * @author Byron Weber Becker */
public class SampleHintWithSomeLetters extends Hint
{ /*0*/
     
     

   /** Construct the int object.
    * @param numLetters The minimum number of letters from the set specified by the
    * user that must be contained in the word. */
   public SampleHintWithSomeLetters(int numLetters)
   { /*1*/           
        
   } /*1*/
		
   public boolean isOK(Word w)
   { /*1*/     
         
              
           
           
         
      
         
   } /*1*/
   
    
    
        
   
} /*0*/	

