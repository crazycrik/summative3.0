package becker.xtras.jotto;


 


/** <p>A sample implementation of the guess evaluator.  Students may write their
 * own version to use in Jotto by implementing <code>IGuessEvaluator</code>.</p>
 * 
 *
 * @author Byron Weber Becker */
  

         
         

   /** Construct a guess evaluator object */
   
  
   
	
   
     
             
   
	
   
     
           
   
        
         
        
   

   
     
         

        
        
   
	
   
          
           
             
              
         
      
   

   

          
           
                   
                 
                  
                   
                    
               
            
         
      
   

   
     
              
           
           
         
      
       
   

   /** Test the class. */
   
     
         
         
         
         
         
       
   

   
      
               
             
               
             
               
             
               
             

      /*
       Guess g = new Guess(target, guess);
       if (g.getExact() != expectedExact || g.getPartial() != expectedPartial)
       {  System.out.println("T=" + target + "; G=" + guess + "; expected ("
       + expectedExact + ", " + expectedPartial + "); got ("
       + g.getExact() + ", " + g.getPartial() + ").");
       }
       */
   


