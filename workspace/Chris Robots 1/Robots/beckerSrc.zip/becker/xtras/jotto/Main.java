package becker.xtras.jotto;



/** Demonstrate the game of Jotto.  The <code>main</code> method is
 * defined as
 * <pre>
 * public static void main(String[] args)
 * {  IWordList wordList = new SampleWordList();
 *    IGuessEvaluator guessEvaluator = new SampleGuessEvaluator();
 *
 *    JottoModel model = new JottoModel(wordList, guessEvaluator);
 *    model.addHint(new SampleHintContainsLetter());
 *    model.addHint(new SampleHintWithoutLetter());
 *    model.addHint(new SampleHintWithAllLetters());
 *    model.addHint(new SampleHintWithSomeLetters(3));
 *    model.addHint(new SampleHintConsistentWithGuesses(guessEvaluator));
 *
 *    JottoGUI ui = new JottoGUI(model);
 * }
 * </pre>
 * 
 * <p>All of the classes with names beginning with "Sample" may be
 * replaced with classes implementing the corresponding interfaces.</p>
 *
 * @author Byron Weber Becker */

  
   

	
   /** Run the program. */
   
      
          
   	
           
       
       
       
       
       
      
          
   


