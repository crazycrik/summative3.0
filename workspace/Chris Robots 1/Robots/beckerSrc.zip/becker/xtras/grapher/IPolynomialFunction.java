package becker.xtras.grapher;

 

/** A polynomial function, <i>f(x)</i>, has a number of terms, each of 
 * the form <i>a<sub>i</sub>x<sup>i</sup></i>.  A polynomial, <i>f</i>, has the form 
 * <i>a<sub>n</sub>x<sup>n</sup> + a<sub>n-1</sub>x<sup>n-1</sup> + ... +
 * a<sub>1</sub>x<sup>1</sup> + a<sub>0</sub>x<sup>0</sup></i> where the 
 * coefficients <i>a<sub>n</sub> .. a<sub>0</sub></i> are real numbers.  
 * The <i>degree</i> of a polynomial is the value of the largest exponent of
 * <i>x</i>, or <i>n</i>.
 *
 * <p>For example, if <i>a<sub>3</sub></i>=2.0, <i>a<sub>2</sub></i>=1.0,
 * <i>a<sub>1</sub></i>=0.0, and <i>a<sub>0</sub></i>=1.0 then<br>
 * <i>f(x) = 2.0*x<sup>3</sup> + 1.0*x<sup>2</sup> + 0.0*x<sup>1</sup> - 1.0*x<sup>0</sup></i> or <br>
 * <i>f(x) = 2.0*x<sup>3</sup> + 1.0*x<sup>2</sup> - 1.0</i>.
 * The function may be evaluated
 * for a particular value of <i>x</i> by substituting the value for <i>x</i>
 * in the above equation.  For example, <br><i>f(2) = 2.0*2<sup>3</sup> + 1.0*2<sup>2</sup> - 1.0</i><br>
 * or 19.</p>
 *
 * <p>A class implementing the <code>IPolynomialFunction</code> interface
 * will be able to evaluate a function at a particular value of <i>x</i>
 * using the {@link IPolynomialFunction#eval eval} method.  The current values
 * of the coefficients can be obtained with 
 * {@link IPolynomialFunction#getCoefficients getCoefficients}, and new values
 * can be set with {@link IPolynomialFunction#setCoefficients setCoefficients}.</p>
 *
 * <p>A class implementing <code>IPolynomialFunction</code> will begin with the
 * code <br><code>public class MyClassName extends Object implements IPolynomialFunction</code>.</p>
 *
 * <p>The function can be graphed by passing an instance of <code>IPolynomialFunction</code>
 * to {@link GrapherGUI}. Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>

 * 
 * @author Byron Weber Becker 
 * @see GrapherGUI
 * @see IFunction
 * @see IQuadraticFunction
 */
  
{ /*0*/

   /** Get the degree of this polynomial.  The degree is the value of the largest
    * exponent of <i>x</i>.  For example, the degree of 
    * <code>y = 5*x^3 + 2*x^2 + 0*x + 5</code> is <code>3</code>.
    * @return the degree of this polynomial. */
     
	
   /** Set the coefficients for this polynomial.  The length of the array
    * of coefficients must be equal to the degree + 1.
    * @param coef the coefficients to the polynomial such that <i>a<sup>i</sup></i>
    * appears in <code>coef[<i>i</i>]</code>. */
      
	
   /** Get the coefficients for this polynomial.  The length of the array
    * of coefficients must be equal to the degree + 1.
    * @return the coefficients to the polynomial such that <i>a<sup>i</sup></i>
    * appears in the<i>i<sup>th</sup></i> position in the array. */
     
	
   /** Get evenly distributed values for f(x) for all the values of x between 
    * <i>minX</i> and <i>maxX</i>.  
    * @param minX The smallest value of x;  must be less than maxX.
    * @param maxX The largest value of x.
    * @param numVals The number of values to return;  must be positive.
    * @return return an array with f(minX+0*deltaX), f(minX+1*deltaX), f(minX+2*deltaX),
    *  ..., f(minX*numVals*deltaX = maxX) */
          
	
   /** Evaluate the function for a given value of <i>x</i>.
    * @param x The value for which the function should be evaluated. */
      

   
   /** Add a view (graphical user interface) to the function. The view's <code>updateView</code>
    * method must be called each time the function's state changes. */
      
} /*0*/
