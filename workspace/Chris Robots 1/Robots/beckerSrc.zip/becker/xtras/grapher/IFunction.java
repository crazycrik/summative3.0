package becker.xtras.grapher;


/** Objects implementing the <code>IFunction</code> interface represent a
 * mathematical function, say <i>f(x)</i>. For example, if 
 * <i>f(x)&nbsp;=&nbsp;cos(x)&nbsp;+&nbsp;sin(x)</i>, a suitable class 
 * could be defined this way:
 * <pre>
 *     public class CosSin extends Object implements Function
 *     {  public CosSin()
 *        {  super();
 *        }
 *       
 *        public double eval(double x)
 *        {  return Math.cos(x) + Math.sin(x);
 *        }
 *     }
 * </pre>
 * and the following code would print a series of values of <i>f(x)</i>:
 * <pre>
 *     Function f = new CosSin();
 *     ...
 *     for(double x=-1; x<1; x+=0.5)
 *     {  System.out.println(f.eval(x));
 *     }
 * </pre>
 * 
 * <p>By using instance variables and appropriate parameters on the constructor,
 * entire families of functions can be defined using the same class.</p>
 *
 * <p>The function can be graphed by passing an instance of <code>IFunction</code>
 * to {@link GrapherGUI}.  Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker
 * @see GrapherGUI
 * @see IQuadraticFunction
 * @see IPolynomialFunction
 */
  
{ /*0*/

   /** Evaluate the function for a given value of <i>x</i>.
    * @param x The value for which the function should be evaluated. */
      
} /*0*/
