package becker.xtras.grapher;


 
 


/*
 * Grapher.java 1.0 
 * Copyright 2003 by Byron Weber Becker.  All rights reserved.
 */

/** <p><code>GrapherGUI</code> provides a user interface for graphing 
 * mathematical functions when supplied with an instance of a student-written 
 * class implementing one of the three interfaces {@link IFunction},
 * {@link IQuadraticFunction} and {@link IPolynomialFunction}.</p>
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @see IFunction
 * @see IQuadraticFunction
 * @see IPolynomialFunction
 *
 * @author Byron Weber Becker */
public class GrapherGUI extends Object
{ /*0*/
        
     
     
     
	
   /** Common code to create the UI object. */
   
  
		
		
			
         
      		
      

       
        
         
           
             
               
                   
                         
           
      
      
      
   
	
   /** Construct a GUI for an object implementing the <code>Function</code> interface.
    * @param f the object with the function to be graphed. */
   public GrapherGUI(IFunction f)
   { /*1*/   
   } /*1*/
	
   /** Construct a GUI for an object implementing the <code>QuadraticFunction</code> interface.
    * @param f the object with the function to be graphed. */
   public GrapherGUI(IQuadraticFunction f)
   { /*1*/   
   } /*1*/
	
   /** Construct a GUI for an object implementing the <code>PolynomialFunction</code> interface.
    * @param f the object with the function to be graphed. */
   public GrapherGUI(IPolynomialFunction f)
   { /*1*/   
   } /*1*/
	
   
      
       
       
       

      
   
   
   /** Set the size of the graphing window.
    * @param width the width of the window
    * @param height the height of the window */
   public void setSize(int width, int height)
   { /*1*/	 
   	
   } /*1*/
   
   /** Set the location of the graphing window relative to the top-left corner of the screen.
    * @param x the x-coordinate of the new location's top-left corner  
    * @param y the y-coordinate of the new location's top-left corner  */
   public void setLocation(int x, int y)
   { /*1*/	 
   } /*1*/
   
   
   
   
     
         
             
             
       
   

} /*0*/
