package becker.xtras.grapher;

 
 

/** A sample class implementing the {@link IPolynomialFunction} interface.  It 
 * calculates values of a polynomial function.
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 * 
 * @author Byron Weber Becker */
  

     
        

	/** Create a sample polynomial function with the given degree.
	 * @param deg The degree of the leading term in the polynomial. */
   
  
         
   
	
   
     
              
             
      
       
   
	
   
   
   
	
   
    
   	
   
	
    
   
   
	
    
      
               
         
              
          
           
      
       
   
   
   
	
   


