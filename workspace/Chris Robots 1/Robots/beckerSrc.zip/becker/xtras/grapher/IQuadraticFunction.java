package becker.xtras.grapher;

 


/** A quadratic function, <i>f(x)</i>, has the form 
 * <i>ax<sup>2</sup> + bx<sup>1</sup> + cx<sup>0</sup></i>, or more simply,
 * <i>ax<sup>2</sup> + bx + c</i> where the coefficients <i>a</i>, <i>b</i>, 
 * and <i>c</i> are real numbers.  
 *
 * <p>For example, if <i>a</i>=2.0, <i>b</i>=4.0, and <i>c</i>=1.0 then 
 * <i>f(x) = 2.0*x<sup>2</sup> + 4.0*x + 1.0</i>.  The function may be evaluated
 * for a particular value of <i>x</i> by substituting the value for <i>x</i>
 * in the above equation.  For example, <i>f(2) = 2.0*2<sup>2</sup> + 4.0*2 + 1.0
 * = 2.0*4 + 8.0 + 1.0 = 17.0</i>. </p>
 *
 * <p>A class implementing the <code>IQuadraticFunction</code> interface
 * will be able to evaluate a function at a particular value of <i>x</i>
 * using the {@link IQuadraticFunction#eval eval} method.  The current values
 * of <i>a</i>, <i>b</i> and <i>c</i> can be obtained with 
 * {@link IQuadraticFunction#getA getA},
 * {@link IQuadraticFunction#getB getB}, and
 * {@link IQuadraticFunction#getC getC}.
 * Finally, the coefficients can be reset to represent a new function with
 * {@link IQuadraticFunction#setCoefficients setCoefficients}.</p>
 *
 * <p>The function can be graphed by passing an instance of <code>IQuadraticFunction</code>
 * to {@link GrapherGUI}. Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>

 * @author Byron Weber Becker
 * @see IFunction
 * @see IPolynomialFunction
 * @see GrapherGUI 
*/
  
{ /*0*/

   /** Get the current value of coefficient <i>a</i>
    * @return the coefficient for the <i>x<sup>2</sup></i> term. */
     

   /** Get the current value of coefficient <i>b</i>
    * @return the coefficient for the <i>x<sup>1</sup></i> term. */
     

   /** Get the current value of coefficient <i>c</i>
    * @return the coefficient for the <i>x<sup>0</sup></i> term. */
     
	
   /** Set the coefficients of the quadratic function, <i>a</i>, <i>b</i>, and 
    * <i>c</i> to new values.
    * @param a The new coeffient for the <i>x<sup>2</sup></i> term.
    * @param b The new coeffient for the <i>x<sup>1</sup></i> term.
    * @param c The new coeffient for the <i>x<sup>0</sup></i> term. */
          
	
   /** Evaluate the function for a given value of <i>x</i>.
    * @param x The value for which the function should be evaluated. */
      

   /** Add a view (graphical user interface) to the function. The view's <code>updateView</code>
    * method must be called each time the function's state changes. */
      
} /*0*/
