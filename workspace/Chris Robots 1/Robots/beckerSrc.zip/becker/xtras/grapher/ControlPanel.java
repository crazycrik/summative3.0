package becker.xtras.grapher;


 
 
 




        
   
     

   
  
        
            
      
      
   
	
   /* package */ 
   
          
        
       
      
   
	
	/*
   private class GraphButtonListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {	g.graph();
      }
   }
	*/


