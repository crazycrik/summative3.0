package becker.xtras.nameSurfer;

 
 
 


/** Information about the popularity of one name. 
 *
 * @author Byron Weber Becker */
  

        
     
	
	/** Construct a new NameInfo object. 
	 * @param in An open scanner object where one name and related info can
	 * be read. */
   
  
        

      /* Read all the data for this name; add it to the object. */
       
           
            
         
      
         
      

   
	
   /** Get the name. */
   
   
   
	
   /** Find the ranking of this name for the given decade.
    * @param decade The decade number, starting at 0.
    * @return the ranking for the given decade */
   
   
   

