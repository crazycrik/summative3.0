package becker.xtras.nameSurfer;


/** Objects implementing INameList are used to collect names with popularity 
 * rankings to be graphed in the NameSurfer application.
 *
 * @author Byron Weber Becker */

   
{ /*0*/  
   /** Find the information for the given name.
   * @param name The name to find information for
   * @return name information for the given name; null if not found. */ 
      
} /*0*/
