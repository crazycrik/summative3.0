package becker.xtras.nameSurfer;

 
 
 

/** The model for the nameSurfer program specifies which names to graph.
 *
 * @author Byron Weber Becker */
  
	     
     
        

   /** Construct a new model.
    * @param nameList The set of names and their popularity data. */
	
	
	     
	
	
	
     
	      
	     
         
      
	
	
	
  
	   
	
	
	 
    
	
	
	
	
	
	
	
	
	
	
	
	   
			
		
	
