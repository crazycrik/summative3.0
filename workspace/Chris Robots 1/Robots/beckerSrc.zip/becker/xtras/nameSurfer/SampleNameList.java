package becker.xtras.nameSurfer;


 
 
 
 


/** A list of names and their rankings. 
 *
 * @author Byron Weber Becker */
  
	
        

   
  
	
         
          
       
            
         		
      
      
   
	
   
          
           
          
            
         
      
		
       
   
	
	/*
   public static void main(String[] args)
   {  INameList nl = new SampleNameList("names-data.txt");
   	
      // Charity 642 889 0 0 0 0 0 277 284 494 463
      INameInfo n = nl.find("Charity");
      Test.ckIsNotNull("not null", n);
      Test.ckEquals("name", "Charity", n.getName());
      Test.ckEquals("d0", 642, n.getRanking(0));
      Test.ckEquals("d1", 889, n.getRanking(1));
      Test.ckEquals("d2", 0, n.getRanking(2));
      Test.ckEquals("d7", 277, n.getRanking(7));
      Test.ckEquals("d10", 463, n.getRanking(10));
   }
   */

