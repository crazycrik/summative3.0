package becker.xtras.nameSurfer;

    
{ /*0*/
   /** Find the popularity rankings for the given name and add it to the set
    * of names to graph.
    * @param name The name to graph. */
      
   
   /** Clear the set of names to graph. */
     
   
   /** Get the set of names to graph. */
     
} /*0*/
