package becker.xtras.nameSurfer;

/** Objects implementing INameInfo record information about a name
 * and the popularity of that name over time.
 *
 * @author Byron Weber Becker */
   
{ /*0*/

   /** Get the name. 
    * @return the name */
     
   
   /** Find the ranking of this name for the given decade.
    * @param decade The decade number, starting at 0.
    * @return the ranking for the given decade */
      

} /*0*/
