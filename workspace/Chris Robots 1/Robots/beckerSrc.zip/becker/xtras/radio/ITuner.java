
package becker.xtras.radio;

 


/** <p>A tuner is a kind of radio that allows the user to adjust
 * the current frequency up or down or to seek the next station
 * with an adequate signal strength.  It also has memory presets
 * so the user can quickly return to a remembered station.</p>
 *
 * <p>Each tuner object is for a different band -- AM, FM, ShortWave, etc.
 * Each band has a minimum and a maximum frequency.  For the AM band, the
 * range is 530 - 1710.  For the FM band it is 87.5 to 107.9.  AM tuners
 * typically increment the frequecy in steps of 10;  FM tuners typically
 * increment the frequency in steps of .1 or .2. </p>
 *
 * <p>Classes that implement the <code>ITuner</code> interface will 
 * often extend {@link Radio}, a class that provides the most basic
 * functionality for a radio:  set and get the current frequency and a
 * measure of the signal strength being received at the current frequency.</p>
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
  
{ /*0*/
	
   /** The number of preset frequencies provided by the tuner. */
   public static final int NUM_PRESETS = 5;

   /** Move the frequency one step up, unless the frequency is already 
    * at the highest value for this band.  In that case, set it to the lowest
    * frequency for this band. */
     

   /** Move the frequency one step down, unless the frequency is already 
    * at the lowest value for this band.  In that case, set it to the highest
    * frequency for this band. */
     

   /** Move the frequency up until a station is found with a signal strength of
    * at least 0.5.  If the highest frequency for this band is reached, continue
    * the search with the band's lowest frequency.  */
     

   /** Move the frequency down until a station is found with a signal strength of
    * at least 0.5.  If the lowest frequency for this band is reached, continue
    * the search with the band's highest frequency.  */
     
	
   /** Remember the current frequency so that it can be later recalled with 
    * {@link #recallFrequency}.  There are a possible <code>NUM_PRESETS</code> 
    * remembered frequencies, each assigned to a button in the user interface.
    * @param button The number of a preset frequency button.  Between 1 and
    * NUM_PRESETS, inclusive. */
      
	
   /** Recall the frequency associated with a given preset button by a
    * previous call to {@link #rememberFrequency}. Set the recalled frequency
    * to be the current frequency.  There are a possible <code>NUM_PRESETS</code> 
    * remembered frequencies, each assigned to a button in the user interface.
    * @param button The number of a preset frequency button.  Between 1 and
    * NUM_PRESETS, inclusive. */
      
	
   /** Get the strength of the signal currently being received.  This depends,
    * of course, on the current frequency and whether or not there is a "radio
    * station" near or at that frequency.
    * @return The strength of the signal being received;  0 <= strength <= 1.0 */
     
	
   /** Get this tuner's current frequency.
    * @return The current frequency. */
     
   
   /** Add a view (graphical user interface) to the tuner. The view's <code>updateView</code>
    * method must be called each time the tuner's state changes. */
      
} /*0*/
