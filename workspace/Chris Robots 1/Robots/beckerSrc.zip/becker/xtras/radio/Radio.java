
package becker.xtras.radio;


 


/*
 * Radio.java 1.0 
 * Copyright 2003 by Byron Weber Becker.  All rights reserved.
 */

/** A very simple radio that allows the frequency to be adjusted and provides
 * a measure of the signal strength of the station being received, if there
 * is one.
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
public class Radio extends Object
{ /*0*/
     
       { /*1*/     
                
       } /*1*/
       { /*1*/     
                
       } /*1*/
	
   /** Construct a new Radio object. */
   public Radio()
   { /*1*/  
   } /*1*/
	
   /** Set this radio's current frequency.
    * @param frequency The new frequency for this radio. */
   public void setFrequency(double frequency)
   { /*1*/    
   } /*1*/
	
   /** Get this radio's current frequency.
    * @return The current frequency. */
   public double getFrequency()
   { /*1*/   
   } /*1*/
	
   /** Get the strength of the signal currently being received.  This depends,
    * of course, on the current frequency and whether or not there is a radio
    * station nearby at that frequency.
    * @return The strength of the signal being received;  0 <= strength <= 1.0 */
   public double getSignalStrength()
   { /*1*/     
           
         
         
      	
            
            
              
              
              
              
              
              
         
       
      	
            
            
              
              
              
              
              
              
         
      
       
   } /*1*/
	
   /** Find the position of the closest station in the array. */
   
       
         
              
             
            
             
              
         
       
       
   
	
	/*
   public static void main(String[] args)
   {  Radio r = new Radio();
      r.setFrequency(89.1);
      Test.ckEquals("freq", 89.1, r.getFrequency());
      Test.ckEquals("str", 1.0, r.getSignalStrength());

      r.setFrequency(89.2);
      Test.ckEquals("freq", 89.2, r.getFrequency());
      Test.ckEquals("str", 0.7, r.getSignalStrength());

      r.setFrequency(89.0);
      Test.ckEquals("freq", 89.0, r.getFrequency());
      Test.ckEquals("str", 0.7, r.getSignalStrength());
   }
   */
} /*0*/
