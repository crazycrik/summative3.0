package becker.xtras.radio;
 


/** A graphical user interface (GUI) for an AM/FM radio.  It must be
 * supplied with two instances of {@link ITuner}, one used for the AM band
 * and the other used for the FM band.  See the package overview for a sample
 * <code>main</code> method using this class.
 *
 * @author Byron Weber Becker */
public class RadioGUI extends Object
{ /*0*/
         
	
	/** Construct a graphical user interface for an AM/FM radio.
	 * @param amTuner A class implementing <code>ITuner</code> representing the
	 *  AM frequencies.
	 * @param fmTuner A class implementing <code>ITuner</code> representing the
	 *  FM frequencies. */
   public RadioGUI(ITuner amTuner, ITuner fmTuner)
   { /*1*/  
            
      
      
      
		
			
         
      		
      

      
      
   } /*1*/
} /*0*/
