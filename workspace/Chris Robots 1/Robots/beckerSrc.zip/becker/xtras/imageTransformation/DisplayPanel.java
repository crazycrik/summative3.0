package becker.xtras.imageTransformation;


/*   
 * The idea for this assignment and some of the initial code is from "Teaching 
 * Two-Dimensional Array Concepts in Java With Image Processing Examples" by Kevin R. 
 * Burger in <i>SIGCSE Bulletin</i>, Volume 35, Number 1, March 2003, pages 205-209.
 */


 
 
 
 


/**
 * A simple panel used to display the image under scrutiny.
 *
 * @author    Michael DiBernardo
 * @version   1.1
 */

/* package */ 

     

   /**
    * Formats the display panel.
    *
    * @param curImage   the image to be displayed in this panel.
    */
   
    
      
        
      
   
   
   
  
   

   /**
    * Redraws the greyscale image on the panel.
    *
    * @param g   the graphics object for this panel
    */
   
  
          
        
   

