package becker.xtras.imageTransformation;

/*   
 * The idea for this assignment and some of the initial code is from "Teaching 
 * Two-Dimensional Array Concepts in Java With Image Processing Examples" by Kevin R. 
 * Burger in <i>SIGCSE Bulletin</i>, Volume 35, Number 1, March 2003, pages 205-209.
 */

 
 
 


/**
 * The button bar that is used to manipulate the image in the
 * display.
 *
 * @author    Michael DiBernardo
 * @version   1.2
 */

/* package */ 

           
        

   /**
    * Populates this panel with buttons whose names are specified in the
    * list of transformations held by the greyscale image we are manipulating.
    *
    * @param curImage   the image to be manipulated by the buttons in this panel
    * @param dp         the <code>DisplayPanel</code> on which our image is drawn
    */
   
    
      

         
         

      
      
      

        
   

   /**
    * Creates a button for each transformation named in the given array,
    * with the transformation name as the button text.
    *
    * @param transformationNames   The list of transformations to make buttons for
    */
   
   
             
           
      
   

   /**
    * Adds buttons to this panel.
    */
   
    

              
        
      

      
   

   /**
    * Creates a listener for each button on this panel.
    */
   
   
             
         
      
   

       
   

      /**
       * Uses the button text to figure out the name of the transformation
       * that the user is requesting, requests the image to perform that transformation,
       * and then updates the display.
       */
         
            
         
      
   


