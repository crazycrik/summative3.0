package becker.xtras.imageTransformation;


/*   
 * The idea for this assignment and some of the initial code is from "Teaching 
 * Two-Dimensional Array Concepts in Java With Image Processing Examples" by Kevin R. 
 * Burger in <i>SIGCSE Bulletin</i>, Volume 35, Number 1, March 2003, pages 205-209.
 */


 
 
 


/** The ImageTransformerGUI provides a graphical user interface (GUI) for 
 * transforming graphic images via a class implementing {@link ITransformations}
 * provided to its constructor. 
 *
 *	<p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author    Michael DiBernardo and Byron Weber Becker
 */
public class ImageTransformerGUI extends Object
{ /*0*/
     

   /**
    * Create a GUI that allows manipulation of images.
    *
    * @param trans The object that will do the transformations of the image.
    */
   public ImageTransformerGUI(ITransformations trans)
   { /*1*/  
           
       
		
		
			
         
      		
      

      

          
       

          
       

          
           

       
       

      
      
   } /*1*/

   /**
    * Used to centre the window in the user's environment. Credit goes to
    * Steven Furino for this one.
    */
   
     
         
             
             
       
   
} /*0*/
