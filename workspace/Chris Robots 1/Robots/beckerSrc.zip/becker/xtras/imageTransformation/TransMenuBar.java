
package becker.xtras.imageTransformation;


/*   
 * The idea for this assignment and some of the initial code is from "Teaching 
 * Two-Dimensional Array Concepts in Java With Image Processing Examples" by Kevin R. 
 * Burger in <i>SIGCSE Bulletin</i>, Volume 35, Number 1, March 2003, pages 205-209.
 */


 
 
 


/* package */ 

     
   
   
  
        
      
      
   
   
   
      
       
       
      
       
      
       
   
   
   
      
         
              
         
      
       
   
   
       
   
       
        
      

         
            
          
         
            
            
              
            
            
         		
      
   
   

       
   
       
        
      

         
         
      
   
   
   
       
   
       
        
      

         
        
      
   
   
   
       
   
        
        
      

      /**
       * Uses the menu text to figure out the name of the transformation
       * that the user is requesting, requests the image to perform that transformation.
       */
         
            
         
      
   

