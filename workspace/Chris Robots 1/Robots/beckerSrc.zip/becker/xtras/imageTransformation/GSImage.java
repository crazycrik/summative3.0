package becker.xtras.imageTransformation;


/*   
 * The idea for this assignment and some of the initial code is from "Teaching 
 * Two-Dimensional Array Concepts in Java With Image Processing Examples" by Kevin R. 
 * Burger in <i>SIGCSE Bulletin</i>, Volume 35, Number 1, March 2003, pages 205-209.
 */


 
 
 
 
 
 
 


/**
 * A representation of an greyscale image. Pixels are stored in a 2D array of integers.
 * A single pixel is given a value between 0 and 255, with 0 being completely white and 255
 * being completely black.
 *
 * @author    Michael DiBernardo
 * @version   1.1
 */

/* package */ 


       
  
   /**
    * Reads the image in from the specified file and creates
    * a 2D array representation of that image. Files should be
    * of GIF or JPEG format. Any color image will be converted
    * to greyscale.
    *
    * @param fileName   The path to the source image file
    */
   
    
    
         
      
      
   

	
	
	

   /**
    * Sets the pixelmap for this image.
    *
    * @param newPixels   the pixelmap to set to this image
    */
   
  
   
    
   /**
    * Gets the pixelmap for this image.
    *
    * @return   the pixelmap for this image.
    */
    
   
   
   
   
  
   
   
    
   
   

   /**
    * Draws this image on the surface specified by the
    * given graphics object at the coordinates (x,y).
    *
    * You do not need to modify this method.
    *
    * @param g2   The surface on which to paint this image
    * @param x    The x coordinate at which to draw this image
    * @param y    The y coordinate at which to draw this image
    */
   
     

         
   

   /**
    * Reads in the image file that contains the source for this image and
    * converts it into a greyscale 2D integer representation.
    *
    * You do not need to modify this method.
    *
    * I would like to acknowledge Kevin R. Burger from Rockhurt University for
    * the idea of reading in the array samples using the <code>WriteableRaster</code>
    * class. Some of the code in this method was taken from his article in the SIGCSE
    * 2003 compilation.
    */
   
   /* package */ 
  
      
          
      

   
    
   
      
      
   
    
   
  
         
         

             
              
      

      
           
            

      
         
         

      
          

      
      
         

              
                
               
         
      
      
   

   /**
    * Converts the 2D array representation of our image into a BufferedImage
    * object so that it can be drawn to a surface.
    *
    * You do not need to modify this method.
    *
    * This is basically the inverse of what is done in the last portion of the
    * <code>readImage()</code> method. Once again, I would like to credit
    * Kevin R. Burger for the WritableRaster stuff.
    *
    * @return   A BufferedImage representation of this image
    */
   
     
         
         
      
           
            

         

              
                
              
         
      

       
   

