package becker.xtras.hangman;

 
 

/** A graphical user interface for the game of Hangman.  The model is typically
 * implemented by a student and must implement the {@link IHangman} interface.
 *
 * <p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
public class HangmanGUI extends JFrame
{ /*0*/    
     
     
     

   
   /** Construct the UI.
       @param aModel the model the ui diplays and updates */
   public HangmanGUI(IHangman aModel)
   { /*1*/  
      
         
         
         
         

      

   } /*1*/

	
	
   
      
       
       
       

          
        
      
      
       
      
      
      
       
		
			
         
      		
      
      
   
} /*0*/
