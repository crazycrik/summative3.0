package becker.xtras.hangman;

 
 

/** Objects implementing <code>IHangman</code> are used to play the game of
 * <i>Hangman</i>.  
 *
 * <p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
  
{ /*0*/
   /** The first letter that can be guessed. */
   public static final char FIRST_LETTER = 'A';
   /** The last letter that can be guessed. */
   public static final char LAST_LETTER = 'Z';
   /** The number of letters that can be guessed. */
   public static final int NUM_LETTERS = LAST_LETTER - FIRST_LETTER + 1;
   /** The number of incorrect guesses the player is allowed to have. */
   public static final int MAX_WRONG_GUESSES = 6;

   /** Begin a new game with the player trying to guess the given phrase.
    *   @param thePhrase the phrase to guess */
      

   /** Begin a new game with a randomly chosen phrase for the player
    * to guess.  */
     
   
   /** How many wrong guesses has the player used? 
    * @return the number of wrong guesses made */
     
   
   /** Has the player lost the game (had more than MAX_WRONG_GUESSES or has
    * forfeit)?
    * @return true if the player has lost; false otherwise */
     
   
   /** Has the player won the game by correctly guessing all the letters
    * in the phrase?
    * @return true if the player has won; false otherwise */
     

   /** Process a letter the player has guessed.
    * <p>This method is called by the user interface when the user clicks
    * on a letter to guess it.  Assuming <code>wasGuessed(theLetter)</code>,
    * <code>won()</code>, and <code>lost()</code> all
    * return <code>false</code> before this method is called and 
    * <code>numWrongGuesses</code> returns <i>n</i>, then after this
    * method is called the following should be true:</p>
    * <ul><li><code>wasGuessed(theLetter)</code> returns <code>true</code>.</li>
    * <li>if the phrase contains <code>theLetter</code>, then <code>getGuessedPhrase</code>
    *     will have <code>theLetter</code> included in the string it returns
    *     and <code>numWrongGuesses()</code> will return <i>n</i>.</li>
    * <li>if the phrase does not contain <code>theLetter</code>, 
    *    <code>numWrongGuesses()</code> will return <i>n+1</i>.</li>
    * </ul>
    * @param theLetter the letter guessed */
      

   /** Has the given letter been guessed before?
    * @param aLetter
    * @return true if the letter was already guessed;  false otherwise */
      
   
   /** The user has given up and forfeited the game. */
     
   
   /** Return the phrase that has been guessed so far.  If the player has
    * already lost the game, return the phrase they were trying to guess.
    * <P>Examples:</p>
    * <blockquote><table border="1" cellpadding="5">
    * <tr><th>Phrase</th><th>Letters guessed</th><th>Return</th></tr>
    * <tr><td>WAIT A MINUTE</td><td><i>none</i></td><td>. . . . &nbsp; . &nbsp; . . . . . .</td></tr>
    * <tr><td>WAIT A MINUTE</td><td>A I</td><td>. A I . &nbsp; A &nbsp; . I . . . .</td></tr>
       * <tr><td>WAIT A MINUTE</td><td><i>lost game</i></td><td>W A I T &nbsp; A &nbsp; M I N U T E</td></tr>
    * </table></blockquote>
    * @return the guessed phrase */
     
   
   /** Add a view (graphical user interface) to the game. The view's <code>updateView</code>
    * method must be called each time the game's state changes. */
      

} /*0*/
