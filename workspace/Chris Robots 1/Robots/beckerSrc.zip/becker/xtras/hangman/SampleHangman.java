package becker.xtras.hangman;

 
 
 
 
 

/** A sample implementation of {@link IHangman} used to demonstrate the
 * operation of the game of Hangman.  
 *
 * <p>Please see the <a href="package-summary.html#package_description">package description</a>
 * for a more in-depth discussion of using this class.</p>
 *
 * @author Byron Weber Becker */
public class SampleHangman extends Object implements IHangman
{ /*0*/
   public static final char FIRST_LETTER = 'A';
   public static final char LAST_LETTER = 'Z';
   public static final int NUM_LETTERS = LAST_LETTER - FIRST_LETTER + 1;
   public static final int MAX_WRONG_GUESSES = 6;

   
        

   /* Phrase holds the phrase they're trying to guess.  GuessedPhrase holds
   the player's progress so far.  GuessedPhrase starts with all the letters
   replaced with '.'.  As the user guesses letters correctly, the '.' are
   replaced with the actual letters.  The player has won when the two phrases
   are equal. */
       
        
        

   /* This array is indexed by letter - FIRST_LETTER -- position 0 corresponds
   to 'A', 1 to 'B', and so on.  The element is true if the letter has been
   guessed; false otherwise. */
            
       
       

   public SampleHangman()
   { /*1*/  

   } /*1*/

   public void newGame()
   { /*1*/  
   } /*1*/

   public void newGame(String thePhrase)
   { /*1*/    
         

      
         
            
            
         
      
      
        
        
      
      
   } /*1*/

   public int numWrongGuesses()
   { /*1*/   
   } /*1*/

   public boolean lost()
   { /*1*/       
   } /*1*/

   public boolean won()
   { /*1*/     
   } /*1*/

   
     
          
      
   

   public void processGuess(char theLetter)
   { /*1*/  
       
        
                   
      
         
        
      
      
      
   } /*1*/

   
     
         
           
            
              
         
      
       
        
      
          
   

   public boolean wasGuessed(char aLetter)
   { /*1*/  
         
   } /*1*/

   
         
                    
                         
      
   

   public void forfeit()
   { /*1*/    
      
   } /*1*/

   public String getGuessedPhrase()
   { /*1*/   
         
       
          
      
   } /*1*/
   
   
   public void addView(IView aView)
   { /*1*/	
   } /*1*/

/*
	public void removeView(IView aView)
	{	this.views.remove(aView);
	}
	
	public void updateAllViews()
	{	for(Iterator it = this.views.iterator(); it.hasNext(); )
		{	((IView)it.next()).updateView();
		}
	}
	
	*/

   public static void main(String[] args)
   { /*1*/   
          

         
           

      
           
         
      
           
        
        

      
        
        
        
      
      
      
      
      
        
        
        
      
        
        
        

      
      
        
        

       
   } /*1*/
} /*0*/