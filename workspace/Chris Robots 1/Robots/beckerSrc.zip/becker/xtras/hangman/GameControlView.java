package becker.xtras.hangman;


 
 
 
 

/** A view of a Hangman game that controls the game functions of forfeiting
and starting a new game.
@author Byron Weber Becker */

    
        
         

   
  
        

      
      

      
      
   

	/**	Enable the forfeit button while the game is in progress; disable it when 
		the game is over.  Disable the new game button while the game is in
		progress;  enable it when the game is over. */
   
    
        
   

   /** Add the buttons to the view;  keep them aligned vertically. */
   
    
      
      
   

   /** Register the listeners for this view's components. */
   
   
       
   

   
         
        
        
      
   

         
        
        
      
   



