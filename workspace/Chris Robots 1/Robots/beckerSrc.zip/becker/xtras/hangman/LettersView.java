package becker.xtras.hangman;


 
 
 
 

/** A view of the game that shows the letters that have been used and allows
    the user to guess a letter.
    @author Byron Weber Becker */

    

   /* Use a special kind of JButton that displays a single letter and
      has a getLetter method that returns the single letter it displays. */
        


   
  
        

      
		   
		    
					   
			    
           
			
		

      
      

      
      
   

   /** Update the view with the most current information. */
   
	
		
		     
			   
            
         
      
	

   
	
		  
         
        
      
	

	
	
		
          
		   
      	   
         
      
	

         
        
        
			
            
         
      
   

