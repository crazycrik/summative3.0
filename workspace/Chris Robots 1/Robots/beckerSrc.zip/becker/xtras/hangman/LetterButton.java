package becker.xtras.hangman;

 

/** A special kind of button that displays a single letter.  This
    simplifies LettersView. */

    

   
    
        
   

   
   
   
