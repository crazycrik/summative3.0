package becker.xtras.hangman;





   /** Run a demo for <code>becker.xtras.hangman</code>. */
   
      
          
   

