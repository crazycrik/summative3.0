package becker.xtras.hangman;

 
 
 

/** Draw the gallows for the game of Hangman, showing how many wrong guesses the player
 *  has had and a message if the game is over.
 *  
 *  @author Byron Weber Becker */
public class GallowsView extends JComponent implements IView
{ /*0*/
   /* Note:  GallowsView is used in one of the problems in chapter
    * 12, so it needs to stay public.  If not for that, it could have
    * package visibility. */
    
    
     
     
     

            
            
            
            
            
         

   /** Construct the view.
   @param aModel the model for this view. */
   public GallowsView(IHangman aModel)
   { /*1*/  
        

        
        
      
      
   } /*1*/

   /** Update the view with the most recent info from the model. */
   public void updateView()
   { /*1*/  
      
   } /*1*/

   /** Paint the component.  This is called automatically by the system.
   @param g The graphics context for painting. */
   public void paintComponent(Graphics g)
   { /*1*/  
        
        

      
      
      
       
           
         
         
      
   } /*1*/

   /** Print a message on the graphic
   @param g The graphics context for drawing. */
   
        
      
         
         
        
   


   /** Draw the person hanging from the gallows.
   @param g The graphics context for drawing. */
   
     
   
      
               
      

                
           
      

                
           
      

               
               
         
      

              
               
         
      

              
               
         
      

              
               
         
      
   

   /** Make an appendage (arm or leg) for the person.
   @return A polygon outlining the appendage. */
   
      
       
       
       
       
       
       
   

   /** Draw the gallows.
   @param g The graphics context where it should be drawn. */
   
  

               
            
              
            
                

   

   /** Draw the background with sky, mountains, sun, etc.
   @param g The graphics context. */
   
  
      
         

      
      
         

      
      
         

      
      
          
       
       
       
       
       
       
      
   
} /*0*/

