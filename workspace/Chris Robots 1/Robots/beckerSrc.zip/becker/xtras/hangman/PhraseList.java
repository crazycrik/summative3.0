package becker.xtras.hangman;




/** Represent all the words and phrases that can be guessed.
    @author Byron Weber Becker */


      
                             
                    
             
                 
             
           
      

   
       
       
   


