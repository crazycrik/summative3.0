/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */
package becker.robots;

 


/** A MazeCity contains walls in the form of a perfect maze.  Every intersection
 * is connected to every other intersection and there are no cycles.  The 
 * classic "keep your right hand on the wall" algorithm will visit every
 * intersection.
 *
 * The maze has no exit.  Instead, place a <code>Thing</code> to mark the
 * destination.  
 *
 * @author Byron Weber Becker */
public class MazeCity extends City
{ /*0*/
   
   /* From http://www.astrolog.org/labyrnth/algrithm.htm
    * Growing Tree Algorithm:  This is a general algorithm, capable of creating 
    * Mazes of different textures. It requires storage up to the size of the Maze. 
    * 
    * Each time you carve a cell, add that cell to a list. Proceed by picking a 
    * cell from the list, and carving into an unmade cell next to it. If there 
    * are no unmade cells next to the current cell, remove the current cell from 
    * the list. The Maze is done when the list becomes empty. 
    * 
    * The interesting 
    * part that allows many possible textures is how you pick a cell from the 
    * list. For example, if you always pick the most recent cell added to it, 
    * this algorithm turns into the recursive backtracker. If you always pick 
    * cells at random, this will behave similarly but not exactly to Prim's 
    * algorithm. If you always pick the oldest cells added to the list, this 
    * will create Mazes with about as low a "river" factor as possible, even 
    * lower than Prim's algorithm. If you usually pick the most recent cell, 
    * but occasionally pick a random cell, the Maze will have a high "river" 
    * factor but a short direct solution. If you randomly pick among the most 
    * recent cells, the Maze will have a low "river" factor but a long windy 
    * solution.
    */
    
     
        
   
   /** Create a city with walls that form a maze.  The upper left corner of the
    * city is always at (0,0).
    *
    * @param numStreets The number of streets in the city.  Must be at least 2.
    * @param numAvenues The number of avenues in the city.  Must be at least 2.
    * @param twisty How twisty the passages should be.  A value of 0.0 makes
    *        the passages as straight as possible.  A value of 1.0 makes them
    *        as twisty as possible.
    * @param branchy How branchy should the passages be?  A value of 0.0
    *        makes passages with few branches;  a value of 1.0 makes passages 
    *        with more branches.
    */
   public MazeCity(int numStreets, int numAvenues, double twisty, double branchy)
   { /*1*/   
      
             
                  
      
             
                 
      
             
                 
      
      
       
      
      
         
           
             
            
           
            
          
           
            
         
      
      
      
   } /*1*/
   
   /** Construct a maze of the given size with moderate branching and twistiness.
    * @param numStreets The number of streets in the city.  Must be at least 2.
    * @param numAvenues The number of avenues in the city.  Must be at least 2.
    */
   public MazeCity(int numStreets, int numAvenues)
   { /*1*/     
   } /*1*/
   
      
   
  
      
      
      
         
        
            
       
        
         
              
         
      
   
   
   
     
        
                 
              
            
         
       
             
         
              
      
         
          
           
         
      

            
         
           
         
      
         
      
             
           
         
      

      
       
   
   
   
      
   
              
                
               
         
      
        
   
   
   
          
                
           
         
      
   
} /*0*/




        
        
        
        
   
        
       
       
   
   
    
    
   
       
      
   
   
  
        
        
   
   
   
     
               
   
   
   
          
         
               
         
      
   
   
   
     
             
          
               
          
               
          
               
          
       
         
      
      
        
            
      
        
            
   
   
   /** Return the neighbour in the given direction, if there is one.  Null if there isn't. */
   
     
         
      
             
           
                 
           
               
           
                 
           
       
         
      
   

