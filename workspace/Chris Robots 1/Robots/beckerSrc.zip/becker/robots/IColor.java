/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


 


/**
 * An interface to add a color property to various robot entities.
 *
 * @author Byron Weber Becker 
 */
  
{ /*0*/

   /** Return this object's current color. */
     

   /** Set the color for this object
    * @param aColor the new color.
    */
      
   
   
   /** Get this object's current transparency.
    * @return A number between 0.0 (fully opaque) and 1.0 (fully transparent). */
     
   
   /** Set the transparency for this object;  that is, the degree to which it
    * permits objects under it show through.
    * @param trans  A number between 0.0 (fully opaque) and 1.0 (fully transparent).*/
      
} /*0*/
