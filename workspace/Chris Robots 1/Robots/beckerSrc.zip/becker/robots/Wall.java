/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 

 


/** A Wall will block the movement of a robot into or out of the intersection
 *  which contains it, depending on the robot's direction of travel and
 *  the orientation of the Wall.
 *
 * @author Byron Weber Becker
 */
public class Wall extends Thing
{ /*0*/

   /** Construct a new wall.
    *  @param city The city in which the wall will exist.
    *  @param street The wall's initial street within the city.
    *  @param avenue The wall's initial avenue within the city.
    *  @param orientation The direction in which the wall blocks entry
    *  into and exit out of the wall's intersection.  One of
    *  {{@link Direction}.NORTH, EAST, SOUTH, WEST}.
    */
   public Wall(City city, int street, int avenue, Direction orientation)
   { /*1*/        
       
                    
      
      
       
       
   } /*1*/

   /**
    * Save a representation of this intersection to an output stream.
    * @param indent the indentation, for formatting purposes
    * @param out the output stream
    */
   protected void save(String indent, PrintWriter out)
   { /*1*/   
         
   } /*1*/
} /*0*/
