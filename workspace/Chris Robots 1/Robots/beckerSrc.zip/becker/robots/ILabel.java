/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


/** An interface to provide colored entities in the robot world.
 * 
 * @author Byron Weber Becker
 */
  
{ /*0*/

   /** Set a new label for this object.
    @param label the new label */
      

   /** Get the label for this object.  Returns an empty string if no label has been set. */
     
} /*0*/
