/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


 
 
 
 


/**
 *
 *	<P>There are two ways to display a Robot program on a web page, both are
 * documented here. </P> 
 *
 * <H3>Option 1: Run a Robot Application as an Applet</H3> 
 * <P>The first, and easiest way, is to write a standard robot
 * <I>application</I> and then to use <CODE>AppletRunner</CODE> to display it. 
 * <CODE>AppletRunner</CODE> simply displays a button on the web page. Clicking 
 * the button will run the application in a separate window. For example,
 * <APPLET
 *   CODEBASE="http://www.learningwithrobots.com/examples/classes/"
 *   ARCHIVE="examples.jar" CODE="becker.robots.AppletRunner.class" WIDTH="100"
 *   HEIGHT="25"> <PARAM NAME="className" VALUE="examples.Pick3">
 * <PARAM NAME="buttonLabel" VALUE="Pick3"> </APPLET>.  
 *
 * (Try it!)</P> 
 *
 * <P>No programming, other than the original application, is required. </P>
 *
 * <H4>Step 1: The HTML</H4>
 * <P>Simply include <CODE>APPLET</CODE> tags, as follows, except that the 
 * capitalized red parts will need to be customized to your situation: </P> 
 *
 * <PRE>&lt;applet
 *   codebase = "classes/"
 *   code = "becker.robots.AppletRunner.class"
 *   width = "100" 
 *   height = "25"&gt;
 *   &lt;param name="className" value="<FONT COLOR="red">CLASS_NAME</FONT>"&gt;
 *   &lt;param name="buttonLabel" value="<FONT COLOR="red">LABEL_TEXT</FONT>"&gt;
 * &lt;/applet&gt;
 * </PRE>
 *
 * <P>The parts you need to customize are: </P> 
 * <BLOCKQUOTE>
 *   <DL> 
 *   <DT>CLASS_NAME</DT> 
 *   <DD>The name of the class containing the <CODE>main</CODE> method to 
 *       execute. If it the class is part of a package, the package
 *       name is also required. Examples include <CODE>MyClass</CODE> and 
 *       <CODE>myPackage.MyClass</CODE>. </DD> 
 *   <DT>LABEL_TEXT</DT> 
 *   <DD>The text to display on the button that starts the program running.
 *       For example, "Run My Applet". </DD> 
 *   </DL></BLOCKQUOTE>
 * 
 * <H4>Step 2: Install Files on a Web Server</H4>
 *
 * <P>Step 2 is to install the files on a web server. Assume that the web page
 * is in a directory named <CODE>public_html</CODE>. Then the class files for 
 * the robot application, <I>along with the
 * class files in <CODE>becker.jar</CODE></I> must be in the directory 
 * <CODE>public_html/classes</CODE>. </P>
 *
 * <P>To obtain the class files from <CODE>becker.jar</CODE>, simply unzip it 
 * with a standard zip compression utility. Extract all
 * the files into <CODE>public_html/classes/</CODE>. If you wish, you may 
 * delete the directory <CODE>public_html/classes/becker/xtras/</CODE> to 
 * conserve disk space.</P>
 *
 * <P>Now add the class files from your program. Suppose your program consists
 * of two classes, <CODE>Main</CODE> and <CODE>CollectorBot</CODE>, and that 
 * the program is in a package named <CODE>examples</CODE>. The directory 
 * structure should then be</P>
 *
 * <BLOCKQUOTE><PRE>public_html/
 *   myRobotApplet.html
 *   classes/
 *     becker/
 *       io/
 *       robots/
 *       util/
 *     examples/
 *       Main.class
 *       CollectorBot.class</PRE></BLOCKQUOTE>
 *
 * <P>The class files in <CODE>becker/io/</CODE>, 
 * <CODE>becker/robots/</CODE>, and 
 * <CODE>becker/util/</CODE> are not shown.</P>
 *
 * <P>Make sure all the files have read permissions set. The world should now
 * be able to view your work!</P>
 *
 * <H4>Step 3: Jarring the Class Files (Optional)</H4>
 *
 * <P>Your applet will start and run faster if you put all the files into a
 * jar file. You can use the <CODE>jar</CODE> tool to do this. A sample 
 * command line for the above example is</P>
 *
 * <PRE>   jar cf collectorBot.jar becker&#047;&#042;&#047;&#042;.class examples&#047;&#042;.class</PRE>
 *
 * <P>You can then replace everything in the <CODE>classes</CODE> file with 
 * this one file. You also need to add the line 
 * <CODE>archive="collectorBot.jar"</CODE> to the applet tags inserted in 
 * step 1. Again, make sure the file has read permissions.</P>
 *
 * <BLOCKQUOTE>
 * <P><FONT SIZE="-1">Note: It seems that it should be possible for the web
 * browser to search both the <CODE>becker.jar</CODE> archive and classes in 
 * the <CODE>codebase</CODE> directory. This seems unreliable, at best, with 
 * some browsers
 * supporting it and some not. Furthermore, the <CODE>APPLET</CODE> tag has 
 * been deprecated in version 4.0 of the HTML standard, but again,
 * browser support for the alternative <CODE>OBJECT</CODE> tag seems very 
 * spotty.</FONT></P></BLOCKQUOTE> 
 *
 * <H3>Option 2: Run a Robot Applet Inside a Web Page</H3> 
 * <P>The second solution for displaying a robot program via the web is to
 * embed the applet in the web page, as is traditionally done. This requires
 * extending <CODE>JApplet</CODE>, putting part of the robot application's 
 * <CODE>main</CODE> method in the applet's <CODE>init</CODE> method and part 
 * in the <CODE>start</CODE> method. It also involves using a 
 * <CODE>Thread</CODE>. Fortunately, the transformation is quite 
 * straight-forward. </P>
 *
 * <P>The following example shows a traditional robot application and then the
 * equivalent applet.</P>
 *
 * <H4>Traditional Robot Application</H4>
 * <BLOCKQUOTE>
 * <PRE> import becker.robots.*;
 *
 * public class Example extends Object
 * {  public static void main(String[] args)
 *    {  City c = new City();
 *       Robot karel = new Robot(c, 1, 2, Direction.EAST);
 *       CityFrame f = new CityFrame(c);
 *
 *       karel.move();
 *       karel.turnLeft();
 *       karel.move();
 *       karel.turnLeft();
 *    }
 * }</PRE></BLOCKQUOTE>
 *
 * <H4>Equivalent Robot Applet</H4>
 * <BLOCKQUOTE>
 * <PRE>import becker.robots.*;
 * import javax.swing.JApplet;
 * import javax.swing.*;
 *
 * public class Example extends JApplet implements Runnable
 * {  private Robot karel;
 *
 *    // Create the initial situation
 *    public void init()
 *    {  City c = new City();
 *       this.karel = new Robot(c, 1, 2, Direction.EAST);
 *       RobotUIComponents ui = new RobotUIComponents(c);
 *       this.setContentPane(ui.getUI());
 *
 *       Thread t = new Thread(this);
 *       t.start();
 *    }
 *
 *    // Tell the robot what to do.
 *    public void run()
 *    {  this.karel.move();
 *       this.karel.turnLeft();
 *       this.karel.move();
 *       this.karel.turnLeft();
 *    }
 * }</PRE></BLOCKQUOTE>
 *
 * <P>After writing the applet, the class files need to be placed on the web
 * server, as discussed in Option 1, steps 2 and 3. The <CODE>APPLET</CODE> 
 * tag to put in the HTML file would be something like</P>
 *
 * <BLOCKQUOTE><PRE>&lt;applet
 *   codebase = "classes/"
 *   code = "Example.class"
 *   width = "600" 
 *   height = "500"&gt;
 * &lt;/applet&gt;
 * </PRE></BLOCKQUOTE>
 *
 * @author Byron Weber Becker 
 *
 */  
public class AppletRunner extends JApplet implements ActionListener
{ /*0*/
    
    
	
   /** Public because it must be;  not meant to be called. */
   public void init()
   { /*1*/    
         
          
		
           
         
      
       
      
   } /*1*/
   
   
  
            
           
      	
            
             
           
              
         
              
           
          
         
         
        
         
        
         
        
         
        
      
   

   /** Public because it must be;  not meant to be called. */
   public void actionPerformed(ActionEvent evt)
   { /*1*/      
      
           
           
         
      
      

   } /*1*/
	
} /*0*/
