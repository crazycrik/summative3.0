package becker.robots;


/** Reflect a change of state event within the robot world.
 *
 * @author Byron Weber Becker */
public class StateChangeEvent 
{ /*0*/
     
     
     
     
   
   
   /* package */
  
        
        
        
        
   
   
   /* package */
  
        
            
        
        
   
   
   
   /** What type of event was it?
    * @return The event's type. */
   public StateChangeEventType getType()
   { /*1*/   
   } /*1*/
   
   /** Which Sim generated the event? */
   public Sim getSource()
   { /*1*/   
   } /*1*/
   
   /* package */ 
   
   
   
   /* package */ 
   
   
   
   /** Represent the event as a string. */
   public String toString()
   { /*1*/                 
   } /*1*/
} /*0*/
