/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 

 
 


/**
 * Karel the Robot lives in a city composed of intersections connected
 * by roads.  Roads that run north and south (up and down) are called
 * "Avenues" and roads that run east and west are called "Streets".
 *
 *  <p>Intersections may contain {@link Thing}s such as {@link Flasher}s,
 * {@link Wall}s or {@link Streetlight}s.  Some kinds of things block
 * robots from entering or exiting an intersection.  It is possible
 * to build things which are one-way, blocking robots from entering but
 * not exiting (or visa versa) an intersection.</p>
 *
 * @author Byron Weber Becker
 */
public class Intersection extends Sim implements ILabel
{ /*0*/
   
        
       

   /**
    * Construct a new intersection.
    *  @param city The city in which this intersection exists.
    *  @param avenue The intersection's avenue within the city.
    *  @param street The intersection's street within the city.
    */
   public Intersection(City city, int street, int avenue)
   { /*1*/      
                
                                    
   } /*1*/


   /**
    * The intersection neighboring this one in the given direction.  This
    * always succeeds, even if the intersection is not displayed.
    *  @param dir the direction of the desired neighboring
    * intersection.  
    *  @return the neighboring intersection.
    */
   public Intersection getNeighbor(Direction dir)
   { /*1*/      
              
   } /*1*/

   /** Set a label for this intersection.
    * @param aLabel the new label
    */
   public void setLabel(String aLabel)
   { /*1*/  
      
   } /*1*/

   /** Get the label for this intersection.
    * @return this intersection's label
    */
   public String getLabel()
   { /*1*/   
   } /*1*/
   
   /** Set the predicate used to count the number of things on this intersection;
    *  null if no counts are to be displayed.
    *  @param aPred The predicate to use, or null if none are to be displayed. */
   /* package */ 
    
      
   
   
   /** Display the number of things on this intersection. */
   
     
         
           
         
       
        
      
      
   

   /** Report the internal state of the intersection.
    *  @return The internal state of the intersection.
    */
   public String toString()
   { /*1*/          
            	       
               
   } /*1*/

   /**
    * The avenue intersecting this intersection.
    *  @return The avenue intersecting this intersection.
    */
   public final int getAvenue()
   { /*1*/    
   } /*1*/

   /**
    * The street intersecting this intersection.
    *  @return The street intersecting this intersection.
    */
   public final int getStreet()
   { /*1*/    
   } /*1*/

   /** Used internally.
    *  @return a perfect hash (for all reasonable cases) for the intersection.
    */
   public int hashCode()
   { /*1*/    
   } /*1*/

   /**
    * Return this intersection.
    *  @return This intersection.
    */
   protected Intersection getIntersection()
   { /*1*/   
   } /*1*/

   /**
    * Determine whether something on this intersection blocks robots
    * from exiting the intersection.
    *  @param dir the direction to check for a blockage.
    * One of {{@link Direction}.NORTH, SOUTH, EAST, WEST}.
    *  @return True if a robot facing <code>direction</code> is blocked from
    * exiting the intersection; false otherwise.
    */
   protected boolean exitIsBlocked(final Direction dir)
   { /*1*/      
      
            
                
         
      
         
   } /*1*/

   /**
    * Determine whether something on this intersection blocks robots
    * from entering the intersection from the given direction.
    *  @param dir the direction to check for a blockage.
    * One of {{@link Direction}.NORTH, SOUTH, EAST, WEST}.
    *  @return true if a robot coming from the <code>direction</code> side
    * is blocked from entering the intersection; false otherwise.
    */
   protected boolean entryIsBlocked(final Direction dir)
   { /*1*/      
      
            
                
         
      
         
   } /*1*/

   /**
    * Add a sim to this intersection.  It is called when a robot enters the
    * intersection, when a robot puts a thing in the intersection, or a Sim
    * (robot, streetlight, flasher, wall...) is constructed on this intersection.
    * @see #removeSim
    *  @param theSim The sim to add.
    */
   protected synchronized void addSim(Sim theSim)
   { /*1*/  
   	
   	

      
      
   } /*1*/

   /**
    * Remove the given Sim (robot, flasher, streetlight, wall, and so on)
    * from this intersection.
    * @see #addSim
    *  @param s The Sim to remove.  It is an error to attempt to
    * remove a Sim which isn't on this intersection.
    */
   protected synchronized void removeSim(Sim s)
   { /*1*/   
                      
      
      
      
   } /*1*/   

   /**
    * Determine the number of Things currently on this intersection.
    *  @return The number of Things on this intersection.
    */
   public int countThings()
   { /*1*/ 	 
   } /*1*/

   /**
    * Determine the number of sims currently on this intersection that
    * match the given predicate.
    * @param pred the predicate that determines which sims to count
    *  @return The number of sims on this intersection.
    */
   public int countSims(IPredicate pred)
   { /*1*/   
   } /*1*/
   
   
   /* package */ 
   
   

   /**
    * Save a representation of this intersection to an output stream.  The
    * default intersection actually does nothing.  Override for intersections
    * which need to save state.  Sims on the intersection are saved
    * separately.
    * @param indent the indentation, for formatting purposes
    * @param out the output stream
    */
   protected void save(String indent, PrintWriter out)
   { /*1*/} /*1*/


   /** Hash the avenue and street to facilitate finding this intersection
    * in a hash table.
    */
    
       
   

   /** Examine all the 
    * <code>Thing</code>s that are on this intersection, one at a time.
    * <code>examineThings</code> returns an iterator, which may be used as follows:
    *
	 * <ul><li>One <code>Thing</code> can be obtained from this intersection with
    * <pre>Thing t = anIntersection.examineThings().next();</pre>
    * If there are no things on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the things on this intersection
    * can be obtained, one at a time, with
    * <pre>for(Thing t : anIntersection.examineThings())
    * {  // do something with t
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Thing> things = anIntersection.examineThings();
    * while (things.hasNext())
    * {  Thing t = things.next();
    *    // do something with t
    * }</pre></ul>
    *
    * @return an interator of all the things on this intersection. */
   public IIterate<Thing> examineThings()
   { /*1*/   
   } /*1*/
   

   /** Examine all the things on this intersection that
    * match the given predicate, one at a time.  One <code>Thing</code> can be obtained with
    * <pre>Thing t = anIntersection.examineThings(aPredicate).next();</pre>
    * If there are no things matching the predicate on the intersection, 
    * an exception is thrown.
    *
    * All of the things on the intersection that match the predicate
    * can be obtained, one at a time, with
    * <pre>for(Thing t : anIntersection.examineThings(aPredicate))
    * {  // do something with t
    * } </pre>
    *
    * @param aPredicate A predicate used to test whether a thing should be 
    * included in the iteration.
    *  @return an interator of all the things on this intersection.
    */
   public IIterate<Thing> examineThings(final IPredicate aPredicate)
   { /*1*/   
   } /*1*/
   
   /** Examine all the robots on this intersection that match
    * the given predicate, one at a time.  Usage is similar to that 
    * documented in {@link #examineThings(IPredicate aPredicate)}.
    *
    * @param aPredicate A predicate used to test whether a robot should be
    * included in the iteration.
    * @return An iterator over all the robots on this intersection that 
    * match the given predicate.*/
   public IIterate<Robot> examineRobots(final IPredicate aPredicate)
   { /*1*/	    
   		   
   			     
   		
   	
   	 
   } /*1*/

   
   /** Examine all the lights on this intersection that match
    * the given predicate, one at a time.  Usage is similar to that 
    * documented in {@link #examineThings(IPredicate aPredicate)}.
    *
    * @param aPredicate A predicate used to test whether a light should be
    * included in the iteration.
    * @return An iterator over all the lights on this intersection that 
    * match the given predicate.*/
   public IIterate<Light> examineLights(final IPredicate aPredicate)
   { /*1*/   
   } /*1*/
} /*0*/
