package becker.robots;


/* package */ 

   /* package */   
   /* package */   
   /* package */   
   
   /* package */
  
        
        
        
   
   
   /** Return a new Position that is changed from this one by the given deltas.
    * @param dx Delta-x
    * @param dy Delta-y
    * @param dz Delta-angle */
   /* package */ 
	          
   
   
   /** Normalize the values for this position to an integer intersection and
    * standard angle. */
   /* package */ 
	  
   
      
   
                
   

