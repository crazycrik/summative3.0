/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 

 


/** A flasher is commonly used to mark construction hazards on
 *  streets and avenues.  Flashers are small enough for a robot to pick
 *  up and carry.  They do not obstruct the movement of robots.  Like
 *  all lights, they can be turned on and off.  Unlike some kinds of lights,
 *  when flashers are "on" their lights cycle on and off.  When flashers
 *  are turned "off" their lights stay off.
 *
 * @author Byron Weber Becker
 */
public class Flasher extends Light
{ /*0*/

   /** Construct a new flasher, initially turned off.
    *  @param city The city in which the flasher will exist.
    *  @param avenue The flasher's initial avenue within the city.
    *  @param street The flasher's initial street within the city.
    */
   public Flasher(City city, int avenue, int street)
   { /*1*/     
   } /*1*/

   /** Construct a new flasher.
    *  @param city The city in which the flasher will exist.
    *  @param avenue The flasher's initial avenue within the city.
    *  @param street The flasher's initial street within the city.
    *  @param isOn True if the flasher is on; false otherwise.
    */
   public Flasher(City city, int avenue, int street, boolean isOn)
   { /*1*/       

         
                 
       
        
      
   } /*1*/

   /** Construct a new flasher held by a robot.
    * @param heldBy the robot holding the flasher.
    */
   public Flasher(Robot heldBy)
   { /*1*/  
         
                 
   } /*1*/

   /** Turn the flasher on so that it begins to flash. */
   public void turnOn()
   { /*1*/      
      
      
   } /*1*/

   /** Turn the flasher off. */
   public void turnOff()
   { /*1*/      
      
      
   } /*1*/

   /**
    * Save a representation of this flasher to an output stream.
    * @param indent the indentation, for formatting purposes
    * @param out the output stream
    */
   protected void save(String indent, PrintWriter out)
   { /*1*/   
         
   } /*1*/
   
   
      
   /** Print this object represented as a string. */
   public String toString()
   { /*1*/     
         
      
         
                 
   } /*1*/


} /*0*/
