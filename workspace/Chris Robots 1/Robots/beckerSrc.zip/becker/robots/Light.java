/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 

/** A light is a kind of thing that can be turned on to make it brighter
 *  and turned off to make it darker.  Some lights can be moved
 *  ({@link Flasher}) while others can't ({@link Streetlight}).
 *
 *  <p>The <code>Light</code> class itself is abstract meaning programmers
 *  cannot construct an instance of <code>Light</code>.  It must be extended 
 *  to create a class that can be instantiated.  This class does
 *  define a common interface for all lights so that that any light may
 *  be turned on or off without knowing what specific kind of light it is
 *  (polymorphism).
 */
public abstract class Light extends Thing
{ /*0*/
   
       
 
   /** Construct a new light with the same default appearance as a Thing.
    *  @param aCity The city in which the light will exist.
    *  @param aStreet The light's initial street within the city.
    *  @param anAvenue The light's initial avenue within the city.
    */
   public Light(City aCity, int aStreet, int anAvenue)
   { /*1*/    
   } /*1*/
 
   /** Construct a new light.
    *  @param aCity The city in which the light will exist.
    *  @param aStreet The light's initial street within the city.
    *  @param anAvenue The light's initial avenue within the city.
    *  @param orientation The light's initial orientation.  A streetlight,
    *  for instance, uses this to determine on which corner of the intersection
    *  it appears.  One of {{@link Direction}.NORTH, EAST, SOUTH, WEST,
    *  NORTHWEST, NORTHEAST, SOUTHWEST, SOUTHEAST}.
    *  @param canBeMoved Specifies whether or not the light can be moved
    *  by a robot.
    *  @param anIcon The icon to use to display this light.
    */
   public Light(City aCity, int aStreet, int anAvenue, Direction orientation, boolean canBeMoved, Icon anIcon)
   { /*1*/       
   } /*1*/

   /** Construct a new Light held by a robot.
    * @param heldBy the robot holding the light.
    */
   public Light(Robot heldBy)
   { /*1*/  
   } /*1*/

   /** Turn the light on. */
   public void turnOn()
   { /*1*/    
   } /*1*/

   /** Turn the light off. */
   public void turnOff()
   { /*1*/    
   } /*1*/

   /** Determine whether or not the light is turned on.
    *  @return true if the light is on; false otherwise.
    */
   public boolean isOn()
   { /*1*/   
   } /*1*/
} /*0*/
