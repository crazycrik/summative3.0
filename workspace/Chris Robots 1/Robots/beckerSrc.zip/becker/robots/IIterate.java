package becker.robots;

 
 


/** The <code>IIterate</code> interface allows the same method to provide an iterator
 * and to be used in a foreach loop.  For example, an intersection has a
 * method, <code>examineThings()</code> that returns an object implementing 
 * <code>IIterate</code>.  It can be used as
 * <pre>Iterator<Thing> things = anIntersection.examineThings();
 * while(things.hasNext())
 * {  Thing t = things.next();
 *    // do something with t
 * }</pre>
 * as well as
 * <pre>for(Thing t : anIntersection.examineThings())
 * {  // do something with t
 * }</pre>
 * 
 * @author Byron Weber Becker */
      
{ /*0*/
   
} /*0*/
