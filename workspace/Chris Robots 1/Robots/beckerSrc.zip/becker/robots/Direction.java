/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


 

/** Constants which define directions in the robot city. 
 *
 * @author Byron Weber Becker */
public enum Direction
{ /*0*/
   
   
   EAST(0), SOUTHEAST(1), SOUTH(2), SOUTHWEST(3), WEST(4), NORTHWEST(5), NORTH(6), NORTHEAST(7);

     
     
     

   /** There are only 8 valid turns, 0-8. */
   
         
      
              
         
         
   
   
   /* package */
   
   
   
   /* package */ 
   
   
   
   /* package */ 
   
   
   
   /* package */  
        
   	          
   	       
   		             
   	
   	 
   
   
   /* package */ 
         
   
   
   /** Which direction {NSEW} is left of this direction?  This direction must be 
    *  one of {NSEW}. */
   public Direction left()
   { /*1*/   
         
          

       
          

       
          

       
          

      
          
      
       
   } /*1*/
   
   
   /** Which direction {NSEW} is right of this direction?  This direction must be 
    *  one of {NSEW}. */
   public Direction right()
   { /*1*/   
         
          

       
          

       
          

       
          

      
          
      
       
   } /*1*/
   
   /** Which direction is opposite this direction? */
   public Direction opposite()
   { /*1*/   
         
          

       
          

       
          

       
          

       
          

       
          

       
          

       
          

      
          
      
       
   } /*1*/
   
   public static void main(String[] args)
   { /*1*/    
        
        
        
        
        
      
          
            
             
      
      
   } /*1*/
   
} /*0*/
