/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


 


/** A new kind of robot with extended capabilities such as
 * turnAround, and turnRight.  RobotSE also makes public a number of protected 
 * methods in Robot.
 *
 * @author Byron Weber Becker
 */
public class RobotSE extends Robot
{ /*0*/

   /** Construct a new RobotSE.
    @param theCity the city in which the robot will be located.
    @param street the robot's initial street
    @param avenue the robot's initial avenue
    @param dir the robot's initial direction
    @param numThings the number of things initially in the robot's backpack*/
   public RobotSE(City theCity, int street, int avenue, Direction dir, int numThings)
   { /*1*/      
   } /*1*/

   /** Construct a new RobotSE with nothing in its backpack.
    @param theCity the city in which the robot will be located.
    @param street the robot's initial street
    @param avenue the robot's initial avenue
    @param dir the robot's initial direction*/
   public RobotSE(City theCity, int street, int avenue, Direction dir)
   { /*1*/     
   } /*1*/

   /** Turn the robot around so it faces the opposite direction. */
   public void turnAround()
   { /*1*/  
      
   } /*1*/

   /** Turn the robot 90 degrees to the right.  This invokes a package access
    * method in Robot to really turn the robot right rather than left three
    * times. */
   public void turnRight()
   { /*1*/  
   } /*1*/

   /** Turn right the given number of times.
    @param numTimes how many times to turn right.  Must be >= 0. */
   public void turnRight(int numTimes)
   { /*1*/     
                
                        
                       
      
   
              
        
      
   } /*1*/

   /** Move the given distance.
    @param howFar how far to move.  Must be >= 0. */
   public void move(int howFar)
   { /*1*/     
                
                        
                       
      
   	
              
        
      
   } /*1*/

   /** Turn left the given number of times.
    @param numTimes how many times to turn left.  Must be >= 0. */
   public void turnLeft(int numTimes)
   { /*1*/     
                
                        
                       
      
   	
              
        
      
   } /*1*/

   /** Pick all the moveable things from the current intersection. */
   public void pickAllThings()
   { /*1*/   
        
      
   } /*1*/

   /** Pick all of the specified kind of things from the current intersection.
    @param kindOfThing The kind of things to pick up */
   public void pickAllThings(IPredicate kindOfThing)
   { /*1*/   
        
      
   } /*1*/

   /** Put all the things in this robot's backpack down on the current intersection. */
   public void putAllThings()
   { /*1*/     
        
      
   } /*1*/

   /** Put all of the specified kind of things from the robot's backpack down
    on the current intersection.
    @param kindOfThing The kind of things to put down */
   public void putAllThings(IPredicate kindOfThing)
   { /*1*/     
        
      
   } /*1*/

   /** Determine whether the robot is facing north.
    @return true if the robot is facing north; false otherwise. */
   public boolean isFacingNorth()
   { /*1*/     
   } /*1*/

   /** Determine whether the robot is facing east.
    @return true if the robot is facing east; false otherwise. */
   public boolean isFacingEast()
   { /*1*/     
   } /*1*/

   /** Determine whether the robot is facing south.
    @return true if the robot is facing south; false otherwise. */
   public boolean isFacingSouth()
   { /*1*/     
   } /*1*/

   /** Determine whether the robot is facing west.
    @return true if the robot is facing west; false otherwise. */
   public boolean isFacingWest()
   { /*1*/     
   } /*1*/

   public int countThingsInBackpack(IPredicate pred)
   { /*1*/   
   } /*1*/
	/*
   public Thing examineThing()
   {  return super.examineThing();
   }
	
   public Thing examineThing(IPredicate kindOfThing)
   {  return super.examineThing(kindOfThing);
   }
   */

   public boolean isBesideThing(IPredicate kindOfThing)
   { /*1*/   
   } /*1*/
	
   public void pickThing(IPredicate kindOfThing)
   { /*1*/  
   } /*1*/
	
   public void pickThing(Thing theThing)
   { /*1*/  
   } /*1*/
	
   public void putThing(IPredicate kindOfThing)
   { /*1*/  
   } /*1*/
	
   public void putThing(Thing theThing)
   { /*1*/  
   } /*1*/
	
   public void save(String indent, PrintWriter out)
   { /*1*/   
   } /*1*/
} /*0*/
