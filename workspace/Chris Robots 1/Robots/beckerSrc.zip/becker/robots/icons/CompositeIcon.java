/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;


 
 
 
 
 


/** A CompositeIcon is composed of two or more icons which, taken
 *  together, form the desired icon. An example is {@link StreetlightIcon}
 *  which composes one icon for the streetlight's post with another for
 *  the light.
 *
 * @author Byron Weber Becker
 */

public class CompositeIcon extends Icon
{ /*0*/

     

   /** Construct a new CompositeIcon out of two icons.
    *  @param background the icon to draw in the background.
    *  @param foreground the icon to draw in front of the background.
    */
   public CompositeIcon(Icon background, Icon foreground)
   { /*1*/  
         
        
        
   } /*1*/

   /** Construct a new CompositeIcon out of an array of icons.  The Icon at
    *  icons[0] will be displayed first, then icons[1], and so on.
    *  @param icons the icons which compose this composite icon.
    *  icons.length >= 1
    */
   public CompositeIcon(Icon[] icons)
   { /*1*/  
         
             
      
        
   } /*1*/
	
   protected void renderImage(Graphics2D g2, int width, int height)
   { /*1*/     
   
              
           
      
              
             
                   
	
         /* + icn.getRotation()*/
          

         
            
         
           

         
         
      
      
 
   } /*1*/
   
     
     
   protected void applyTransforms(Graphics2D g2, int width, int height, double rotation, double relSize)
   { /*1*/    
        
   } /*1*/
   
   protected void markChanged()
   { /*1*/	
   	   
   		
   	
   } /*1*/

   public boolean hasChanged()
   { /*1*/   
   		 
   	
   	
   	   
           
        
      
         
   } /*1*/

   /** Obtain a reference to one of the component icons, perhaps so it can
    *  be modified.
    *  @param index which component icon to return.
    *  0 <= index < this.numComponents().
    */
   public Icon componentIcon(int index)
   { /*1*/         
         
       
                
      
   } /*1*/

   /** Determine the number of component icons in this composite icon.
    *  @return the number of component icons
    */
   public int numComponents()
   { /*1*/   
   } /*1*/

   
   /** Returns null.  To get the color of a composite icon, get the color
    * of one of the components:
    * <pre>Color c = compositeIcon.componentIcon(0).getColor();</pre>
    */
   public Color getColor()
   { /*1*/   
   } /*1*/
   
   /** Has no effect.  To set the color of a composite icon, set the color
    * of one of the components:
    * <pre>Color c = compositeIcon.componentIcon(0).setColor(newColor);</pre>
    */
   public void setColor(Color c)
   { /*1*/
   } /*1*/

} /*0*/
