/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;


 
 
 
 


/** An icon to display an intersection.
 *
 * @author Byron Weber Becker
 */
public class IntersectionIcon extends CompositeIcon
{ /*0*/

   /** An enumeration to specify the different areas of an IntersectionIcon. */
     
   { /*1*/
              } /*1*/

   /** Specify the center area of the intersection icon;  the place where
    *  the avenue and street intersect.
    */
         
            
      
     
       

   /** Construct a new icon with the default colors.
    */
    /*
   public IntersectionIcon()
   {  this(AppProperties.getColor(AppProperties.ROAD_COLOR),
            AppProperties.getColor(AppProperties.INTERSECTION_BACKGROUND_COLOR));
   }
   */

   /** Construct a new icon.
    *  @param roadColor The color used for the avenues and streets.
    *  @param backgroundColor The color used for the areas between avenues
    *  and streets.
    */
   public IntersectionIcon(Color roadColor, Color backgroundColor)
   { /*1*/    
            
          
                
          
                
          
                
          
                
           
               
           
               
           
               
           
               
           
               
           
      
         
   } /*1*/
   
   /** Display the number of Sims on this intersection.
    * @param numSims The number of sims on this icon's intersection. */
   public void setSimCount(int numSims)
   { /*1*/  
         
           
             
          
           
         
      
        
   } /*1*/

   /** Return a reference to an icon representing one component of the
    *  intersection:  the center of the intersection, the street entering
    *  from the east, or the southwest corner, for instance.
    *  @param area One of {{@link IntersectionIcon.Area}.NORTH, SOUTH, EAST, WEST} for
    *  an avenue or street, one of {{@link IntersectionIcon.Area}.NORTHEAST, NORTHWEST,
    *  SOUTHEAST, SOUTHWEST} for an area between the avenues and streets, or
    *  {@link IntersectionIcon.Area}.CENTER for the actual intersection of
    *  the avenue and street.
    *  @return The icon used to display the specified portion of the intersection.
    */
   public Icon componentIcon(Area area)
   { /*1*/     
       
         
           
         

       
           
         

       
           
         

       
           
         

       
           
         

       
           
         

       
           
         

       
           
         

       
           
         
      
       
   } /*1*/
   
   /** Same as colorRoads. */
   public void setColor(Color newColor)
   { /*1*/  
   } /*1*/
   
   /** Returns the color of the central road area. */
   public Color getColor()
   { /*1*/   
   } /*1*/

   /** Change the color of one area of the intersection.
    *  @param area One of {{@link IntersectionIcon.Area}.NORTH, SOUTH, EAST, WEST} for
    *  an avenue or street, one of {{@link IntersectionIcon.Area}.NORTHEAST, NORTHWEST,
    *  SOUTHEAST, SOUTHWEST} for an area between the avenues and streets, or
    *  {@link IntersectionIcon.Area}.CENTER for the actual intersection of
    *  the avenue and street.
    *  @param color The new color for the specified area.
    */
   public void colorArea(Area area, Color color)
   { /*1*/      
      
   } /*1*/

   /** Color the roads on this intersection.
    * @param c the new color */
   public void colorRoads(Color c)
   { /*1*/   
       
       
       
       
   } /*1*/

   /** Color the areas of this intersection that are not roads.
    * @param c the new color */
   public void colorNonRoads(Color c)
   { /*1*/   
       
       
       
   } /*1*/

   
   { /*1*/       
          
       
       
       
       
       
       
       
       
      

        
           
            
          
             
           
            
          
             
           
            
           
            
           
            
           
            

   } /*1*/
} /*0*/

