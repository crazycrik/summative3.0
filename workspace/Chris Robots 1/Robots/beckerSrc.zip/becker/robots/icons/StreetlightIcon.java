/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;


 
 
 


/** An icon used to display a {@link becker.robots.Streetlight}.
 *  @author Byron Weber Becker
 */
public class StreetlightIcon extends CompositeIcon
{ /*0*/  /** Construct a new icon.
    * @param lightColor The color used for the light shining from the
    * streetlight.
    * @param postColor The color used for the streetlight's post.
    * @param relativeSize A value between 0.0 (very small) and 1.0 (large).
    */
   public StreetlightIcon(Color lightColor, Color postColor, double relativeSize)
   { /*1*/     
               
   } /*1*/

         
         
         
         
           
          
           
           
           
           
          
             
           
           
} /*0*/
