/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;

 
 

 
 
 
 
 
 
 
 
 


/** Icons are used to display {@link becker.robots.Robot}s, {@link becker.robots.Intersection}s and 
 *  {@link becker.robots.Thing}s.  This
 *  class is abstract, merely defining what kinds of behaviors are required
 *  by the system.  Subclasses define icons for specific purposes.
 *
 *  <p>A very simple icon which displays a blue square could be
 *  defined as
 *  <blockquote><pre>public class BlueIcon extends Icon
 *  {  public BlueIcon(double relativeSize)
 *     {  super(relativeSize);
 *     }
 *     protected void renderImage(Graphics2D g2, int width, int height)
 *     {  g2.setColor(Color.blue);
 *        g2.fill(new Rectangle2D.Double(0.0, 0.0, 1.0, 1.0));
 *     }
 *   }</pre></blockquote>
 *	  The drawing area is from from 0.0 to 1.0 in both dimensions.  An alternative
 *	  approach that is more consistent with using <code>paintComponent</code> is
 *  <blockquote><pre>public class BlueIcon extends Icon
 *  {  public BlueIcon(double relativeSize)
 *     {  super(relativeSize);
 *     }
 *     protected void paintIcon(Graphics g)
 *     {  g.setColor(Color.blue);
 *        g.fillRect(0, 0, 100, 100);
 *     }
 *   }</pre></blockquote>
 *
 *	  In this approach the implicit drawing area is 100 x 100 pixels.  The system
 *	  scales and rotates the image appropriately when it is drawn.
 *
 *   The {@link ShapeIcon} class makes this even easier.
 *
 *  @author Byron Weber Becker
 */
public abstract class Icon
{ /*0*/
     
       
          
       
       
       
       

   /** A transparent "color" which allows the underlying image to show
    *  through.
    */
   public static final Color transparent = new Color(0, 0, 0, 0);

   /** Construct a new, full-sized, transparent icon. */
   public Icon()
   { /*1*/   
   } /*1*/

   /** Construct a new icon of the specified size. */
   public Icon(double relativeSize)
   { /*1*/   
   } /*1*/

   /** Construct a new icon of the specified color. */
   public Icon(Color color)
   { /*1*/   
   } /*1*/

   /** Construct a new icon of the specified size and color. */
   public Icon(double relativeSize, Color color)
   { /*1*/  
        
        
   } /*1*/
   
   /** Get this icon's current color.
    * @return this icon's current color. */
   public Color getColor()
   { /*1*/   
   } /*1*/

   /** Change the color of this icon. 
    * @param newColor The new color. */
   public void setColor(Color newColor)
   { /*1*/        

      
   } /*1*/
   
   
   /** Get this icon's current transparency.
    * @return A number between 0.0 (fully opaque) and 1.0 (fully transparent). */   
   public double getTransparency()
   { /*1*/   
   } /*1*/
   
   /** Set the transparency for this icon;  that is, the degree to which it
    * permits objects under it show through.
    * @param trans  A number between 0.0 (fully opaque) and 1.0 (fully transparent).*/
   public void setTransparency(double trans)
   { /*1*/         
                       
      
        
      
   } /*1*/

   /** Get the relative size of this icon.
    *  @return a number between 0.0 (very small) and 1.0 (large).
    */
   public double getSize()
   { /*1*/   
   } /*1*/

   /** Change the relative size of this icon.
    *  @param relativeSize a number which specifies how large the icon should
    *  be.  1.0 is as large as possible, 0.5 is half-size, 0.001 is very, very
    *  small.  0.0 < relativeSize <= 1.0.
    */
   public void setSize(double relativeSize)
   { /*1*/         
              
      
        
      
   } /*1*/

   /** Get number of radians this icon is rotated.
    *  @return the icon's rotation */
   protected double getRotation()
   { /*1*/       
   } /*1*/
   
   
   /** Get the label currently being displayed on this icon.
    * @return The label currently displayed. */
   public String getLabel()
   { /*1*/   
   } /*1*/
   
   /** Set the label to display on this icon.
    *  @param aLabel The label to display. */
   public void setLabel(String aLabel)
   { /*1*/     
             
      
        
      
   } /*1*/
   
   /** Mark this icon as changed so it is rendered again. */
   protected void markChanged()
   { /*1*/    
   } /*1*/
   
   /** Has this icon changed since it was last rendered?
    * @return true if this icon has changed since it was last rendered; false otherwise */
   protected boolean hasChanged()
   { /*1*/   
   } /*1*/

   /** Override either this method or {@link #paintIcon} to specify how the 
    *  icon looks.  For this method, the upper left corner
    *  of the icon has coordinates (0,0).  The width and height are both 1.0.
    *  @param g2 the graphics context where the icon should be drawn.
    *  @param width the number of pixels wide the image will be
    *  @param height the number of pixels high the image will be
    */
   protected void renderImage(Graphics2D g2, int width, int height)
   { /*1*/	 
   	 
   	
   } /*1*/
   
   /** Override this method (or {@link #renderImage}) to specify how this icon
    * looks.  For this method, the uper left corner of the icon has coordinates
    * (0,0) and width and height of 100 pixels each.  It's standard position is
    * facing NORTH; other methods will rotate it, if required.
    * @param g The graphics context where the icon should be drawn. */
   protected void paintIcon(Graphics g)
   { /*1*/	
   } /*1*/

   /** Get this icon's image with a preferred size (in pixels). */
   public Image getImage(int width, int height, double rotation)
   { /*1*/     

      
      
      
               
               
               
             
           
      

      
       
           
             

            
               

         
           
            
             
         

         
      
       
   } /*1*/

   
     
         
       

         
       
      

       
           
           
            
              
           
         
            
             
              
             
          
             
         
      

         
         

             
                   
      
        
      

   

   /** Apply translations, scaling and rotation to g2 in preparation
    * for rendering the image.  The standard transformations are:
    * <pre>
    g2.translate(width/2.0, height/2.0);
    g2.scale(width*this.relSize, height*this.relSize);
    g2.rotate(rotation);
    g2.translate( - 0.5,  - 0.5);
    g2.setStroke(new BasicStroke(1.0F / width));
    * </pre>
    * @param g2 The graphics context to apply transformations to
    * @param width the width (in pixels) of the icon
    * @param height the height (in pixels) of the icon
    * @param rotation the rotation of the icon, in radians
    * @param relSize the relative size (0.0 < relSize <= 1.0) of the icon */
   protected void applyTransforms(Graphics2D g2, int width, int height, double rotation, double relSize)
   { /*1*/  
      
           
           
      
       

      
         
   } /*1*/
} /*0*/

