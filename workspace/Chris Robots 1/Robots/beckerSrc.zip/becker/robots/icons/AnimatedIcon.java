/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;

 

 
 
 
 
 
 
 
 


/**
 * <p>An AnimatedIcon displays a sequence of icons, giving the appearance of
 * movement or action.  For example, an object representing a flashing light
 * might use an AnimatedIcon with two icons -- one icon with the light on
 * and one icon with the light off.  More complicated sequences are
 * also possible.</p>
 *
 * @author Byron Weber Becker
 */
public class AnimatedIcon extends CompositeIcon
{ /*0*/

     
     
     
     

   /**
    * Construct an AnimatedIcon which displays the Icons in the given array
    * in order.  Each icon is shown for the same amount of time.
    * @param owner the Sim which will be displaying this icon.
    *  @param icons the Icons to show, in sequence.
    *  @param millisecondsForEachIcon how long to show each icon.
    */
   public AnimatedIcon(Sim owner, Icon[] icons, int millisecondsForEachIcon)
   { /*1*/  
        
        
         
          
   } /*1*/

   /** Start the animation. */
   public void start()
   { /*1*/  
   } /*1*/

   /** Stop the animation. */
   public void stop()
   { /*1*/  
   } /*1*/

   /** Set which image is currently shown.  For example, a subclass may
    want to show a particular image when the animation is stopped.
    @param imageNum The index of the image to show.  0 <= imageNum < icons.length */
   protected void setCurrentImage(int imageNum)
   { /*1*/    
   } /*1*/

   /** Render the image for the current icon. */
   protected void renderImage(Graphics2D g2, int width, int height)
   { /*1*/    
   } /*1*/

   /** Get the image for the current icon.
    */
   public Image getImage(int width, int height, double rotation)
   { /*1*/     
   } /*1*/

   /** Get the next icon in the sequence ready to show. */
   
        
   
   
   
   /** Returns null.  To get the color of an animated icon, get the color
    * of one of the components of the underlying composite icons:
    * <pre>Color c = animatedIcon.componentIcon(0).getColor();</pre>
    */
   public Color getColor()
   { /*1*/   
   } /*1*/
   
   /** Has no effect.  To set the color of an animated icon, set the color
    * of one of the components of the underlying composite icons:
    * <pre>Color c = animatedIcon.componentIcon(0).setColor(newColor);</pre>
    */
   public void setColor(Color c)
   { /*1*/
   } /*1*/

   /** What we do on each tick. */
       
   { /*1*/
         
        
         
      
   } /*1*/
} /*0*/
