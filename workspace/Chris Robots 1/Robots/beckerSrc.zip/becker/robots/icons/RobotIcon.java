/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;

 
 
 
 
 


/** An icon used to display a robot.
 *
 * @author Byron Weber Becker
 */
public class RobotIcon extends ShapeIcon
{ /*0*/
      

   /** Construct a new icon of the given color with the default size. */
   public RobotIcon(Color color)
   { /*1*/   
   } /*1*/

   /** Construct a new icon with the given color and size.
    *  @param color The icon's color.
    *  @param relativeSize A number between 0.0 (very small) and 1.0 (large).
    */
   public RobotIcon(Color color, double relativeSize)
   { /*1*/    
   } /*1*/

/*
   protected void renderImage(Graphics2D g2, int width, int height)
   {	System.out.println("Rendering RobotIcon");
   	super.renderImage(g2, width, height);
   }
*/


   
   { /*1*/     
       
       
       
       
      
   } /*1*/
} /*0*/
