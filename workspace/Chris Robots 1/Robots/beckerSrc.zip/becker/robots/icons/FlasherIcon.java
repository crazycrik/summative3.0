/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;

 
 
 

 
 
 


/** Display the current state of a {@link becker.robots.Flasher}, based on the flasher's
 *  current state.  In particular, if the flasher is "on", then cycle
 *  between two images to simulate the flashing action of the flasher.
 *
 * @author Byron Weber Becker
 */
public class FlasherIcon extends AnimatedIcon
{ /*0*/

   
            
            
            
         
         


   /** Construct a new FlasherIcon.
    *  @param owner the owner of this icon, typically an instance of Flasher.
    *  @param base the desired color of the flasher's base.
    *  @param onColor the desired color of the light when it is on.
    *  @param offColor the desired color of the light when it is off.
    *  @param relativeSize a value between 0.0 (very small) and 1.0 (large).
    *  @param millisecondsPerFlash the number of milliseconds between flashes.
    */
   public FlasherIcon(Sim owner, Color base, Color onColor, Color offColor,
         double relativeSize, int millisecondsPerFlash)
   { /*1*/  
             
            
             
             
       
   } /*1*/

   /** Construct a new FlasherIcon with default colors and flash rate.
    *  @param owner the owner of this icon, typically an instance of Flasher.
    *  @param relativeSize a value between 0.0 (very small) and 1.0 (large).
    */
   public FlasherIcon(Sim owner, double relativeSize)
   { /*1*/     
             
   } /*1*/

   /** Construct a new FlasherIcon with default colors.
    *  @param owner the owner of this icon, typically an instance of Flasher.
    *  @param relativeSize a value between 0.0 (very small) and 1.0 (large).
    *  @param millisecondsPerFlash the number of milliseconds between flashes.
    */
   public FlasherIcon(Sim owner, double relativeSize, int millisecondsPerFlash)
   { /*1*/     
             
   } /*1*/

   /** Construct a new FlasherIcon with default colors, size and flash rate.
    *  @param owner the owner of this icon, typically an instance of Flasher.
    */
   public FlasherIcon(Sim owner)
   { /*1*/     
             
   } /*1*/

   public void stop()
   { /*1*/  
      
   } /*1*/
   
   /** Get the color of the flasher's base. */
   public Color getColor()
   { /*1*/   
   } /*1*/
   
   /** Set the color of the flasher's base. */
   public void setColor(Color c)
   { /*1*/  
   } /*1*/
   
        
   { /*1*/

        
        
        

              
        
           
           
           
      
      
        
         
      
      
         
          
      

             
        
             
          
          
          
          
          
          
          
          
         

         
         

         
         
             

         
         
             
                         
                    
                           
            
         
      
   } /*1*/
} /*0*/

