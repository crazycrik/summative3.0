/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;

 
 

 
 
 


/** A ShapeIcon provides an easy means to make an icon of a particular
 *  shape and color.
 *
 *  <p>The easiest example is
 *  <pre>  private Icon icon = new ShapeIcon(
 *               new Rectangle2D.Double(0.0, 0.0, 1.0, 1.0)), Color.blue);</pre>
 *  A {@link RobotIcon} is defined as
 *  <pre>  public class RobotIcon extends ShapeIcon
 *  {
 *     public RobotIcon(Color color)
 *     {  this(color, 0.8);
 *     }
 *
 *     public RobotIcon(Color color, double relativeSize)
 *     {  super(RobotIcon.shape, color, relativeSize);
 *     }
 *
 *     private static GeneralPath shape;
 *
 *     static
 *     {  shape = new GeneralPath();
 *        shape.moveTo(0.5F, 0.0F);
 *        shape.lineTo(0.0F, 1.0F);
 *        shape.lineTo(0.5F, 0.7F);
 *        shape.lineTo(1.0F, 1.0F);
 *        shape.closePath();
 *
 *     }
 *  }</pre>
 *  The <code>static</code> block initializes the <code>shape</code>
 *  instance variable before it is used in the constructor.  The
 *  same shape is used for each RobotIcon instance.</p>
 *
 * @author Byron Weber Becker
 */
public class ShapeIcon extends Icon implements IColor
{ /*0*/
     

   /** Construct a new icon with the given shape and color.
    *  @param aShape The shape of the icon:  a rectangle, ellipse, or
    *  even a <code>GeneralPath</code>.
    *  @param aColor The color the shape should have.
    */
   public ShapeIcon(Shape aShape, Color aColor)
   { /*1*/    
   } /*1*/

   /** Construct a new icon with the given shape and color.
    *  @param aShape The shape of the icon:  a rectangle, ellipse, or
    *  even a <code>GeneralPath</code>.
    *  @param aColor The color the shape should have.
    *  @param relativeSize A value between 0.0 (very small) and 1.0 (large).
    */
   public ShapeIcon(Shape aShape, Color aColor, double relativeSize)
   { /*1*/   
        
   } /*1*/

   protected void renderImage(Graphics2D g2, int width, int height)
   { /*1*/  
      
   } /*1*/
} /*0*/
