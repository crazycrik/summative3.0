/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;


 
 


/** An icon that breaks or fragments another icon.  Primarily used
 * to display a broken robot.
 *
 * @author Byron Weber Becker
 */
public class BrokenIcon extends Icon
{ /*0*/
     
      

   /** Construct a broken icon.
    @param brokenIcon the icon to break into fragments. */
   public BrokenIcon(Icon brokenIcon)
   { /*1*/  
      
        
   } /*1*/
   
   public Color getColor()
   { /*1*/   
   } /*1*/
   
   public void setColor(Color c)
   { /*1*/  
      
   } /*1*/

   protected void renderImage(Graphics2D g2, int width, int height)
   { /*1*/     
         

               

              
           
             

         
         
              
              
         
          

         
          
         
          

         

         

         
              

      
   } /*1*/

   
   { /*1*/     

                  
            
      
       
       
       
       
       
        

                 
            
      
       
       
       
       
       
        

      
                  
       
       
       
       
       
        

                  
      
       
       
       
       
       
       
        

                  
      
       
       
       
       
        

   } /*1*/

} /*0*/




       
    
    
    
    
    
    


  
        
        
        
        
        
        
   

