/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;

 

 
 
 


/** An icon that shown as a printed label.  A LabelIcon is often combined with
 * another icon using a {@link CompositeIcon}.
 *
 * @author Byron Weber Becker */
public class LabelIcon extends Icon implements ILabel
{ /*0*/
       
           
     
     
        
       
       

   public LabelIcon()
   { /*1*/   
   } /*1*/

   /** Create a new label icon.
    * @param xPos (0.0<xPos<=1.0)
    * @param yPos (0.0<yPos<=1.0)
    */
   public LabelIcon(double xPos, double yPos)
   { /*1*/  
        
        
   } /*1*/

   public void setLabel(String aLabel)
   { /*1*/    
      
             
   } /*1*/

   public String getLabel()
   { /*1*/   
   } /*1*/

   public void setFont(Font f)
   { /*1*/    
      
             
   } /*1*/

   protected void renderImage(Graphics2D g2, int width, int height)
   { /*1*/  

             
           
            
            
                  
                  
           
           
      
         
       
      
      
        
      

   } /*1*/
} /*0*/
