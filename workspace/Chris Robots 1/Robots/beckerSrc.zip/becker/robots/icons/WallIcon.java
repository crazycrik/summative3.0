/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;


 
 
 


/** An icon to display a wall.
 *
 * @author Byron Weber Becker
 */
public class WallIcon extends ShapeIcon
{ /*0*/  
   /** Construct a new black wall icon. */
   public WallIcon()
   { /*1*/  
   } /*1*/
   
   /** Construct a new icon with the given color at full size.
    *  @param color The icon's color.
    */
   public WallIcon(Color color)
   { /*1*/   
   } /*1*/

   /** Construct a new icon with the given color and size.
    *  @param color The icon's color.
    *  @param relativeSize A value between 0.0 (very small) and 1.0 (large).
    */
   public WallIcon(Color color, double relativeSize)
   { /*1*/    
   } /*1*/

       
   
   { /*1*/     
       
       
       
       
       
       
       
       
      
   } /*1*/
} /*0*/
