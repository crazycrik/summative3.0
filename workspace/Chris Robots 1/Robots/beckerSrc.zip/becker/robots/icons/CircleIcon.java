/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots.icons;

 
 


/** A circular icon.
 @author Byron Weber Becker */
public class CircleIcon extends ShapeIcon
{ /*0*/

   /** Construct a new CircleIcon.
    @param c The icon's color. */
   public CircleIcon(Color c)
   { /*1*/       
   } /*1*/

   /** Construct a new CircleIcon.
    @param c The icon's color.
    @param size The relative size of the icon (0.0 < size <= 1.0) */
   public CircleIcon(Color c, double size)
   { /*1*/        
   } /*1*/
} /*0*/ 

