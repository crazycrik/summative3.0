/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


 
 
 
 
 
 


/**
 * A factory object that provides the major user interface components, making
 * customized user interfaces easy to create.  
 * <p>For example, <code>CityFrame</code> contains the following code
 * using <code>RobotUIComponents</code> in its constructor:
 * <pre>
 public CityFrame(City model, int firstVisibleStreet, int firstVisibleAvenue,
 int numVisibleStreets, int numVisibleAvenues)
 {  super();
 this.frame = new JFrame("Robots: Learning to program with Java");
 
 this.frame.addWindowListener(new WindowCloser());
 
 this.ui = new RobotUIComponents(model, firstVisibleStreet, firstVisibleAvenue, 
 numVisibleStreets, numVisibleAvenues);

 this.frame.setJMenuBar(ui.getMenuBar());
 
 JPanel view = new JPanel(new BorderLayout());
 CityView sp = ui.getCityView();

 view.add(sp, BorderLayout.CENTER);
 view.add(ui.getControlPanel(), BorderLayout.EAST);

 this.frame.setContentPane(view);
 this.frame.pack();
 this.frame.repaint();
 this.frame.setVisible(true);
 }

 * </pre>
 *@author Byron Weber Becker
 */
public class RobotUIComponents extends Object
{ /*0*/

   /* package access so we can test */
    
    

    
    
     
     

   
  
        
   

   /** Create the components for a default view of the city using the defaults
    * in becker.robots.ini for the visible streets and avenues and intersection size.
    * @param model the city to show */
   public RobotUIComponents(City model)
   { /*1*/  
           
           
           
           
           
   } /*1*/

   /** Create the components to view a specified section of the city.
    * @param model the city to show
    * @param leftAve the leftmost avenue to show
    * @param topStr the topmost street to show
    * @param width the number of avenues to show
    * @param height the number of streets to show 
    * @param simSize the size, in pixels, of each sim (ie: the size of one intersection) */
   public RobotUIComponents(City model, int leftAve, int topStr, int width, int height, int simSize)
   { /*1*/        
   } /*1*/

   /** Create the components to view a specified section of the city.
    * @param model the city to show
    * @param leftAve the leftmost avenue to show
    * @param topStr the topmost street to show
    * @param width the number of avenues to show
    * @param height the number of streets to show  */
   public RobotUIComponents(City model, int leftAve, int topStr, int width, int height)
   { /*1*/        
   } /*1*/
   
   /** Get a slider to control the speed of the animation. 
    * @return a slider to control the speed */
   public JSlider getSpeedSlider()
   { /*1*/   
   } /*1*/
   
   /** Get a button to start and stop the animation 
    * @return a start/stop button */
   public JButton getStartStopButton()
   { /*1*/   
   } /*1*/
   
   /** Get a component that shows the city and the city's scrollbars.
    * @return a component showing the city */
   public CityView getCityView()
   { /*1*/   
   } /*1*/
   
   /** Get the city's viewport -- the view of the city without labels or scrollbars.
    * @return the component showing the city */
   
   /* package */ 
   
   
   
   /** Get a component that causes the view to zoom in on the city
    * @return a component controlling zoom */
   public JSlider getZoom()
   { /*1*/   
   } /*1*/
   
   /** Get a panel grouping the start/stop button and speed slider together
    * @return a control panel */
   public JPanel getControlPanel()
   { /*1*/   
   } /*1*/
   
   /** Get a panel grouping the city's view with the traditional control panel.
    * @return the traditional UI */
   public JPanel getUI()
   { /*1*/       

       
       
      
       
   } /*1*/

   /**
    * Get the menu bar for the user interface.
    * @return the application's menu bar.
    */
   public JMenuBar getMenuBar()
   { /*1*/      
      
       
       
      
         
      

          
       
      

          
       
      

          
       
            
       
      
            
            
              
               
            
         
      
      
      

      
       
       
   } /*1*/
   
   
    
      

           
         
      

          
         
         
        
   

   
      
        

      

      
      

      /*
       this is what currently keeps the width of the control panel from
       changing when the text on the start/pause button changes.  This should
       be based on the width of the button, but don't know how. */
        

      
            
      
      
      
      

       
   

   /** Quit the application. */
   public void quitApp()
   { /*1*/   
        
         
      

   } /*1*/

       
   { /*1*/
         
            
           
               
            
            
              
            
                   
                
               
               
                     
               
            
            
         

      
   } /*1*/


       
   { /*1*/
         
           
         
          
           
              
               
            
            
         
      
   } /*1*/

} /*0*/
