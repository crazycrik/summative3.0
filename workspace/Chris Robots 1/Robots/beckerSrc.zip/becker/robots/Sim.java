/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 
 
 


/** A Sim is an element of the robot city which participates in the
 *  simulation, namely a Thing (such as Walls, Lights), a Robot, or an
 *  Intersection.
 *
 *  <p>Since this class is abstract it cannot be instantiated; only
 *  subclasses may be instantiated.  This class exists to ensure that
 *  basic services required for the simulation are present and to provide
 *  common implementations for required several services.
 *
 *  @author Byron Weber Becker
 */
public abstract class Sim
{ /*0*/
	/*
   private double xPos;
   private double yPos;
   private double angle;
   */
     
     
     

   /** Construct a new Sim.
    *  @param aCity The city in which the Sim will exist.
    *  @param aStreet The Sim's initial street within the city.
    *  @param anAvenue The Sim's initial avenue within the city.
    *  @param orientation The Sim's initial orientation.  One of
    *  {{@link Direction}.NORTH, EAST, SOUTH, WEST, NORTHWEST, NORTHEAST,
    *  SOUTHWEST, SOUTHEAST}.
    *  @param anIcon The icon to use to display this Sim.
    */
   public Sim(City aCity, int aStreet, int anAvenue, Direction orientation, Icon anIcon)
   { /*1*/  
   	     

      /*
       if (Directions.FIRST_DIRECTION <= orientation
       && orientation <= Directions.LAST_DIRECTION)
       {  this.angle = Directions.ANGLES[orientation];
       } else
       {  throw new IllegalArgumentException(
       "Invalid orientation = " + orientation
       + ".  Should be a constant defined in the Directions class.");
       }*/
        
        
      
   } /*1*/
   
   
   /** Set this sim's color.
    * @param color The new color for this Sim. */
   public void setColor(Color color)
   { /*1*/  
        
   } /*1*/
   
   /** Get this sim's color.
    * @return this sim's color. */
   public Color getColor()
   { /*1*/   
   } /*1*/
   
   /**
    * Return the icon used to display the visible characteristics of
    * this sim, based on the sim's current state.
    * @return The icon used to display this sim.
    */
   public Icon getIcon()
   { /*1*/   
   } /*1*/

   /**
    * Set the icon used to display this sim.
    * @param theIcon The new icon to use in displaying this Sim.
    */
   public void setIcon(Icon theIcon)
   { /*1*/    
        
   } /*1*/

   /**
    * Notify any observers of this Sim (for instance, the user interface)
    * that it has changed.
    */
   public void notifyObservers()
   { /*1*/  
   } /*1*/

   /**
    * Notify any observers of this Sim (for instance, the user interface)
    * that it has changed.
    * @param changeInfo Any extra information required by the observer.
    */
   protected void notifyObservers(Object changeInfo)
   { /*1*/   
   } /*1*/

   /**
    * Return the intersection where this Sim is located.
    *  @return The intersection where this Sim is located.
    */
      

   /**
    * This method is called when a key is typed and keyboard input is directed
    * to karel's world (the map, as opposed to a different window or the
    * controls for karel's world).  Override the method to add behavior.
    * @param key The key that was typed.
    */
   protected void keyTyped(char key)
   { /*1*/} /*1*/

   /** Print this object represented as a string. */
   public String toString()
   { /*1*/         
                       
   } /*1*/

   /** Return the current x position of the Sim.  In the case of a moving
    *  robot, this may not be an integer.
    */
   
   
   

   /** Return the current y position of the Sim.  In the case of a moving
    *  robot, this may not be an integer.
    */
   
   
   

   /** Return the angle or orientation of this Sim expressed in radians.
    *  The direction EAST is 0.0 radians.  The angle increases in the
    *  clockwise direction.
    */
   
   
   
   
   /* package */ 
	  
   
   
   /* package */ 
	 
   

   /** Wait until the simulation has been started. */
    
  
         
           
         
         
      
   

   /** Returns a reference to this sim's city. */
   public City getCity()
   { /*1*/   
   } /*1*/

	/** Set the current location (intersection) of the robot.  Called from 
	 * Intersection.addSim.
	 */
	/* package */ 
	   
	
   
   
   
       
                 
   

} /*0*/
