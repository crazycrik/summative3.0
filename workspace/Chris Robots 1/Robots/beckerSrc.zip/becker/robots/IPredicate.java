/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


/** A predicate says whether something is true or false about a
 *  {@link Sim}.  A class implementing the IPredicate interface does
 *  this via the {@link #isOK isOK} method which returns <code>true</code>
 *  if some condition about a Sim is true and <code>false</code> otherwise.
 *
 *  <p>A typical use for a predicate is to find a certain kind of thing
 *  for a robot to examine; for example,
 *  a Light.  To do this, define a class implementing IPredicate as follows:
 *  <pre>  public class ALightPred implements IPredicate
 *  {  //return true if the Sim passed is a Light, false otherwise
 *     public boolean isOK(Sim s)
 *     {  return s instanceof Light;
 *     }
 *  }</pre>
 *  In a subclass of Robot invoke the <code>examineThings</code> method
 *  like this:
 *  <pre>    Light t = this.examineLights(new ALightPred()).next()</pre>
 *  which will return a light from the current intersection that matches the 
 *  predicate, if there is one.  If there isn't, an exception will be thrown.
 *
 *  <p><code>IPredicate</code> also defines a number of useful
 *  predicates as constants.  For example, to pick up a <code>Thing</code>
 *  that is a <code>Flasher</code>, one could write
 *  <pre>  karel.pickThing(IPredicate.aFlasher);</pre></p>
 *
 *  @author Byron Weber Becker
 */
   
{ /*0*/

   /** Return true if a certain condition is true about theSim;
    *  false otherwise.
    *  @param theSim The Sim object to test.
    *  @return true if a condition is true; false otherwise.
    */
       
   
   /** A predicate to test whether something is a Flasher.
    * Example Usage: <code>karel.pickThing(IPredicate.aFlasher);</code> to pick
    * up a Flasher (but not a subclass of Flasher) from the current intersection. */
   public static final IPredicate aFlasher = new  IPredicate()
   {
      public boolean isOK(Sim s)
      {  try
         {  return s.getClass() == Class.forName("becker.robots.Flasher");
         } /*0*/   
         { /*0*/   
         } /*0*/
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether something is a Flasher or a subclass of Flasher.
    * Example Usage: <code>karel.pickThing(IPredicate.anyFlasher);</code> to pick
    * up a Flasher (or a subclass of Flasher) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/     
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether something is a Light.
    * Example Usage: <code>karel.pickThing(IPredicate.aLight);</code> to pick
    * up a Light (but not a subclass of Light) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/  
         { /*0*/     
         } /*0*/   
         { /*0*/   
         } /*0*/
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether something is a Light or a subclass of Light.
    * Example Usage: <code>karel.pickThing(IPredicate.anyLight);</code> to pick
    * up a Light (or a subclass of Light) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/     
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether something is a Robot.
    * Example Usage: <code>karel.pickThing(IPredicate.aRobot);</code> to examine
    *  a Robot (but not a subclass of Robot) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/  
         { /*0*/     
         } /*0*/   
         { /*0*/   
         } /*0*/
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether something is a Robot or a subclass of Robot.
    * Example Usage: <code>karel.pickThing(IPredicate.anyRobot);</code> to examine
    * a Robot (or a subclass of Robot) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/     
      } /*-1*/
   } /*-2*/
   
   /** A predicate to test whether something is a Streetlight.
    * Example Usage: <code>karel.examineThing(IPredicate.aStreetlight);</code> to examine
    * a Streetlight (but not a subclass of Streetlight) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/  
         { /*0*/     
         } /*0*/   
         { /*0*/   
         } /*0*/
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether something is a Streetlight or a subclass of Streetlight.
    * Example Usage: <code>karel.examineThing(IPredicate.anyStreetlight);</code> to examine
    * a Streetlight (or a subclass of Streetlight) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/     
      } /*-1*/
   } /*-2*/
   
   /** A predicate to test whether something is a Thing.
    * Example Usage: <code>karel.pickThing(IPredicate.aThing);</code> to pick
    * up a Thing (but not a subclass of Thing) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/  
         { /*0*/     
         } /*0*/   
         { /*0*/   
         } /*0*/
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether something is a Thing or a subclass of Thing.
    * Example Usage: <code>karel.pickThing(IPredicate.anyThing);</code> to pick
    * up a Thing (or a subclass of Thing) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/     
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether the Thing is something that a robot can carry.
    * Example Usage: <code>karel.pickThing(IPredicate.canBeCarried);</code> to pick
    * up a Thing (or a subclass of Thing) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/       
      } /*-1*/
   } /*-2*/
   
   /** A predicate to test whether something is a Wall.
    * Example Usage: <code>karel.examineThing(IPredicate.aWall);</code> to examine
    * a Wall (but not a subclass of Wall) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/  
         { /*0*/     
         } /*0*/   
         { /*0*/   
         } /*0*/
      } /*-1*/
   } /*-2*/

   /** A predicate to test whether something is a Wall or a subclass of Wall.
    * Example Usage: <code>karel.pickThing(IPredicate.aWallPred);</code> to examine
    * a Wall (or a subclass of Wall) from the current intersection. */
          
   { /*-2*/
         
      { /*-1*/     
      } /*-1*/
   } /*-2*/
} /*-3*/
