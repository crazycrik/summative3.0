/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


 
 
 
 
 


/** A graphical view of the city and its contents, including scrollbars to
 * reveal different parts of the city.
 *
 * @author Byron Weber Becker */
public class CityView extends JPanel
{ /*0*/
     
     
     
     
     
	
   protected CityView(City aModel, Rectangle roads, int simSize)
   { /*1*/  
           
          
          
          
          
      
   } /*1*/
	
   
     
            
              
      
       
      

          
      
		
          
        
        
        
        
        
        
       
        
        
       
        
        
       
        
        
       
        
        
       
        
   
	
   /** Get the view port for the city -- the component that shows the city. */
   
   /* package */ 
   
   
   
   /** The number of pixels square that each Sim (intersection, robot, etc) 
    * occupies.
    * @return the number of pixels on each side of a painted Sim */ 
   public int getSimSize()
   { /*1*/   
   } /*1*/
	
   /** Set the number of pixels square that each Sim (intersection, robot, etc) 
    * occupies.
    * @param theSize the new size for sims */
   public void setSimSize(int theSize)
   { /*1*/  
   } /*1*/
	
   /** Get the avenue to display at the origin. */
   public int getLeftAvenue()
   { /*1*/   
   } /*1*/
	
   /** Get the street to display at the origin. */
   public int getTopStreet()
   { /*1*/   
   } /*1*/
	
   /** Set the avenue and street to display at the origin (top left corner)
    * of the city.
    * @param str the street to display 
    * @param ave the avenue to display */
   
   public void setOrigin(int str, int ave)
   { /*1*/   
   } /*1*/

} /*0*/
