package becker.robots;


/** Report an error with the operation of a Robot such as running
 * into a wall or attempting to pick or put a thing when it can't.
 *
 * @author Byron Weber Becker */
public class RobotException extends java.lang.RuntimeException
{ /*0*/

   /** Construct a new instance of RobotException.
    * @param msg An explanatory error message. */
   public RobotException(String msg)
   { /*1*/  
   } /*1*/
} /*0*/
