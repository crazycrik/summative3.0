/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


 
 
 
 
 
 
 
 
 
 
 
 
 


/** A city contains intersections joined by streets and avenues.
 *  {@link Intersection}s may contain {@link Thing}s such as walls,
 *  streetlights, flashers, and robots.  
 *
 * @author Byron Weber Becker
 */
public class City
{ /*0*/      
       
        

        
        
        
        
       
       

   /** Construct a new city using the defaults stored in the becker.robots.ini
    * initialization file. */
   public City()
   { /*1*/  
           
           
           
           
   } /*1*/
   
   /** Construct a new City which displays streets 0 through
    *  <code>numVisibleStreets-1</code> and avenues 0 through
    *  <code>numVisibleAvenues-1</code>.
    *  @param numVisibleStreets The number of streets to display.
    *  @param numVisibleAvenues The number of avenues to display.
    */
   public City(int numVisibleStreets, int numVisibleAvenues)
   { /*1*/     
   } /*1*/

   /** Construct a new City which displays streets <code>firstVisibleStreet</code> through
    *  <code>numVisibleStreets-1</code> and avenues <code>firstVisibleAvenue</code> through
    *  <code>numVisibleAvenues-1</code>.
    *
    *  @param firstVisibleStreet The street of the upper left intersection.
    *  @param firstVisibleAvenue The avenue of the upper left intersection.
    *  @param numVisibleStreets The number of streets to display
    *  @param numVisibleAvenues The number of avenues to display
    */
   public City(int firstVisibleStreet, int firstVisibleAvenue,
         int numVisibleStreets, int numVisibleAvenues)
   { /*1*/  
        
             
   } /*1*/

   /** Construct a new City.  By default, an implicit frame is created which 
    *  displays the intersection at 
    *  <code>firstVisibleStreet</code> and <code>firstVisibleAvenue</code>
    *  in the upper left corner of the City.  <code>numVisibleStreet</code> 
    *  streets and <code>numVisibleAvenues</code> avenues
    *  are displayed below and to the right.  Use {@link #showFrame} to avoid
    *  creating the implicit frame.
    *
    *  @param firstVisibleStreet The street of the upper left intersection.
    *  @param firstVisibleAvenue The avenue of the upper left intersection.
    *  @param numVisibleStreets The number of streets to display
    *  @param numVisibleAvenues The number of avenues to display
    *  @param intersectionSize The number of pixels each intersection takes up
    */
   public City(int firstVisibleStreet, int firstVisibleAvenue,
         int numVisibleStreets, int numVisibleAvenues, int intersectionSize)
   { /*1*/  
        
             
   } /*1*/

   /** Construct a new city by reading information to construct it
    *  from a file.  The file format is documented in {@link #City(Scanner)}.
    *  @param fileName the name of the file containing the information to
    *       build this city. */
   public City(String fileName)
   { /*1*/  
   	
       
             
         
         
          
        
         
      
   } /*1*/

   
     
      
          
              
      
         
         
         
         
         
      
   	
       
        
      
       
       
            
         
      
   
   
   
   
   
        
      
       
   
	
   /** Construct a new city by reading information to construct it
    *  from a file.  The file format is the same as that produced by using
    *  the "Save" command in a running program.  
    *
    *	 The first lines in the file must contain the following information in
    *  the order given.  Comments and blank lines (see below) may be interspersed between
    *  these three lines.
    *  <ol>
    *	 <li>A string, to be used as the window's title.</li>
    *	 <li>Four integers:  first Street, first Avenue, number of visible streets, number of visible avenues</li>
    *  <li>One integer: the size of the intersections, in pixels</li>
    *  </ol>
    *
    *  Each of the remaining lines in the file
    *  must have one of three formats:
    *  <ul>
    *   <li>A blank line</li>
    *   <li>A comment, which begins with the '#' character and extends to the 
    *       end of the line.</li>
    *   <li>A fully-qualified class name such as <code>becker.robots.Robot</code>,
    *       <code>becker.robots.Wall</code> or <code>becker.robots.Thing</code>.
    *			Classes that extend <code>Thing</code> (which includes extensions of 
    *			<code>Robot</code>) may also be included provided the class is
    *			in the program's classpath.  Under normal usage, it will be without
    *			any special action.
    *			<p>The class name is followed by the information that would normally
    *			be passed to its constructor, except for the <code>City</code>.  
    *			</p>
    *	   </li>
    *  </ul>
    *	 <p>For example,
    *    <blockquote><pre>
# A city with one robot, one thing and one wall.
# Window title
Clear snow
# first street, first avenue, num streets, num avenues
0 0 5 9
# intersection size
38

becker.robots.Robot 1 2 Direction.EAST 
becker.robots.Thing 2 2
becker.robots.Wall 2 2 Direction.EAST
    *    </pre></blockquote>
    *  </p>
    *  
    *  @param in the open file containing the information to
    *       build this city. */
   public City(Scanner in)
   { /*1*/  
      
   } /*1*/
   
   
   
   
   /** make the frame */
   

   
               
                  
                          
                        
         

             
                  
                  	
                 
          
              
              
                 
                  
                 	
               
            
         

         
      
              
         
            

          
          

         
         
         
         

      
   
   
   /** Should the city be shown in a frame?  The default is to show it.  Not
    * showing it is useful if for automated testing and if you want to provide 
    * your own controls for the window.  See {@link RobotUIComponents}.
    *
    * This method, if used, must be called before the City object is constructed.
    * 
    * @param show True to show the city inside a frame; false otherwise.
    */
   public static void showFrame(boolean show)
   { /*1*/	
        
   } /*1*/

   /** Show the number of Things and Robots on each intersection, counted according to
    * the predicate set with {@link #setThingCountPredicate}.  The default
    * predicate counts things that can be moved by a robot.
    * @param show true if the number of things should be shown; false otherwise
    */
   public void showThingCounts(boolean show)
   { /*1*/    
       
        
       
        
      
   } /*1*/

   /** Is the city showing the number of Things and Robots on each intersection?
    * @return true if the city is showing counts; false otherwise
    */
   public boolean isShowingThingCounts()
   { /*1*/   
   } /*1*/
   
   /** Set the predicate for what kinds of things to count when showing
    * the number of things on each intersection.  The default counts the
    * number of things that can be moved by a robot.
    * @param pred A predicate that returns true if the Thing/Robot should be counted,
    * false otherwise.
    */
   public void setThingCountPredicate(IPredicate pred)
   { /*1*/    
      
   } /*1*/
   
   /** Propagate the predicate to the intersections. */
   
     
       
            
         
      
   

   /** Get the predicate used to show counts on the city's intersections.
    * @return The current predicate; null if none is in use. */
   public IPredicate getThingCountPredicate()
   { /*1*/   
   } /*1*/
   
   /** Sets the title of the implicitly created frame, if there is one.
    *  @param title The frame's title */
   public void setFrameTitle(String title)
   { /*1*/     
        
      
   } /*1*/
   
   /** Set the size of the implicitly created frame, if there is one.
    * @param width the width of the frame, in pixels
    * @param height the height of the frame, in pixels */
   public void setSize(int width, int height)
   { /*1*/     
         
      
   } /*1*/
   
   
  
      
      
          
      
      
       
        
      
      
      
         
         
        
      

      

          
      
          
      
      
      
       
         
              
             
            
            
            
            
            
            
            
            
              
         
             
                
            
            
             
                 
               
               
                
              
               
            
            
         
      
      
      
      
      
           

         
       
        
              
               
               
            

            
            
                   
                       
                     
               

                          
                        
             
                
            
            
                    
                       
            
                  
            
         
      
   

   /** Obtain a reference to a specified intersection within this city.
    *  @param street the street of the desired intersection
    *  @param avenue the avenue of the desired intersection
    *  @return the specified intersection.
    */
   protected Intersection getIntersection(int street, int avenue)
   { /*1*/      
       
   } /*1*/

   /** Make an intersection which will appear at the specified avenue
    *  and street.  This method simply instantiates an Intersection
    *  object by default.  Cities which use a subclass of Intersection
    *  should override the method to instantiate the desired subclass.
    *
    *  <p><i>Caution:</i> Do not add Things such as Walls or Flashers to
    *  the intersection before returning it;  doing so results in infinite
    *  recursion.  Instead, override
    *  {@link #customizeIntersection customizeIntersection}.</p>
    *
    *  @param avenue the avenue where the intersection will appear within the city.
    *  @param street the street where the intersection will appear within the city.
    *  @return an Intersection.
    */
   protected Intersection makeIntersection(int street, int avenue)
   { /*1*/        
       
        
      
   
       
   } /*1*/

   /** Customize an intersection, perhaps by adding Things to it.  For
    *  instance, a city which has a wall on the north edge can be implemented
    *  by extending City and overriding customizeIntersection as follows:
    *  <pre>  protected void customizeIntersection(Intersection intersection)
    *  {  if (intersection.getStreet() == 0)
    *     {  new Wall(this, intersection.getAvenue(), 0, Direction.NORTH);
    *     }
    *  }</pre>
    *  @param intersection the intersection to be customized.
    */
   protected void customizeIntersection(Intersection intersection)
   { /*1*/} /*1*/

   /** This method is called when the city's display has the focus and
    a key is typed.
    @param key The character typed at the keyboard. */
   protected synchronized void keyTyped(char key)
   { /*1*/     
              
        
      
   } /*1*/
   

   /** Examine all the 
    * other <code>Robot</code>s, one at a time, that are on the same 
    * intersection 
    * as this robot.  <code>examineRobots</code>
    * returns an iterator, which may be used as follows:
    *
    * <ul><li>One <code>Robot</code> can be obtained with
    * <pre>Robot r = this.examineRobots().next();</pre>
    * If there are no robots on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the robots (except this one) on the intersection
    * can be obtained, one at a time, with
    * <pre>for(Robot r : this.examineRobots())
    * {  // do something with r
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Robot> robots = this.examineRobots();
    * while (robots.hasNext())
    * {  Robot r = robots.next();
    *    // do something with r
    * }</pre></ul>
    *
    * @return an interator of all the robots (other than this robot) on this intersection. 
    * @see #examineThings()
    * @see #examineThings(IPredicate)
    * @see #examineLights()
    */
   public final IIterate<Robot> examineRobots()
   { /*1*/   
   } /*1*/

   /** Examine all the 
    * <code>Light</code> objects in this city, one at a time.  <code>examineLights</code>
    * returns an iterator, which may be used as follows:
    *
    * <ul><li>One <code>Light</code> can be obtained with
    * <pre>Light l = this.examineLights().next();</pre>
    * If there are no lights on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the lights on the intersection
    * can be obtained, one at a time, with
    * <pre>for(Light l : this.examineLights())
    * {  // do something with l
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Light> lights = this.examineLights();
    * while (lights.hasNext())
    * {  Light l = lights.next();
    *    // do something with l
    * }</pre></ul>
    *
    * @return an interator of all the lights on this intersection. 
    * @see #examineThings()
    * @see #examineThings(IPredicate)
    * @see #examineRobots()
    */
   public final IIterate<Light> examineLights()
   { /*1*/   
   } /*1*/


   /** Examine all the 
    * <code>Thing</code>s in this City, one at a time.  <code>examineThings</code>
    * returns an iterator, which may be used as follows:
    *
    * <ul><li>One <code>Thing</code> can be obtained with
    * <pre>Thing t = this.examineThings().next();</pre>
    * If there are no things on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the things on the intersection
    * can be obtained, one at a time, with
    * <pre>for(Thing t : this.examineThings())
    * {  // do something with t
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Thing> things = this.examineThings();
    * while (things.hasNext())
    * {  Thing t = things.next();
    *    // do something with t
    * }</pre></ul>
    *
    * @return an interator of all the things on this intersection. 
    * @see #examineThings(IPredicate)
    * @see #examineLights()
    * @see #examineRobots()
    */
   public final IIterate<Thing> examineThings()
   { /*1*/   
   } /*1*/


   /** Examine all the 
    * <code>Thing</code>s, one at a time, that are in this city
    * and match the provided predicate.  <code>examineThings</code>
    * returns an iterator, which may be used as follows:
    *
    * <ul><li>One <code>Thing</code> can be obtained with
    * <pre>Thing t = this.examineThings(aPredicate).next();</pre>
    * If there are no things matching the predicate on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the things on the intersection that match the predicate
    * can be obtained, one at a time, with
    * <pre>for(Thing t : this.examineThings(aPredicate))
    * {  // do something with t
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Thing> things = this.examineThings(aPredicate);
    * while (things.hasNext())
    * {  Thing t = things.next();
    *    // do something with t
    * }</pre></ul>
    *
    * @param aPredicate A predicate used to test whether a thing should be 
    * included in the iteration.  Commonly used predicates are defined
    * in {@link becker.robots.IPredicate}.
    * @return an interator of all the things on this intersection. 
    * @see #examineThings()
    * @see #examineLights()
    * @see #examineRobots()
    */
   public final IIterate<Thing> examineThings(IPredicate aPredicate)
   { /*1*/   
   } /*1*/

   

   /**
    * Tell if the animation should be running, or not.
    *    @return true if the animation should be running;
    * false otherwise.
    */
   
   
   

   /**
    * Start the animation -- notify observers that the state has changed.
    */
   
  
   

   /** Pause the animation; notify observers. */
   
  
   

   
   
   

   /** Save a representation of this city to a file for later use.
    *  @param indent A string of spaces prepended to each line of output.
    *  @param out an open output stream. */
   public void save(String indent, PrintWriter out)
   { /*1*/           
   
         
               
            
            
            
            
            
       
           
           
            
            
            
            
            
            
      

         
       
            
               
      

        
       
            
      
      	   
      		      
            
      	
      
   } /*1*/
   
   
    
        
              
                       
        
        
      
   

   public String toString()
   { /*1*/         
   } /*1*/

   
   
   

   
   
   

   
   
   

   /** Add a sim to the City. */
    
  
   
   
   
   
   
   

   /** This is here so that we can use the Observer-Observable pattern
    *  AND hide the required methods from students.  If students ever
    *  write their own observers this may prove to be a bad, but easily
    *  reversable, decision.
    */
      
   { /*1*/

         
        
      

         
        
      

        
        
      

           
         
      

           

   } /*1*/


     
   { /*1*/
      
      

          
           
      

        
           
            
         
              
            
                     
                       
         
      

           
             
               
            
              
            
            
         
          
      

       
         
      

             
   } /*1*/
} /*0*/

