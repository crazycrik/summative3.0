/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 

 
 
 
 
 
 
 
 
 
 


/** A CityViewPort displays a city.  It's the central component in the
 * CityView class, but is missing the scrollbars and labels.
 *
 * @author Byron Weber Becker */

/* package */ 


   
        
     
     
     
     
        
        
	
   /** Construct a new view port.
    * @param aModel the city to display
    * @param roads the roads to display. 
    * @param simSize the size of each sim to display */
   
  
        
        
       
      

      

   
	
   
   
   
	
   /** The number of pixels square that each Sim (intersection, robot, etc) 
    * occupies.
    * @return the number of pixels on each side of a painted Sim */ 
   
   /* package */ 
   
   
	
   /** Set the number of pixels square that each Sim (intersection, robot, etc) 
    * occupies.
    * @param theSize the new size for sims */
   /* package */ 
    
      
       
   
	
   /** Get the avenue to display at the origin. */
   
   /* package */ 
   
   
	
   /** Get the street to display at the origin. */
   
   /* package */ 
   
   
	
   /** Set the avenue and street to display at the origin (top left corner)
    * of the city.
    * @param str the street to display
    * @param ave the avenue to display */
   /* package */ 
    
         
            
           
           
               
              	
      

        
         
            
           
           
               
              	
      
      
       
   
   
   /* package */ 
       
       
   

   /* package */ 
       
       
   

   
   
   
		
   /** Paint the city. */
   
  
   	
          
         
		
         

      
      
         
               
         
               
              
                
               
             
         
      
      
		
		
      
            
              
         
      
      
   
	
   
   
           
                 
            
         
      
   

   
     
   
   	   
         
   	
      
      
         

		   
		   
			
			     

      	   
      
   
	
	/*
   public void repaint()
   {  this.repaint(0, 0, this.getWidth(), this.getHeight());
   }
	
   public void repaint(Rectangle r)
   {  this.clips.add(r);
      super.repaint(r);
   }
	
   public void repaint(int x, int y, int width, int height)
   {  this.repaint(new Rectangle(x, y, width, height));
   }
	*/
	
   
   
   
	
   
        
   
	
   
        
   
		
   
       
   
		
   
       
   
	
   
         
                   
   
   
   
     
   	       
                   
   

   
   
   
	
	
  
	      
	       
	       
               
            
            
            
             
          
            
            
            
             
          
            
             
            
          
               
               
               
               
               
            
             
            
          
              
            
              
            
             
            
           
                               
	   
	
	
	
	
     
        
         
        
   
   
         
         
            
             
         
         
           
            
           
         
      
   

   /** Print this view. */
   
     
         
      
          
       
      
       
   
	
   
   
   
	

   
  
       
   

   
  
   

   
  
   
	
   
     
       
            
          
      
   	

   
   
   
	
   /* package */ 
  
        
          
        
   
	
   /* package */ 
  
        
          
        
   
	
   
   
   
	
	
   
   
       
      
            
           
         

            
           
         
      
       
      
            
           
         
      
      

   
	
      
   
           
            
         
              
              
            
         
         
      
   


