/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 
 

 
 


/** A Streetlight is a kind of {@link Light} that lights an intersection.
 *  Like all lights, it can be turned on and off.  A streetlight
 *  cannot be moved by a robot.
 *
 *  @author Byron Weber Becker
 */
public class Streetlight extends Light
{ /*0*/
             
         
         
     
     

   /** Construct a new streetlight.
    *  @param city The city in which the streetlight will exist.
    *  @param street The streetlight's initial street within the city.
    *  @param avenue The streetlight's initial avenue within the city.
    *  @param corner The corner of the intersection occupied by the
    *  streetlight.  One of {{@link Direction}.NORTHEAST, SOUTHEAST, SOUTHWEST,
    *  NORTHWEST}.
    *  @param isOn True if the streetlight is on when constructed.
    */
   public Streetlight(City city, int street, int avenue, Direction corner, boolean isOn)
   { /*1*/       
       
                   
      
           
           
       
        
       
        
      
   } /*1*/

   /** Construct a new streetlight.  The light is initially off.
    *  @param city The city in which the streetlight will exist.
    *  @param street The streetlight's initial street within the city.
    *  @param avenue The streetlight's initial avenue within the city.
    *  @param corner The corner of the intersection occupied by the
    *  streetlight.  One of {{@link Direction}.NORTHEAST, SOUTHEAST, SOUTHWEST,
    *  NORTHWEST}.
    */
   public Streetlight(City city, int street, int avenue, Direction corner)
   { /*1*/      
   } /*1*/

   /** Turn the streetlight on. */
   public void turnOn()
   { /*1*/  
      
   } /*1*/

   /** Turn the streetlight off. */
   public void turnOff()
   { /*1*/  
      
   } /*1*/

   /**
    * Save a representation of this intersection to an output stream.
    * @param indent the indentation, for formatting purposes
    * @param out the output stream
    */
   protected void save(String indent, PrintWriter out)
   { /*1*/   
         
         
   } /*1*/
   
      
   /** Print this object represented as a string. */
   public String toString()
   { /*1*/     
         
      
         
                 
                 
   } /*1*/

} /*0*/
