/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */
 
package becker.robots;


 
 
 


/** A SimBag stores zero or more Sims.  Sims may be added,
 *  removed or simply retrieved.
 *
 *	 This is should probably just be replaced with a generic collection object
 *	 now that they're available.
 *
 *  @author Byron Weber Becker
 */

/* package */ 
       
       
       

   /* package */



	/** Provide a String representation. */
	
	    
		
		
		
		   
		 
			   
			 
				
				
				  
			
			
		
		
		 
		   
		 
			   
			 
				
				
				  
			
			
		
		
		 
	

   /** Add a new Sim to this vector.
    *  @param theSimToAdd The Sim to add.
    */
   /* package */ 
     
         
         
           
           
         
           
        
       
         
      
   

   /** How many Sims are in this vector?
    *  @return The number of Sims contained in this vector.
    */
   
   /* package */ 
   
   

   /** Count the number of Sims of the given kind that are in the vector.
    *  @param kindOfSim The kind of Sim to count.
    *  @return The number of Sims of the given kind.
    */
   
   /* package */  
     
              
         
           
         
      
       
   

   /** Removes the first occurrence of the specified element in this Vector.
    *  If the Vector does not contain the element, it is unchanged.
    *  @param theSimToRemove The Sim to remove.
    *  @return True if theSimToRemove was found in the vector; false otherwise.
    */
   
   /* package */ 
  
       
           
           
              
           
         
          
       
         
      
   

   /** Get something from this vector that matches <code>kindOfSim</code>.
    *  If no such Sim is present, return null.
    *  @param kindOfSim A predicate which determines what kind of Sim to
    *  get.
    *  @return A Sim from this vector that matches <code>kindOfSim</code>
    *  or null if no such Sim exists.
    */
   
   /* package */ 
       
       
           
            
         
             
          
            
         
         
      
   


    
     
   
   
   
   /** Get an iterator over the lights (and subclasses) on this intersection. */
   
    
   
   
   /** Get an iterator over the robots (and subclasses) on this intersection. */
   
    
   
   
   /** Get an iterator over the robots (and subclasses) on this intersection. */
   
    
   
   
   /** Get an iterator over the things (and subclasses) on this intersection. 
    */
   
    
   
   
   /** Get an iterator over the things (and subclasses) on this intersection
    *  that match the provided predicate.
    *  @param aPredicate The predicate to use in deciding whether the thing matches. */
   
    
   
   
   
   /** An iterator returning only certain kinds of elements from the SimBag.
    * The Element parameter specifies return types, and so on.  The IPredicate 
    * specified in the constructor is what actually does the testing.  This
    * is necessary because of the type-erasure implementation of generics in
    * Java (ie: can't use instanceof).  The type of Element MUST BE compatible
    * with the predicate. */
       
   
             
                              
             
        
            
      
        
        
           
      
      
        
           
      
      
        
           
            
             
          
              
                 
              
              
               
             
         
      
      
        
           
              
         
              
               
               
               
            
            
         
      
      
        
          
      
      
        
         
      
   

