/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;


/** A Remote Control Robot, RobotRC for short, can be directed from a
 computer keyboard.  The city's view must have the keyboard focus when
 the program is running for the robot to receive the instructions from
 the keyboard.  When the city's view has the focus it will have a thin
 black outline.  Shift the focus between the speed control, the start/stop
 button on the city's view with the tab key.
 @author Byron Weber Becker */
public class RobotRC extends Robot
{ /*0*/

   /** Construct a new RobotRC robot.
    @param theCity the City where the robot will reside.
    @param street the robot's initial street.
    @param avenue the robot's initial avenue.
    @param dir the robot's initial direction.
    @param numThings the number of things initially in the backpack. */
   public RobotRC(City theCity, int street, int avenue, Direction dir, int numThings)
   { /*1*/      
   } /*1*/
	
   /** Construct a new RobotRC robot with nothing in its backpack.
    @param theCity the City where the robot will reside.
    @param avenue the robot's initial avenue.
    @param street the robot's initial street.
    @param dir the robot's initial direction. */
   public RobotRC(City theCity, int street, int avenue, Direction dir)
   { /*1*/     
   } /*1*/

   /** Respond to the following keys in the given manner:
    *
<blockquote><table><tr><td>Keys</td><td>Response</td></tr>
<tr><td>m, M</td><td>move</td></tr>
<tr><td>r, R</td><td>turn right</td></tr>
<tr><td>l, L</td><td>turn left</td></tr>
<tr><td>u, U</td><td>pick up a thing</td></tr>
<tr><td>d, D</td><td>put down a thing</td></tr></table></blockquote>
   
   * @param key The key typed at the keyboard. */
   protected void keyTyped(char key)
   { /*1*/         
        
               
        
               
        
               
        
               
        
      
   } /*1*/

} /*0*/ 
 
