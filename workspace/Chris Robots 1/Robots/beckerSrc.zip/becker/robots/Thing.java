/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 
 

 
 
 


/** A Thing is something that can exist on an intersection.  All things
 *  have a location (avenue and street).  Some things can be picked up
 *  and moved by a robot (Flashers) while others cannot (Streetlights, Walls).
 *
 *  <p>In addition to a location, all things have an orientation although
 *  it is common for the orientation to always have a default value.  Examples
 *  where that is not the case is a wall where the orientation determines
 *  which exit or entry into an intersection is blocked and a streetlight
 *  where the orientation determines which corner of the intersection
 *  it occupies.</p>
 *
 *  @author Byron Weber Becker
 */
public class Thing extends Sim
{ /*0*/

      
     
        
        

   /**
    * Construct a new Thing with an appearance defined by anIcon.
    * @param aCity The city where the thing exists.
    * @param aStreet The street within the city where the Thing will be placed.
    * @param anAvenue The avenue within the city where the Thing will be placed.
    * @param orientation The orientation the thing will have in the city.
    * One of {Direction.NORTH, EAST, SOUTH, WEST, SOUTHEAST, NORTHEAST,
    * SOUTHWEST, NORTHWEST}, although subclasses may provide further
    * restrictions.
    * @param canBeMoved True if this Thing can be picked up and moved by a
    * Robot; false otherwise.
    * @param anIcon The icon to use to display this thing.
    */
   public Thing(City aCity, int aStreet, int anAvenue, Direction orientation, boolean canBeMoved, Icon anIcon)
   { /*1*/      
        
         
       
   } /*1*/

   /**
    * Construct a new Thing with a default appearance that can be carried.
    * @param aCity The city where the thing exists.
    * @param aStreet The street within the city where the Thing will be placed.
    * @param anAvenue The avenue within the city where the Thing will be placed.
    */
   public Thing(City aCity, int aStreet, int anAvenue)
   { /*1*/      
                 
             
   } /*1*/

   /**
    * Construct a new Thing with a default appearance that can be carried,
    * in the given orientation.
    * @param aCity The city where the thing exists.
    * @param aStreet The street within the city where the Thing will be placed.
    * @param anAvenue The avenue within the city where the Thing will be placed.
    * @param orientation The orientation the thing will have in the city.
    * One of {Direction.NORTH, EAST, SOUTH, WEST, SOUTHEAST, NORTHEAST,
    * SOUTHWEST, NORTHWEST}, although subclasses may provide further
    * restrictions.
    */
   public Thing(City aCity, int aStreet, int anAvenue, Direction orientation)
   { /*1*/      
                 
             
   } /*1*/

   /** Construct a new thing held by the given robot.  
    * @param heldBy the robot that will hold the new thing in its backpack.
    */
   public Thing(Robot heldBy)
   { /*1*/    
            
                 
             
      
        
      
   } /*1*/
   
   /** Set whether this thing can be picked up and carried by a robot.
    * @param canCarry <code>true</code> if this thing can be carried; <code>false</code> otherwise.
    */
   public void setCanBeCarried(boolean canCarry)
   { /*1*/	  
   } /*1*/

   /**
    * Can this thing be picked up, carried, and put down by a robot?
    *  @return True if this thing can be carried; false otherwise.
    */
   public boolean canBeCarried()
   { /*1*/   
   } /*1*/
   
   /** Set whether this thing blocks a robot's entry from the given directions.
    *	 @param north <code>true</code> if this thing blocks a robot from entering 
    *			  from the <code>NORTH</code>; <code>false</code> otherwise.
    *	 @param south <code>true</code> if this thing blocks a robot from entering 
    *			  from the <code>SOUTH</code>; <code>false</code> otherwise.
    *	 @param east <code>true</code> if this thing blocks a robot from entering 
    *			  from the <code>EAST</code>; <code>false</code> otherwise.
    *	 @param west <code>true</code> if this thing blocks a robot from entering 
    *			  from the <code>WEST</code>; <code>false</code> otherwise.
    */
   public void setBlocksEntry(boolean north, boolean south, boolean east, boolean west)
   { /*1*/	  
   	  
   	  
   	  
   } /*1*/
   
   /** Set whether this thing blocks a robot's entry in the given direction.
    *	 @param aDir The direction to block in which to block a robot's exit. 
    *	 @param block <code>true</code> if this thing blocks a robot from entering 
    *			  from the given direction; <code>false</code> otherwise.
    */
   public void setBlocksEntry(Direction aDir, boolean block)
   { /*1*/	  
   } /*1*/

   
   /** Set whether this thing blocks a robot's exit in the given directions.
    *	 @param north <code>true</code> if this thing blocks a robot from exiting 
    *			  to the <code>NORTH</code>; <code>false</code> otherwise.
    *	 @param south <code>true</code> if this thing blocks a robot from exiting 
    *			  to the <code>SOUTH</code>; <code>false</code> otherwise.
    *	 @param east <code>true</code> if this thing blocks a robot from exiting 
    *			  to the <code>EAST</code>; <code>false</code> otherwise.
    *	 @param west <code>true</code> if this thing blocks a robot from exiting 
    *			  to the <code>WEST</code>; <code>false</code> otherwise.
    */
   public void setBlocksExit(boolean north, boolean south, boolean east, boolean west)
   { /*1*/	  
   	  
   	  
   	  
   } /*1*/

   
   /** Set whether this thing blocks a robot's exit in the given direction.
    *	 @param aDir The direction to block in which to block a robot's exit. 
    *	 @param block <code>true</code> if this thing blocks a robot from exiting 
    *			  in the given direction; <code>false</code> otherwise.
    */
   public void setBlocksExit(Direction aDir, boolean block)
   { /*1*/	  
   } /*1*/

   /**
    * Does this Thing block the entry of this intersection from the
    * given direction?
    *  @param entryDir The direction from which the entry might be blocked.
    *  One of {{@link Direction}.NORTH, SOUTH, EAST, WEST}.
    *  @return True if entry from the given direction is blocked by this
    * Thing, false otherwise.  
    */
   public boolean blocksIntersectionEntry(Direction entryDir)
   { /*1*/   
                  
      
       
   } /*1*/

   /**
    * Does this Thing block the exit of this intersection in the
    * given direction?
    *  @param exitDir The direction in which the exit might be blocked.
    *  One of {{@link Direction}.NORTH, SOUTH, EAST, WEST}.
    *  @return True if the exit in the given direction is blocked by this
    * Thing, false otherwise.  
    */
   public boolean blocksIntersectionExit(Direction exitDir)
   { /*1*/   
                  
      
       
   } /*1*/

   /** Return a reference to this thing's intersection.  If the thing is
    *  being carried by a robot, this thing's intersection is the same
    *  as the robot's intersection.
    *  @return This thing's intersection.
    */
   protected Intersection getIntersection()
   { /*1*/   
   } /*1*/

   /**
    * Save a representation of this intersection to an output stream.
    * @param indent the indentation, for formatting purposes
    * @param out the output stream
    */
   protected void save(String indent, PrintWriter out)
   { /*1*/       
         
      
   } /*1*/

   /**
    * Set where this Thing is located.  The location might be either an
    * intersection or a bot (which just picked it up).
    *  @param newLocation The intersection containing this thing or the
    * bot which picked it up.
    */
   
    
      
   


   
   /** Print this object represented as a string. */
   public String toString()
   { /*1*/         
                  
   } /*1*/
} /*0*/
