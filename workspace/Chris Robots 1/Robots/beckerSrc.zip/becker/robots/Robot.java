/* Copyright (c) 2003 by  
 * Byron Weber Becker, University of Waterloo, Waterloo, Ontario, Canada. 
 * All rights reserved.  Source code is released only with the written
 * permission of the author and may not be redistributed.
 */

package becker.robots;

 
 
 

 
 
 
 
 
 
 


/**
 * <p>Robots exist on a rectangular grid of roads and can move, turn left
 * ninety degrees, pick things up, carry things, and put things down.  A
 * robot knows which avenue and street it is on and which direction it is
 * facing.  Its speed can be set and queried.</p>
 *
 * <p>More advanced features include determining if it is safe to move forward,
 * examining things on the same intersection as
 * themselves and determining if they are beside a specific kind of thing.
 * Robots can also pick up and put down specific kinds of things and determine how
 * many things they are carrying.</p>
 *
 * @author Byron Weber Becker
 */
public class Robot extends Sim implements ILabel, IColor
{ /*0*/
   
      
   
   /** DEFAULT_MOVES_PER_SEC, stepsPerMove, speedFactor, and movesPerSec
    *  all help determine how fast this robot moves when animated.
    */
         
       
       

   
        
        
        

   
     
   
   
        


   /** Construct a new Robot at the given location in the given city
    *  with nothing in its backpack.
    *  @param aCity The city in which the robot will exist.
    *  @param aStreet The robot's initial street within the city.
    *  @param anAvenue The robot's initial avenue within the city.
    *  @param aDirection The robot's initial direction.  One of
    *  {{@link Direction}.NORTH, EAST, SOUTH, WEST}.
    */
   public Robot(City aCity, int aStreet, int anAvenue, Direction aDirection)
   { /*1*/      
   } /*1*/

   /** Construct a new Robot at the given location in the given city with the
    *  given number of things in its backpack.  Override makeThing to customize
    *  the kind of thing added to the backpack.  
    *  @param aCity The city in which the robot will exist.
    *  @param aStreet The robot's initial street within the city.
    *  @param anAvenue The robot's initial avenue within the city.
    *  @param aDirection The robot's initial direction.  One of
    *  {{@link Direction}.NORTH, EAST, SOUTH, WEST}.
    *  @param numThings The number of things initially in the Robot's backpack.
    */
   public Robot(City aCity, int aStreet, int anAvenue, Direction aDirection, int numThings)
   { /*1*/      
          
       
                 
      
      
        
      

      
      
          
      
       

              
            
      

		
      
   } /*1*/
   
   
   /**
    * Move this robot from the intersection it currently
    * occupies to the next intersection in the direction it is currently
    * facing, leaving it facing the same direction.
    *
    * <p>It is possible that something blocks the exit of this intersection
    * or blocks entry to the next intersection.  If the robot tries to move
    * in that direction anyway, it will break and no longer respond to
    * commands.  The robot can detect whether or not the way is clear
    * with the command {@link #frontIsClear}.</p>
    */
   public synchronized void move()
   { /*1*/   
        
      
         
         

       
                
                      
                  
         
      
      

        
              

      
   } /*1*/


   /**
    * Turn this robot left by 90 degrees or one quarter turn.
    * The robot remains on the same {@link Intersection}.  A robot cannot
    * encounter any errors while turning left.
    */
   public synchronized void turnLeft()
   { /*1*/   
   } /*1*/

   /** Attempt to pick up a movable thing from the current intersection.  If
    *  there are no movable things on the current intersection the robot will
    *  break and not respond to further commands.
    *
    *  @see #pickThing(IPredicate)
    *  @see #pickThing(Thing)
    *  @see #canPickThing()
    */
   public void pickThing()
   { /*1*/  
   } /*1*/


   /**
    * Take something out of the robot's backpack and put it down on the
    * intersection this robot currently occupies.  The robot breaks if the backpack is empty.
    *
    *  @see #putThing(IPredicate)
    *  @see #putThing(Thing)
    *  @see #countThingsInBackpack()
    */
   public void putThing()
   { /*1*/  
   } /*1*/

   /** Determine whether this robot is on the same intersection as a thing 
    *  it can pick up.  
    *  @return True if there is a movable thing on the same intersection as
    *  the robot; false otherwise.
    */
   public boolean canPickThing()
   { /*1*/  
   	 
   } /*1*/
	
   /**
    * Can this robot to move forward to the next intersection safely?
    *  @return True if nothing blocks the robot in the direction it is
    * currently facing; false if something blocks the way.
    */
   public boolean frontIsClear()
   { /*1*/     
       
         
       
           
          
      
   } /*1*/

   /** Which avenue is this robot on?
    *  @return The avenue this robot is on.
    */
   public int getAvenue()
   { /*1*/  
   	 
   } /*1*/

   /** Which street is this robot on?
    *  @return The street this robot is on.
    */
   public int getStreet()
   { /*1*/  
   	 
   } /*1*/

   /** Which direction is this robot facing?
    *  @return The direction this robot is facing.  One of
    *  {{@link Direction}.NORTH, SOUTH, EAST, WEST}.
    */
   public Direction getDirection()
   { /*1*/   
   } /*1*/

   /** How many things are in this robot's backpack?
    *  @return The number of things in this robot's backpack.
    *  @see #countThingsInBackpack(IPredicate)
    */
   public int countThingsInBackpack()
   { /*1*/   
   } /*1*/


   /** How many moves and/or turns does this robot complete in one second?
    *  @return The number of moves/turns per second.
    */
   public double getSpeed()
   { /*1*/   
   } /*1*/

   /** Set this robot's speed.
    *  @param movesPerSecond the approximate number of moves and/or turns a 
    *  robot will complete in one second.  The default is 2.0 moves per second.
    */
   public void setSpeed(double movesPerSecond)
   { /*1*/    
   } /*1*/
   
   /** Set this robot's transparency.  Has no effect if the robot's current icon is
    * not an instance of IColor.
    * @param trans The degree to which things under the robot will show through.
    *   0.0 is fully opque;  1.0 is fully transparent. */
   public void setTransparency(double trans)
   { /*1*/     
         
   } /*1*/
   
   /** Get this robot's transparency.
    * @return a number between 0.0 (fully opaque) and 1.0 (fully transparent) */
   public double getTransparency()
   { /*1*/   
   } /*1*/

   /** What is the string labeling this robot?
    * @return the string labeling this robot */
   public String getLabel()
   { /*1*/     
         
           
          
       
         
      
   } /*1*/

   /** Set a label to identify this robot.
    * @param theLabel the label identifying this robot */
   public void setLabel(String theLabel)
   { /*1*/  
        
   } /*1*/


   /** Return a reference to this robot's intersection.  
    *  @return This robot's intersection.
    */
   public Intersection getIntersection()
   { /*1*/    
   } /*1*/
	
   /** Attempt to pick up a particular kind of thing from the intersection
    *  this robot currently occupies.  If nothing matches the kind of
    *  thing specified the robot will break.  It is possible to specify
    *  things such as walls which cannot be moved.  This, too, causes the
    *  robot to break.  A broken robot will not respond to further
    *  commands.
    * @param kindOfThing A predicate indicating what kind of thing should
    * be picked up.
    * @see #pickThing()
    * @see #pickThing(Thing)
    */
   public void pickThing(IPredicate kindOfThing)
   { /*1*/  
   		   
      	
   	   
   		        
                
                              
   	
      
   } /*1*/

   /** Attempt to pick up a particular thing from the intersection this
    *  robot currently occupies.  If the thing does not exist on the
    *  current intersection or if the thing cannot be moved the robot
    *  will break, refusing to respond to further commands.  
    *
    *  @param theThing The thing to pick up.
    *  @see #pickThing()
    *  @see #pickThing(IPredicate)
    */
   public void pickThing(Thing theThing)
   { /*1*/   
        
      
           
           
           
                
         
         
         
         
                
       
                
                
                              
      
   } /*1*/

   /** Attempt to take a particular kind of thing out of this robot's backpack
    *  and put it on the intersection currently occupied by this robot.
    *  If the backpack is already empty the robot will break and will
    *  no longer respond to commands.
    * @param kindOfThing A predicate indicating what kind of thing should
    * be put down.
    * @see #putThing()
    * @see #putThing(Thing)
    */
   public void putThing(IPredicate kindOfThing)
   { /*1*/   
        
      

          
       /* this.isBroken ||*/   
           
                   
                   
                               
          
                   
                   
                                 
                       
         
         
       
           
           
                
         
         
         
                
      
   } /*1*/

   /** Attempt to put down a particular thing on the intersection this
    *  robot currently occupies.  If the thing does not exist in the
    *  robot's backpact, the robot will break, refusing to respond to
    *  further commands.
    *  @param theThing The thing to put down.
    *  @see #putThing()
    *  @see #putThing(IPredicate)
    */
   public void putThing(Thing theThing)
   { /*1*/   
        
      
       
        
       
                
                
                               
      
   } /*1*/

	/** This robot, represented as a string.
	 * @return A string representing this robot. */
   public String toString()
   { /*1*/          
                   
                  
                  
   } /*1*/

   /** Examine all the 
    * other <code>Robot</code>s, one at a time, that are on the same 
    * intersection 
    * as this robot.  <code>examineRobots</code>
    * returns an iterator, which may be used as follows:
    *
	 * <ul><li>One <code>Robot</code> can be obtained with
    * <pre>Robot r = this.examineRobots().next();</pre>
    * If there are no robots on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the robots (except this one) on the intersection
    * can be obtained, one at a time, with
    * <pre>for(Robot r : this.examineRobots())
    * {  // do something with r
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Robot> robots = this.examineRobots();
    * while (robots.hasNext())
    * {  Robot r = robots.next();
    *    // do something with r
    * }</pre></ul>
    *
    * @return an interator of all the robots (other than this robot) on this intersection. 
    * @see #examineThings()
    * @see #examineThings(IPredicate)
    * @see #examineLights()
    */
   public final IIterate<Robot> examineRobots()
   { /*1*/      
   		   
   			   
   		
   	
   	 
   } /*1*/

   /** Examine all the 
    * <code>Light</code> objects, one at a time, that are on the same 
    * intersection 
    * as this robot.  <code>examineLights</code>
    * returns an iterator, which may be used as follows:
    *
	 * <ul><li>One <code>Light</code> can be obtained with
    * <pre>Light l = this.examineLights().next();</pre>
    * If there are no lights on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the lights on the intersection
    * can be obtained, one at a time, with
    * <pre>for(Light l : this.examineLights())
    * {  // do something with l
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Light> lights = this.examineLights();
    * while (lights.hasNext())
    * {  Light l = lights.next();
    *    // do something with l
    * }</pre></ul>
    *
    * @return an interator of all the lights on this intersection. 
    * @see #examineThings()
    * @see #examineThings(IPredicate)
    * @see #examineRobots()
	 */
   public final IIterate<Light> examineLights()
   { /*1*/   
   } /*1*/


   /** Examine all the 
    * <code>Thing</code>s, one at a time, that are on the same intersection 
    * as this robot.  <code>examineThings</code>
    * returns an iterator, which may be used as follows:
    *
	 * <ul><li>One <code>Thing</code> can be obtained with
    * <pre>Thing t = this.examineThings().next();</pre>
    * If there are no things on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the things on the intersection
    * can be obtained, one at a time, with
    * <pre>for(Thing t : this.examineThings())
    * {  // do something with t
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Thing> things = this.examineThings();
    * while (things.hasNext())
    * {  Thing t = things.next();
    *    // do something with t
    * }</pre></ul>
    *
    * @return an interator of all the things on this intersection. 
    * @see #examineThings(IPredicate)
    * @see #examineLights()
    * @see #examineRobots()
    */
   public final IIterate<Thing> examineThings()
   { /*1*/   
   } /*1*/


   /** Examine all the 
    * <code>Thing</code>s, one at a time, that are on the same intersection 
    * as this robot and match the provided predicate.  <code>examineThings</code>
    * returns an iterator, which may be used as follows:
    *
	 * <ul><li>One <code>Thing</code> can be obtained with
    * <pre>Thing t = this.examineThings(aPredicate).next();</pre>
    * If there are no things matching the predicate on the intersection, 
    * an exception is thrown.</li>
    *
    * <li>All of the things on the intersection that match the predicate
    * can be obtained, one at a time, with
    * <pre>for(Thing t : this.examineThings(aPredicate))
    * {  // do something with t
    * } </pre></li>
    *
    * <li>A traditional iterator can also be used:
    * <pre>Iterator<Thing> things = this.examineThings(aPredicate);
    * while (things.hasNext())
    * {  Thing t = things.next();
    *    // do something with t
    * }</pre></ul>
    *
    * @param aPredicate A predicate used to test whether a thing should be 
    * included in the iteration.  Commonly used predicates are defined
    * in {@link becker.robots.IPredicate}.
    * @return an interator of all the things on this intersection. 
    * @see #examineThings()
    * @see #examineLights()
    * @see #examineRobots()
    */
   public final IIterate<Thing> examineThings(IPredicate aPredicate)
   { /*1*/   
   } /*1*/


   /** Determine whether this robot is on the same intersection as one or more 
    *  instances of the specified kind of thing.
    * @param kindOfThing A predicate indicating what kind of thing should
    * be looked for on the current intersection.
    *  @return True if there is a movable thing on the same intersection as
    *  the robot; false otherwise.
    */
   public boolean isBesideThing(IPredicate kindOfThing)
   { /*1*/  
   	 
   } /*1*/

   /** How many of a specific kind of thing are in this robot's backpack?
    *  @param kindOfThing The kind of thing to count.
    *  @return The number of things of the given kind.
    */
   public int countThingsInBackpack(IPredicate kindOfThing)
   { /*1*/   
   } /*1*/

   /**
    * Save a representation of this robot to an output stream.
    * @param indent A string of blanks, for formatting purposes.
    * @param out The output stream.
    */
   protected void save(String indent, PrintWriter out)
   { /*1*/       
         
         
         
         
   } /*1*/

   /** Make a new thing to place in the Robot's backpack.  Override this
    *  method in a subclass to control what kind of Thing is made when
    *  a robot is constructed with things in its backpack.
    *  @param n this will be the nth thing out of the total number to be made.
    *  @param total the total number of Things to be made.
    */
   protected Thing makeThing(int n, int total)
   { /*1*/    
   } /*1*/

   /**
    * This method is called when the robot does something illegal such
    * as trying to move through a wall or picking up a non-existant object.
    * Subclasses may also call this method to indicate that something has
    * gone wrong.  After breakRobot has been called, the robot does not
    * respond to any further messages and a {@link RobotException} is thrown.
    * @param msg The message for the exception.
    */
   protected void breakRobot(String msg)
   { /*1*/   
          

          
         
           
      
   } /*1*/
   
	/*************************************************************************
	 *
	 * PRIVATE stuff goes down here!
	 *
	 ************************************************************************/

   /** Animate a turn. */
   
  
         
         
          
      
         
         
             
            
               
            
      
      
              
             
             
              
          
           
              
         
             
         			
      

        
           
      
          
   
   

   /* Remember how many steps each move has taken in the recent past
    to help determine how large the first step of the next move should be. */
   
         
	
   /** Animate the move from one point to another. */
   
     
         
         
         
          

   
      
              
             
           
           
      

              
        /*oldPos.x = ave;
         oldPos.y = str;
         ave += xStepSize;
         str += yStepSize;
         super.setXPosition(ave);
         super.setYPosition(str);
         */
         
           
             
         
             
         
         
         
      
      
        
      
          
   

   
   
   
        
      
      
         
      
       

        
      
   
   
	/*************************************************************************
	 *
	 * PACKAGE-level stuff goes down here!
	 *
	 ************************************************************************/
   
   /** Called from the Thing(Robot heldBy) constructor, which might be called 
    * directly or from Robot.makeThing. 
    * @param t The thing to add to this robot. */
   /* package */ 
  
      
   

   
   /**
    * Turn this robot right by 90 degrees or one quarter turn.
    * The robot remains on the same {@link Intersection}.  A robot cannot
    * encounter any errors while turning right.  The method deliberately
    * has package access here and is made public in RobotSE.
    */
   /* package */  
   
   


   /** Is this bot broken? */
   /* package */
  
       
   

   /** Check if this robot is operational.  A side effect is to wait
    *  until the animation is (re)started.  Should be called from the
    *  core functions that cause the robot to "do" something -- move,
    *  turn, pick, put, etc.
    */
   /* package */
  
       
   

   /** Receive updates regarding the overall speed of the animation.
    *  This is in an inner class to hide <code>update</code> from users.
    */
       
   { /*1*/

           
           
               
              
         
      
   } /*1*/
} /*0*/
