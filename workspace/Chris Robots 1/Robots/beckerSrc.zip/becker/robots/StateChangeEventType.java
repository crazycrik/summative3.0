package becker.robots;


public enum StateChangeEventType 
{ /*0*/  /** A robot has begun moving. */
    
   /** A robot has stopped moving. */
    
   /** A robot is moving. */
    
   /** A robot has begun turning.. */
    
   /** A robot has stopped turning. */
    
   /** A robot is turning. */
    
   /** Something has been turned "on". */
    
   /** Something has been turned "off". */
    
   /** A Sim has been given a new icon. */
    
   /** A Sim or Icon's color has changed. */
    
   /** A Sim or Icon's label has changed. */
   
} /*0*/
