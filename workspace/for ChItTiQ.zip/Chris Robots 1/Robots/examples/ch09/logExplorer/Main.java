

/** Set up the LogExplorer program.
 *
 * @author Byron Weber Becker */
public class Main
{
   public static void main(String[] args)
   {  LogExplorer explorer = new LogExplorer();
      explorer.cmdInterpreter();
   }
}
