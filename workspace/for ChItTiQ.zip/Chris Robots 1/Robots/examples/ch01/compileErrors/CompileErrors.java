
/* The code below is commented out to prevent compile-time
 * errors in some of the author's automated tasks.  Please
 * remove the slash-asterisk and asterisk-slash combinations
 * of characters in lines 8 and 28. */


/*
import becker.robots;

publik class Errors
{
	public static void main(String[] args)
      karel.move();
      City 1ondon = new Cit y();
      Robot karel = new Robot(1ondon, 1, 1, Direction.EAST, 0)

		karal.move();
		karel.mvoe();
		karel.turnRight();
		karel.turnleft();
		move();
		karel.move;
	}
	karel.move();
}
*/